package entrada;

import conexao.Conexao;
import empresa.Empresa;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Entradadao {
        Conexao conexoes = new Conexao();
    Connection conexao;

    public Entradadao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Entrada e) throws SQLException, UnknownHostException, IOException {
        try {
            String sql = "INSERT INTO entrada(id_notafiscal, data_entrada, id_fornecedor, id_produto, valor_notafiscal, icms, data_faturamento) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, e.getId_notafiscal());
            stmt.setString(2, e.getData_entrada());
            stmt.setInt(3, e.getId_fornecedor());
            stmt.setInt(4, e.getId_produto());
            stmt.setFloat(5, e.getValor_notafiscal());
            stmt.setFloat(6, e.getIcms());
            stmt.setString(7, e.getData_faturamento());

            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "ENTRADA CADASTRADA COM SUCESSO!");
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Entrada e) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE entrada set id_notafiscal=?, data_entrada=?, id_fornecedor=?, id_produto=?, valor_notafiscal=?, icms=?, data_faturamento=? where id_entrada=?";
        PreparedStatement s = conexao.prepareStatement("select * from entrada");

        rs = s.executeQuery();

        while (rs.next()) {
            if (e.getId_entrada() == rs.getInt("id_entrada")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, e.getId_notafiscal());
            stmt.setString(2, e.getData_entrada());
            stmt.setInt(3, e.getId_fornecedor());
            stmt.setInt(4, e.getId_produto());
            stmt.setFloat(5, e.getValor_notafiscal());
            stmt.setFloat(6, e.getIcms());
            stmt.setString(7, e.getData_faturamento());
            stmt.setInt(8, e.getId_entrada());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "ENTRADA EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "ENTRADA NAO CADASTRADA!");
        }

    }

    public void excluir(Entrada e) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM entrada WHERE id_entrada=? ";
        PreparedStatement s = conexao.prepareStatement("select * from entrada");

        rs = s.executeQuery();

        while (rs.next()) {
            if (e.getId_entrada() == rs.getInt("id_entrada")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, e.getId_entrada());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "ENTRADA DELETADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "ENTRADA NAO CADASTRADA!");
        }

    }

    public List<Entrada> listar() throws SQLException {
        List<Entrada> entrada = new ArrayList<Entrada>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from entrada");

            rs = sql.executeQuery();

            while (rs.next()) {

                Entrada e = new Entrada();
                e.setId_entrada(rs.getInt("id_entrada"));
                e.setId_notafiscal(rs.getInt("id_notafiscal"));
                e.setData_entrada(rs.getString("data_entrada"));
                e.setId_fornecedor(rs.getInt("id_fornecedor"));
                e.setId_produto(rs.getInt("id_produto"));
                e.setValor_notafiscal(rs.getFloat("valor_notafiscal"));
                e.setIcms(rs.getFloat("icms"));
                e.setData_faturamento(rs.getString("data_faturamento"));
                entrada.add(e);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (entrada);
    }

    
}
