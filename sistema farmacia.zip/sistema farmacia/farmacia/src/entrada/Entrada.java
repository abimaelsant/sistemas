package entrada;

public class Entrada {
    private int id_entrada;
    private int id_notafiscal;
    private String data_entrada;
    private int id_fornecedor;
    private int id_produto;
    private float valor_notafiscal;
    private float icms;
    private String data_faturamento;
    
    public Entrada(){}

    public int getId_entrada() {
        return id_entrada;
    }

    public void setId_entrada(int id_entrada) {
        this.id_entrada = id_entrada;
    }

    public int getId_notafiscal() {
        return id_notafiscal;
    }

    public void setId_notafiscal(int id_notafiscal) {
        this.id_notafiscal = id_notafiscal;
    }

    public String getData_entrada() {
        return data_entrada;
    }

    public void setData_entrada(String data_entrada) {
        this.data_entrada = data_entrada;
    }

    public int getId_fornecedor() {
        return id_fornecedor;
    }

    public void setId_fornecedor(int id_fornecedor) {
        this.id_fornecedor = id_fornecedor;
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    public float getValor_notafiscal() {
        return valor_notafiscal;
    }

    public void setValor_notafiscal(float valor_notafiscal) {
        this.valor_notafiscal = valor_notafiscal;
    }

    public float getIcms() {
        return icms;
    }

    public void setIcms(float icms) {
        this.icms = icms;
    }

    public String getData_faturamento() {
        return data_faturamento;
    }

    public void setData_faturamento(String data_faturamento) {
        this.data_faturamento = data_faturamento;
    }
    
    
    
}
