package contas_pagar;

public class Contas_pagar {
    private int id_contas_pagar;
    private String data_compra;
    private String id_fornecedor;
    private String data_vcto;
    private float valor_divida;
    private int id_nota;
    private int numero_prestacao;
    private int id_forma_pagamento;
    
    public Contas_pagar(){}

    public Contas_pagar(int id_contas_pagar, String data_compra, String id_fornecedor, String data_vcto, float valor_divida, int id_nota, int numero_prestacao, int id_forma_pagamento) {
        this.id_contas_pagar = id_contas_pagar;
        this.data_compra = data_compra;
        this.id_fornecedor = id_fornecedor;
        this.data_vcto = data_vcto;
        this.valor_divida = valor_divida;
        this.id_nota = id_nota;
        this.numero_prestacao = numero_prestacao;
        this.id_forma_pagamento = id_forma_pagamento;
    }

    public int getId_contas_pagar() {
        return id_contas_pagar;
    }

    public void setId_contas_pagar(int id_contas_pagar) {
        this.id_contas_pagar = id_contas_pagar;
    }

    public String getData_compra() {
        return data_compra;
    }

    public void setData_compra(String data_compra) {
        this.data_compra = data_compra;
    }

    public String getId_fornecedor() {
        return id_fornecedor;
    }

    public void setId_fornecedor(String id_fornecedor) {
        this.id_fornecedor = id_fornecedor;
    }

    public String getData_vcto() {
        return data_vcto;
    }

    public void setData_vcto(String data_vcto) {
        this.data_vcto = data_vcto;
    }

    public float getValor_divida() {
        return valor_divida;
    }

    public void setValor_divida(float valor_divida) {
        this.valor_divida = valor_divida;
    }

    public int getId_nota() {
        return id_nota;
    }

    public void setId_nota(int id_nota) {
        this.id_nota = id_nota;
    }

    public int getNumero_prestacao() {
        return numero_prestacao;
    }

    public void setNumero_prestacao(int numero_prestacao) {
        this.numero_prestacao = numero_prestacao;
    }

    public int getId_forma_pagamento() {
        return id_forma_pagamento;
    }

    public void setId_forma_pagamento(int id_forma_pagamento) {
        this.id_forma_pagamento = id_forma_pagamento;
    }
    
    
    
}
