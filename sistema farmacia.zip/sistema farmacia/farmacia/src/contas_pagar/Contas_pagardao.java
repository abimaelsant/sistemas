package contas_pagar;

import caixa.Caixa;
import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import produto.Produtodao;

public class Contas_pagardao {
    Conexao conexoes = new Conexao();
    Connection conexao;

    public Contas_pagardao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Contas_pagar c) throws SQLException, UnknownHostException, IOException {
         
        ResultSet rs = null;
        int verifica = 0;
       try{
        String sql = "INSERT INTO contas_pagar(data_compra, id_fornecedor, data_vcto, valor_divida, id_nota, numero_prestacao, id_forma_pagamento) VALUES(?,?,?,?,?,?,?)";
        PreparedStatement s = conexao.prepareStatement("select * from contas_pagar");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_pagar() == rs.getInt("id_contas_pagar")) {
                verifica = 1;
            }
        }
        if (verifica == 0) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getData_compra());
            stmt.setString(2, c.getId_fornecedor());
            stmt.setString(3, c.getData_vcto());
            stmt.setFloat(4, c.getValor_divida());
            stmt.setInt(5, c.getId_nota());
            stmt.setInt(6, c.getNumero_prestacao());
            stmt.setInt(7, c.getId_forma_pagamento());
            
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "OPERAÇÃO REALIZADA COM SUCESSO!");
        }else{
            JOptionPane.showMessageDialog(null, "CONTA JÁ CADASTRADA!");
        }
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Contas_pagar c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE contas_pagar set  data_compra=?, id_fornecedor=?, data_vcto=?, valor_divida=?, id_nota=?, numero_prestacao=?, id_forma_pagamento=? where id_contas_pagar=?";
        PreparedStatement s = conexao.prepareStatement("select * from contas_pagar");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_pagar() == rs.getInt("id_contas_pagar")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getData_compra());
            stmt.setString(2, c.getId_fornecedor());
            stmt.setString(3, c.getData_vcto());
            stmt.setFloat(4, c.getValor_divida());
            stmt.setInt(5, c.getId_nota());
            stmt.setInt(6, c.getNumero_prestacao());
            stmt.setInt(7, c.getId_forma_pagamento());
            stmt.setInt(8, c.getId_contas_pagar());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADA!");
        }

    }

    public void excluir(Contas_pagar c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM contas_pagar WHERE id_contas_pagar=? ";
        PreparedStatement s = conexao.prepareStatement("select * from contas_pagar");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_pagar() == rs.getInt("id_contas_pagar")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, c.getId_contas_pagar());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "DELETADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADA!");
        }

    }

    public List<Contas_pagar> listar() throws SQLException {
        List<Contas_pagar> contas = new ArrayList<Contas_pagar>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from contas_pagar");

            rs = sql.executeQuery();

            while (rs.next()) {

                Contas_pagar c = new Contas_pagar();
                c.setId_contas_pagar(rs.getInt("id_contas_pagar"));
                c.setData_compra(rs.getString("data_compra"));
                c.setId_fornecedor(rs.getString("id_fornecedor"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setValor_divida(rs.getFloat("valor_divida"));
                c.setId_nota(rs.getInt("id_nota"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                contas.add(c);
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (contas);
    }
     public Contas_pagar contap(int id_c) throws SQLException {
        ResultSet rs = null;
        int verifica = 0;
        Contas_pagar c = new Contas_pagar();
               
            PreparedStatement sql = conexao.prepareStatement("select * from contas_pagar");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getInt("id_contas_pagar") == id_c){
                c.setId_contas_pagar(rs.getInt("id_contas_pagar"));
                c.setData_compra(rs.getString("data_compra"));
                c.setId_fornecedor(rs.getString("id_fornecedor"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setValor_divida(rs.getFloat("valor_divida"));
                c.setId_nota(rs.getInt("id_nota"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                verifica = 1;
            }
            }
            if(verifica == 0){
              JOptionPane.showMessageDialog(null, "CONTA NÃO ENCONTRADA!");
            }
            return c;
    }
    
      public List<Contas_pagar> contafor(String forn) throws SQLException {
        ResultSet rs = null;
        int verifica = 0;
        List<Contas_pagar> lista = new ArrayList<>();
        
               
            PreparedStatement sql = conexao.prepareStatement("select * from contas_pagar");

            rs = sql.executeQuery();

            while (rs.next()) {
                Contas_pagar c = new Contas_pagar();
                Produtodao daop = new Produtodao();
               if(daop.removerAcentos(rs.getString("id_fornecedor")).equals(daop.removerAcentos(forn))){
                c.setId_contas_pagar(rs.getInt("id_contas_pagar"));
                c.setData_compra(rs.getString("data_compra"));
                c.setId_fornecedor(rs.getString("id_fornecedor"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setValor_divida(rs.getFloat("valor_divida"));
                c.setId_nota(rs.getInt("id_nota"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                verifica = 1;
                lista.add(c);
            }
            }
            if(verifica == 0){
              JOptionPane.showMessageDialog(null, "CONTA(S) NÃO ENCONTRADA(S)!");
            }
            return lista;
    }
    public List<Contas_pagar> contafor2(String forn) throws SQLException {
        ResultSet rs = null;
        int verifica = 0;
        List<Contas_pagar> lista = new ArrayList<>();
        
               
            PreparedStatement sql = conexao.prepareStatement("select * from contas_pagar");

            rs = sql.executeQuery();

            while (rs.next()) {
                Contas_pagar c = new Contas_pagar();
                Produtodao daop = new Produtodao();
               if(daop.removerAcentos(rs.getString("id_fornecedor")).equals(daop.removerAcentos(forn))){
                c.setId_contas_pagar(rs.getInt("id_contas_pagar"));
                c.setData_compra(rs.getString("data_compra"));
                c.setId_fornecedor(rs.getString("id_fornecedor"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setValor_divida(rs.getFloat("valor_divida"));
                c.setId_nota(rs.getInt("id_nota"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                verifica = 1;
                lista.add(c);
            }
            }
            if(verifica == 0){
              //JOptionPane.showMessageDialog(null, "CONTA(S) NÃO ENCONTRADA(S)!");
            }
            return lista;
    }
    
}
