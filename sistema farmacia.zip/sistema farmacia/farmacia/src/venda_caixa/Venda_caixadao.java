package venda_caixa;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import venda.Venda;

public class Venda_caixadao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Venda_caixadao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Venda_caixa v) throws SQLException, UnknownHostException, IOException {
        ResultSet rs = null;
        int verifica = 0;
        try {
            String sql = "INSERT INTO venda_caixa(data_venda, numCaixa, cpf_cliente, id_forma_pagamento, valor_venda, valor_pago) VALUES(?,?,?,?,?,?)";
            PreparedStatement s = conexao.prepareStatement("select * from venda_caixa");

            rs = s.executeQuery();

            while (rs.next()) {
                if (v.getId_venda_caixa() == rs.getInt("id_venda_caixa")) {
                    verifica = 1;
                }
            }
            if (verifica == 0) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, v.getData_venda());
                stmt.setInt(2, v.getNumCaixa());
                stmt.setString(3, v.getCpf_cliente());
                stmt.setInt(4, v.getId_forma_pagamento());
                stmt.setFloat(5, v.getValor_venda());
                stmt.setFloat(6, v.getValor_pago());
                stmt.execute();
                stmt.close();
                //JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");
            } else {
                //JOptionPane.showMessageDialog(null, "VENDA JÁ CADASTRADA!");
            }
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Venda_caixa v) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE venda_caixa set data_venda=?, numCaixa=?, cpf_cliente=?, id_forma_pagamento=?, valor_venda=?, valor_pago=? where id_venda_caixa=?";
        PreparedStatement s = conexao.prepareStatement("select * from venda");

        rs = s.executeQuery();

        while (rs.next()) {
            if (v.getId_venda_caixa() == rs.getInt("id_venda_caixa")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, v.getData_venda());
            stmt.setInt(2, v.getNumCaixa());
            stmt.setString(3, v.getCpf_cliente());
            stmt.setInt(4, v.getId_forma_pagamento());
            stmt.setFloat(5, v.getValor_venda());
            stmt.setFloat(6, v.getValor_pago());
            stmt.setInt(7, v.getId_venda_caixa());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "VENDA EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "VENDA NÃO CADASTRADA!");
        }

    }

    public void excluir(Venda_caixa v) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM venda_caixa WHERE id_venda_caixa=? ";
        PreparedStatement s = conexao.prepareStatement("select * from venda_caixa");

        rs = s.executeQuery();

        while (rs.next()) {
            if (v.getId_venda_caixa() == rs.getInt("id_venda_caixa")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, v.getId_venda_caixa());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "VENDA DELETADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "VENDA NÃO CADASTRADA!");
        }

    }

    public List<Venda_caixa> listar() throws SQLException {
        List<Venda_caixa> venda = new ArrayList<Venda_caixa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from venda_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Venda_caixa v = new Venda_caixa();
                v.setId_venda_caixa(rs.getInt("id_venda_caixa"));
                v.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                v.setCpf_cliente(rs.getString("cpf_cliente"));
                v.setData_venda(rs.getString("data_venda"));
                v.setValor_venda(rs.getFloat("valor_venda"));
                v.setValor_pago(rs.getFloat("valor_pago"));
                v.setNumCaixa(rs.getInt("numCaixa"));
                venda.add(v);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (venda);
    }

    public List<Venda_caixa> listarvenda(int id_caixa, String data) throws SQLException {
        List<Venda_caixa> venda = new ArrayList<Venda_caixa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from venda_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Venda_caixa v = new Venda_caixa();
                if (id_caixa == rs.getInt("numCaixa") && data.equals(rs.getString("data_venda"))) {
                    v.setId_venda_caixa(rs.getInt("id_venda_caixa"));
                    v.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                    v.setData_venda(rs.getString("data_venda"));
                    v.setValor_venda(rs.getFloat("valor_venda"));
                    v.setValor_pago(rs.getFloat("valor_pago"));
                    v.setNumCaixa(rs.getInt("numCaixa"));
                    venda.add(v);
                }

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (venda);
    }

    public List<Venda_caixa> listarvenda_data(String data) throws SQLException {
        List<Venda_caixa> venda = new ArrayList<Venda_caixa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from venda_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Venda_caixa v = new Venda_caixa();
                if (data.equals(rs.getString("data_venda"))) {
                    v.setId_venda_caixa(rs.getInt("id_venda_caixa"));
                    v.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                    v.setData_venda(rs.getString("data_venda"));
                    v.setValor_venda(rs.getFloat("valor_venda"));
                    v.setValor_pago(rs.getFloat("valor_pago"));
                    v.setNumCaixa(rs.getInt("numCaixa"));
                    venda.add(v);
                }

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (venda);
    }

    public List<Venda_caixa> listarvenda_data_i_f(String dat_inicial, String dat_final) throws SQLException {
        List<Venda_caixa> venda = new ArrayList<Venda_caixa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from venda_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {
                String dia_i = dat_inicial.substring(0, 2);
                String mes_i = dat_inicial.substring(3, 5);
                String ano_i = dat_inicial.substring(6, 10);

                String dia_f = dat_final.substring(0, 2);
                String mes_f = dat_final.substring(3, 5);
                String ano_f = dat_final.substring(6, 10);

                String dia_v = rs.getString("data_venda").substring(0, 2);
                String mes_v = rs.getString("data_venda").substring(3, 5);
                String ano_v = rs.getString("data_venda").substring(6, 10);

                Venda_caixa v = new Venda_caixa();
                if (Integer.parseInt(dia_i) <= Integer.parseInt(dia_v) && Integer.parseInt(mes_i) <= Integer.parseInt(mes_v) && Integer.parseInt(ano_i) <= Integer.parseInt(ano_v) && Integer.parseInt(dia_f) >= Integer.parseInt(dia_v) && Integer.parseInt(mes_f) >= Integer.parseInt(mes_v) && Integer.parseInt(ano_f) >= Integer.parseInt(ano_v)) {
                    v.setId_venda_caixa(rs.getInt("id_venda_caixa"));
                    v.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                    v.setData_venda(rs.getString("data_venda"));
                    v.setValor_venda(rs.getFloat("valor_venda"));
                    v.setValor_pago(rs.getFloat("valor_pago"));
                    v.setNumCaixa(rs.getInt("numCaixa"));
                    venda.add(v);
                }

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (venda);
    }
}
