package venda_caixa;

public class Venda_caixa {
    private int id_venda_caixa;
    private String data_venda;
    private int numCaixa;
    private String cpf_cliente;
    private int id_forma_pagamento;
    private float valor_venda;
    private float valor_pago;
    
    public Venda_caixa(){}

    public Venda_caixa(int id_venda_caixa, String data_venda, int numCaixa, int id_forma_pagamento, float valor_venda, float valor_pago) {
        this.id_venda_caixa = id_venda_caixa;
        this.data_venda = data_venda;
        this.numCaixa = numCaixa;
        this.id_forma_pagamento = id_forma_pagamento;
        this.valor_venda = valor_venda;
        this.valor_pago = valor_pago;
    }

    public int getId_venda_caixa() {
        return id_venda_caixa;
    }

    public void setId_venda_caixa(int id_venda_caixa) {
        this.id_venda_caixa = id_venda_caixa;
    }

    public String getData_venda() {
        return data_venda;
    }

    public void setData_venda(String data_venda) {
        this.data_venda = data_venda;
    }

    public int getNumCaixa() {
        return numCaixa;
    }

    public void setNumCaixa(int numCaixa) {
        this.numCaixa = numCaixa;
    }

    public String getCpf_cliente() {
        return cpf_cliente;
    }

    public void setCpf_cliente(String cpf_cliente) {
        this.cpf_cliente = cpf_cliente;
    }

    public int getId_forma_pagamento() {
        return id_forma_pagamento;
    }

    public void setId_forma_pagamento(int id_forma_pagamento) {
        this.id_forma_pagamento = id_forma_pagamento;
    }

    public float getValor_venda() {
        return valor_venda;
    }

    public void setValor_venda(float valor_venda) {
        this.valor_venda = valor_venda;
    }

    public float getValor_pago() {
        return valor_pago;
    }

    public void setValor_pago(float valor_pago) {
        this.valor_pago = valor_pago;
    }
    
    
}
