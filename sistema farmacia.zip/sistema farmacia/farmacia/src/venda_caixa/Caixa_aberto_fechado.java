package venda_caixa;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import venda.Venda;

public class Caixa_aberto_fechado {
    Conexao conexoes = new Conexao();
    Connection conexao;

    public Caixa_aberto_fechado() throws SQLException {
        this.conexao = conexoes.conexao();
    }
    private int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
    
    
    public void altera_caixa_abre() throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE caixa_aberto_fechado set status1=? where id_caixa_aberto_fechado=?";
        
        
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, 1);
            stmt.setInt(2, 1);
            stmt.executeUpdate();
            stmt.close();
    }
    
    
    public void altera_caixa_fecha() throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE caixa_aberto_fechado set status1=? where id_caixa_aberto_fechado=?";
        
        
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, 2);
            stmt.setInt(2, 1);
            stmt.executeUpdate();
            stmt.close();
    }
    public int status() throws SQLException{
         ResultSet rs = null;
        //Produto p = new Produto();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from caixa_aberto_fechado");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getInt("id_caixa_aberto_fechado") == 1){
                  if(rs.getInt("status1") == 1){
                    verifica = 1;
                }else{
                  if(rs.getInt("status1") == 2){
                      verifica = 2;
                  }
              }

            }
            }
                    return verifica;

    }
}

