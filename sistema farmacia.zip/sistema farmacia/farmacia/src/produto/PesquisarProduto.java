package produto;

import fornecedor.Fornecedor;
import fornecedor.Fornecedordao;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import laboratorio.Laboratorio;
import laboratorio.Laboratoriodao;
import venda.VendaSI;

public class PesquisarProduto extends javax.swing.JFrame {

    public PesquisarProduto() {
        initComponents();
        
         this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton7 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        nome_prod = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        prod_tab = new javax.swing.JTable();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 51, 153));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/listar 2.png"))); // NOI18N
        jButton7.setText("Listar os Produtos");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 210, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Nome do Prod:  ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, -1, -1));
        getContentPane().add(nome_prod, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 250, 30));

        jButton12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(0, 51, 153));
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 2.png"))); // NOI18N
        jButton12.setText("Pesquisar Produto");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, 210, 40));

        prod_tab.setForeground(new java.awt.Color(0, 51, 153));
        prod_tab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Nº Lote", "Desconto", "Valor ", "Qt  Estoque"
            }
        ));
        jScrollPane3.setViewportView(prod_tab);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 560, 290));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        Produtodao dao;
        try {
            dao = new Produtodao();
            Laboratoriodao daol = new Laboratoriodao();
            Fornecedordao daof = new Fornecedordao();
            Produto p = new Produto();
            Laboratorio l = new Laboratorio();
            Fornecedor f = new Fornecedor();
            List<Produto> lista = new ArrayList<>();
            List<String> nomes = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) prod_tab.getModel();
            ((DefaultTableModel) prod_tab.getModel()).setNumRows(0);
            prod_tab.updateUI();
            lista = dao.listar();

            Collections.sort (lista, new Comparator<Produto> () {
                public int compare (Produto p1, Produto p2) {
                    return p1.getNome().toUpperCase().compareTo (p2.getNome().toUpperCase());
                }
            });
            for (int i = 0; i < lista.size(); i++) {
                l = daol.laboratorio_nome(lista.get(i).getId_laboratorio());
                f = daof.fornecedor_nome(lista.get(i).getId_fornecedor());
                table.addRow(new Object[]{lista.get(i).getCodigo_produto(), lista.get(i).getNome(), lista.get(i).getNumero_lote(), lista.get(i).getDesconto(), lista.get(i).getValor_venda(), lista.get(i).getQuantidade_estoque()});

            }
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoSI.class
                .getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

        try {
            Laboratoriodao daol = new Laboratoriodao();
            Laboratorio l = new Laboratorio();
            Fornecedordao daof = new Fornecedordao();
            Fornecedor f = new Fornecedor();
            Produtodao daop = new Produtodao();
            Produto p = new Produto();
            List<Produto> lista = new ArrayList<>();
            if(!nome_prod.getText().isEmpty()){
                lista = daop.listar_prod_venda(nome_prod.getText());
                if(lista.size() > 0){
                    DefaultTableModel table = new DefaultTableModel();
                    table = (DefaultTableModel) prod_tab.getModel();
                    ((DefaultTableModel) prod_tab.getModel()).setNumRows(0);
                    prod_tab.updateUI();
                    for(int i = 0; i < lista.size(); i++){
                        l = daol.laboratorio_nome(lista.get(i).getId_laboratorio());
                        f = daof.fornecedor_nome(lista.get(i).getId_fornecedor());
                        table.addRow(new Object[]{lista.get(i).getCodigo_produto(), lista.get(i).getNome(), lista.get(i).getNumero_lote(), lista.get(i).getDesconto(), lista.get(i).getValor_venda(), lista.get(i).getQuantidade_estoque()});
                    }
                }else{
                    ((DefaultTableModel) prod_tab.getModel()).setNumRows(0);
                    prod_tab.updateUI();
                    JOptionPane.showMessageDialog(null, "NÃO FOI ENCONTRADO NENHUM PRODUTO COM ESSE NOME!");
                }
            }else{
                JOptionPane.showMessageDialog(null, "CAMPO VÁZIO!");
            }

        } catch (SQLException ex) {
            Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton12ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PesquisarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PesquisarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PesquisarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PesquisarProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PesquisarProduto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField nome_prod;
    private javax.swing.JTable prod_tab;
    // End of variables declaration//GEN-END:variables
}
