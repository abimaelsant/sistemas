package produto;

public class Produto {
   private int id_produto;
   private String codigo_produto;
   private String nome;
   private String numero_lote;
   private String id_laboratorio;
   private float desconto;
   private boolean permitirdesconto;
   private int fatorcompra;
   private float valor_custo;
   private float valor_margem;
   private float valor_venda;
   private int quantidade_estoque;
   private int estoque_minimo;
   private boolean ativo_inativo;
   private float comissao;
   private float aliquota;
   private float pis_cofins;
   private float ncm;
   private float icms;
   private String fornecedor;
   private String data_vencimento;
   
   public Produto(){}

    public Produto(int id_produto, String codigo_produto, String nome, String numero_lote, String id_laboratorio, float desconto, boolean permitirdesconto, int fatorcompra, float valor_custo, float valor_margem, float valor_venda, int quantidade_estoque, int estoque_minimo, boolean ativo_inativo, float comissao, float aliquota, float pis_cofins, float ncm, float icms, String fornecedor, String data_vencimento) {
        this.id_produto = id_produto;
        this.codigo_produto = codigo_produto;
        this.nome = nome;
        this.numero_lote = numero_lote;
        this.id_laboratorio = id_laboratorio;
        this.desconto = desconto;
        this.permitirdesconto = permitirdesconto;
        this.fatorcompra = fatorcompra;
        this.valor_custo = valor_custo;
        this.valor_margem = valor_margem;
        this.valor_venda = valor_venda;
        this.quantidade_estoque = quantidade_estoque;
        this.estoque_minimo = estoque_minimo;
        this.ativo_inativo = ativo_inativo;
        this.comissao = comissao;
        this.aliquota = aliquota;
        this.pis_cofins = pis_cofins;
        this.ncm = ncm;
        this.icms = icms;
        this.fornecedor = fornecedor;
        this.data_vencimento = data_vencimento;
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    public String getCodigo_produto() {
        return codigo_produto;
    }

    public void setCodigo_produto(String codigo_produto) {
        this.codigo_produto = codigo_produto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumero_lote() {
        return numero_lote;
    }

    public void setNumero_lote(String numero_lote) {
        this.numero_lote = numero_lote;
    }

    public String getId_laboratorio() {
        return id_laboratorio;
    }

    public void setId_laboratorio(String id_laboratorio) {
        this.id_laboratorio = id_laboratorio;
    }

    public float getDesconto() {
        return desconto;
    }

    public void setDesconto(float desconto) {
        this.desconto = desconto;
    }

    public boolean getPermitirdesconto() {
        return permitirdesconto;
    }

    public void setPermitirdesconto(boolean permitirdesconto) {
        this.permitirdesconto = permitirdesconto;
    }

    public int getFatorcompra() {
        return fatorcompra;
    }

    public void setFatorcompra(int fatorcompra) {
        this.fatorcompra = fatorcompra;
    }

    public float getValor_custo() {
        return valor_custo;
    }

    public void setValor_custo(float valor_custo) {
        this.valor_custo = valor_custo;
    }

    public float getValor_margem() {
        return valor_margem;
    }

    public void setValor_margem(float valor_margem) {
        this.valor_margem = valor_margem;
    }

    public float getValor_venda() {
        return valor_venda;
    }

    public void setValor_venda(float valor_venda) {
        this.valor_venda = valor_venda;
    }

    public int getQuantidade_estoque() {
        return quantidade_estoque;
    }

    public void setQuantidade_estoque(int quantidade_estoque) {
        this.quantidade_estoque = quantidade_estoque;
    }

    public int getEstoque_minimo() {
        return estoque_minimo;
    }

    public void setEstoque_minimo(int estoque_minimo) {
        this.estoque_minimo = estoque_minimo;
    }

    public boolean getAtivo_inativo() {
        return ativo_inativo;
    }

    public void setAtivo_inativo(boolean ativo_inativo) {
        this.ativo_inativo = ativo_inativo;
    }

    public float getComissao() {
        return comissao;
    }

    public void setComissao(float comissao) {
        this.comissao = comissao;
    }

    public float getAliquota() {
        return aliquota;
    }

    public void setAliquota(float aliquota) {
        this.aliquota = aliquota;
    }

    public float getPis_cofins() {
        return pis_cofins;
    }

    public void setPis_cofins(float pis_cofins) {
        this.pis_cofins = pis_cofins;
    }

    public float getNcm() {
        return ncm;
    }

    public void setNcm(float ncm) {
        this.ncm = ncm;
    }

    public float getIcms() {
        return icms;
    }

    public void setIcms(float icms) {
        this.icms = icms;
    }

    public String getId_fornecedor() {
        return fornecedor;
    }

    public void setId_fornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public String getData_vencimento() {
        return data_vencimento;
    }

    public void setData_vencimento(String data_vencimento) {
        this.data_vencimento = data_vencimento;
    }
   
   
}
