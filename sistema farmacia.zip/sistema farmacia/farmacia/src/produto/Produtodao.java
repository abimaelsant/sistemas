package produto;

import cliente.Cliente;
import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Produtodao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Produtodao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public String removerAcentos(String str){
	return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "").toUpperCase();
    }
    public String maiuscula(String str){
        return str.toUpperCase();
    }
    
    public void cadastro(Produto p) throws SQLException, UnknownHostException, IOException {
        int verifica = 0, vf = 0, vl = 0;
        String sql = "INSERT INTO produto(codigo_produto, nome, numero_lote, laboratorio, desconto, permitirdesconto, fatorcompra, valor_custo, valor_margem, valor_venda, quantidade_estoque, estoque_minimo, ativo_inativo, comissao, aliquota, pis_cofins, ncm, icms, fornecedor, data_vencimento) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        ResultSet rs = null;
        PreparedStatement s = conexao.prepareStatement("select * from produto");

        rs = s.executeQuery();
        
        while (rs.next()) {
            if (p.getCodigo_produto().equals(rs.getString("codigo_produto")) || p.getCodigo_produto() == null || p.getCodigo_produto().equals("")) {
                verifica = 1;
            }
        }
        if (verifica == 0 ) {
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, p.getCodigo_produto());
            stmt.setString(2, p.getNome());
            stmt.setString(3, p.getNumero_lote());
            stmt.setString(4, p.getId_laboratorio());
            stmt.setFloat(5, p.getDesconto());
            stmt.setBoolean(6, p.getPermitirdesconto());
            stmt.setInt(7, p.getFatorcompra());
            stmt.setFloat(8, p.getValor_custo());
            stmt.setFloat(9, p.getValor_margem());
            stmt.setFloat(10, p.getValor_venda());
            stmt.setInt(11, p.getQuantidade_estoque());
            stmt.setInt(12, p.getEstoque_minimo());
            stmt.setBoolean(13, p.getAtivo_inativo());
            stmt.setFloat(14, p.getComissao());
            stmt.setFloat(15, p.getAliquota());
            stmt.setFloat(16, p.getPis_cofins());
            stmt.setFloat(17, p.getNcm());
            stmt.setFloat(18, p.getIcms());
            stmt.setString(19, p.getId_fornecedor());
            stmt.setString(20, p.getData_vencimento());

            stmt.execute();
            stmt.close();
//            if (p.getCodigo_produto().isEmpty()) {
  //              atualiza_codigo();
    //        }
          
            JOptionPane.showMessageDialog(null, "PRODUTO CADASTRADO COM SUCESSO!");
          
        }else{
            JOptionPane.showMessageDialog(null, "PRODUTO JÁ CADASTRADO!");
        }
    }

    public void altera(Produto p) throws SQLException, UnknownHostException, IOException {
        int verifica = 0, vf = 0, vl= 0;
        try {

            ResultSet rs = null;
            String sql = "UPDATE produto set nome=?, numero_lote=?, laboratorio=?, desconto=?, permitirdesconto=?, fatorcompra=?, valor_custo=?, valor_margem=?, valor_venda=?, quantidade_estoque=?, estoque_minimo=?, ativo_inativo=?, comissao=?, aliquota=?, pis_cofins=?, ncm=?, icms=?, fornecedor=?, data_vencimento=? where codigo_produto=?";
            PreparedStatement s = conexao.prepareStatement("select * from produto");

            rs = s.executeQuery();
            
        ResultSet rsf = null;
        PreparedStatement sf = conexao.prepareStatement("select * from empresa");

        ResultSet rsl = null;
        PreparedStatement sl = conexao.prepareStatement("select * from laboratorio");

        rsl = sl.executeQuery();
        
        while(rsl.next()){
            if(p.getId_laboratorio().equals(rsl.getString("nome"))){
                vl = 1;
            }
        }
        
        if(p.getId_laboratorio() == null || p.getId_laboratorio().equals("")){
            vl = 2;
        }
        rsf = sf.executeQuery();
        while(rsf.next()){
            if(p.getId_fornecedor().equals(rsf.getString("nome"))){
                vf = 2;
            }
        }
        if(p.getId_fornecedor() == null || p.getId_fornecedor().equals("")){
            vf = 3;
        }
            while (rs.next()) {
                if (p.getCodigo_produto().equals(rs.getString("codigo_produto"))) {
                    verifica = 1;
                }
            }
             while (rs.next()) {
            if (p.getCodigo_produto() == null || p.getCodigo_produto().equals("")) {
                verifica = 2;
            }
        }
            if (verifica == 1) {
              if(vf == 2 || vf == 3){
                  if(vl == 1 || vl == 2){
                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, p.getNome());
                stmt.setString(2, p.getNumero_lote());
                stmt.setString(3, p.getId_laboratorio());
                stmt.setFloat(4, p.getDesconto());
                stmt.setBoolean(5, p.getPermitirdesconto());
                stmt.setInt(6, p.getFatorcompra());
                stmt.setFloat(7, p.getValor_custo());
                stmt.setFloat(8, p.getValor_margem());
                stmt.setFloat(9, p.getValor_venda());
                stmt.setInt(10, p.getQuantidade_estoque());
                stmt.setInt(11, p.getEstoque_minimo());
                stmt.setBoolean(12, p.getAtivo_inativo());
                stmt.setFloat(13, p.getComissao());
                stmt.setFloat(14, p.getAliquota());
                stmt.setFloat(15, p.getPis_cofins());
                stmt.setFloat(16, p.getNcm());
                stmt.setFloat(17, p.getIcms());
                stmt.setString(18, p.getId_fornecedor());
                stmt.setString(19, p.getData_vencimento());
                stmt.setString(20, p.getCodigo_produto());
                stmt.executeUpdate();
                stmt.close();
                JOptionPane.showMessageDialog(null, "PRODUTO EDITADO COM SUCESSO!");
                  }else{
                      JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
                  }
                  }else{
                  JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA NO SISTEMA!");
              }
              } else {
                JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao editar" + e);
        }
    }

    public void excluir(Produto p) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {
            ResultSet rs = null;
            String sql = "DELETE FROM produto WHERE codigo_produto=? ";
            PreparedStatement s = conexao.prepareStatement("select * from produto");

            rs = s.executeQuery();

            while (rs.next()) {
                if (p.getCodigo_produto().equals(rs.getString("codigo_produto"))) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, p.getCodigo_produto());
                stmt.execute();
                stmt.close();
                JOptionPane.showMessageDialog(null, "PRODUTO DELETADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir" + e);
        }
    }

    public List<Produto> listar() throws SQLException {
        List<Produto> produto = new ArrayList<Produto>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {

                Produto p = new Produto();
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
               // p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                //p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                p.setData_vencimento(rs.getString("data_vencimento"));
                produto.add(p);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (produto);
    }
public List<Produto> listar_prod_venda(String nome) throws SQLException {
        List<Produto> produto = new ArrayList<Produto>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {

                Produto p = new Produto();
               if(removerAcentos(rs.getString("nome")).equals(removerAcentos(nome))){
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
               // p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                //p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                p.setData_vencimento(rs.getString("data_vencimento"));
                produto.add(p);
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (produto);
    }
    public void atualiza_codigo() throws SQLException {
        ResultSet rs = null;

        PreparedStatement sql = conexao.prepareStatement("select * from produto");

        rs = sql.executeQuery();
        Produto p = new Produto();
        while (rs.next()) {
            p.setId_produto(rs.getInt("id_produto"));
            p.setCodigo_produto(rs.getString("codigo_produto"));
            String cod_prod = p.getCodigo_produto();
            if (cod_prod.isEmpty()) {
                String cod = String.valueOf(p.getId_produto());
                String sql_cod = "UPDATE produto set codigo_produto=? where id_produto=?";
                PreparedStatement stmt = conexao.prepareStatement(sql_cod);
                stmt.setString(1, cod);
                stmt.setInt(2, p.getId_produto());
                stmt.executeUpdate();
                stmt.close();
            }
        }
    }
    
    public Produto produto(String id_p) throws SQLException{
         ResultSet rs = null;
        Produto p = new Produto();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(removerAcentos(rs.getString("nome")).equals(removerAcentos(id_p))){
                p.setId_produto(rs.getInt("id_produto"));
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
                //p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                //p.setData_vencimento(rs.getString("data_nascimento"));
                verifica = 1;
              }

            }
         if(verifica == 0){
             JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
         }
        return (p);
    }
    
    
    public Produto produto_codigoP(String id_p) throws SQLException{
         ResultSet rs = null;
        Produto p = new Produto();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(removerAcentos(rs.getString("codigo_produto")).equals(removerAcentos(id_p))){
                p.setId_produto(rs.getInt("id_produto"));
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
                //p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                //p.setData_vencimento(rs.getString("data_nascimento"));
                verifica = 1;
              }

            }
         if(verifica == 0){
             JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
         }
        return (p);
    }
    
    
    
    public List<Produto> produto_nomeP(String nome) throws SQLException{
         ResultSet rs = null;
       List<Produto> produto = new ArrayList<>();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {
                 Produto p = new Produto();
              if(removerAcentos(rs.getString("nome")).equals(removerAcentos(nome))){
                p.setId_produto(rs.getInt("id_produto"));
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
                //p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                //p.setData_vencimento(rs.getString("data_nascimento"));
                verifica = 1;
                produto.add(p);
              }

            }
         if(verifica == 0){
             JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
         }
        return (produto);
    }
    public List<Produto> produto_nomeP2(String nome) throws SQLException{
         ResultSet rs = null;
       List<Produto> produto = new ArrayList<>();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {
                 Produto p = new Produto();
              if(removerAcentos(rs.getString("nome")).equals(removerAcentos(nome))){
                p.setId_produto(rs.getInt("id_produto"));
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
                //p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                //p.setData_vencimento(rs.getString("data_nascimento"));
                verifica = 1;
                produto.add(p);
              }

            }
         if(verifica == 0){
   //          JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
         }
        return (produto);
    }
    
     
    
    
    
    
     public Produto produto_cod(String id_p) throws SQLException{
         ResultSet rs = null;
        Produto p = new Produto();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getString("codigo_produto").equals(id_p)){
                p.setId_produto(rs.getInt("id_produto"));
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
                //p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                //p.setData_vencimento(rs.getString("data_nascimento"));
                verifica = 1;
              }

            }
         if(verifica == 0){
             JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
         }
        return (p);
    }
    
    
    public void altera_cod(Produto p) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {

            ResultSet rs = null;
            String sql = "UPDATE produto set  quantidade_estoque=? where codigo_produto=?";
            PreparedStatement s = conexao.prepareStatement("select * from produto");

            rs = s.executeQuery();

            while (rs.next()) {
                if (p.getCodigo_produto().equals(rs.getString("codigo_produto"))) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);
                if(p.getQuantidade_estoque() < 1){
                    p.setQuantidade_estoque(0);
                }
                if(p.getQuantidade_estoque() <= p.getEstoque_minimo()){
                    JOptionPane.showMessageDialog(null, "O ESTOQUE MINÍMO PRODUTO "+p.getNome()+" FOI ATINGIDO!");
                }
                stmt.setInt(1, p.getQuantidade_estoque());
                stmt.setString(2, p.getCodigo_produto());
                stmt.executeUpdate();
                stmt.close();
                //JOptionPane.showMessageDialog(null, "PRODUTO EDITADO COM SUCESSO!");
            } else {
                //JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao editar" + e);
        }
    }
    public Produto produtop(String id_p) throws SQLException{
         ResultSet rs = null;
        Produto p = new Produto();
        int verifica = 0;
 
            PreparedStatement sql = conexao.prepareStatement("select * from produto");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getString("codigo_produto").equals(id_p)){
                p.setCodigo_produto(rs.getString("codigo_produto"));
                p.setNome(rs.getString("nome"));
                p.setNumero_lote(rs.getString("numero_lote"));
                p.setId_laboratorio(rs.getString("laboratorio"));
                p.setDesconto(rs.getFloat("desconto"));
                //p.setPermitirdesconto(rs.getBoolean("permitirdesconto"));
                //p.setFatorcompra(rs.getInt("fatorcomptra"));
                p.setValor_custo(rs.getFloat("valor_custo"));
                //p.setValor_margem(rs.getFloat("valor_margem"));
                p.setValor_venda(rs.getFloat("valor_venda"));
                p.setQuantidade_estoque(rs.getInt("quantidade_estoque"));
                p.setEstoque_minimo(rs.getInt("estoque_minimo"));
                //p.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
                p.setComissao(rs.getFloat("comissao"));
                p.setAliquota(rs.getFloat("aliquota"));
                p.setPis_cofins(rs.getFloat("pis_cofins"));
                p.setNcm(rs.getFloat("ncm"));
                p.setIcms(rs.getFloat("icms"));
                p.setId_fornecedor(rs.getString("fornecedor"));
                //p.setData_vencimento(rs.getString("data_nascimento"));
                verifica = 1;
              }

            }
         if(verifica == 0){
             //JOptionPane.showMessageDialog(null, "PRODUTO NÃO CADASTRADO!");
         }
        return (p);
    }
}
