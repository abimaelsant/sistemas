package caixa;

public class Caixas {
    private int id_caixas;
    private String descricao;
    
    public Caixas(){}

    public Caixas(int id_caixas, String descricao) {
        this.id_caixas = id_caixas;
        this.descricao = descricao;
    }

    public int getId_caixas() {
        return id_caixas;
    }

    public void setId_caixas(int id_caixas) {
        this.id_caixas = id_caixas;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
