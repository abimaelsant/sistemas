package caixa;

import conexao.Conexao;
import empresa.Empresa;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Caixadao {
    Conexao conexoes = new Conexao();
    Connection conexao;

    public Caixadao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Caixa c) throws SQLException, UnknownHostException, IOException {
        try {
            String sql = "INSERT INTO caixa(numCaixa, vendaAvista, vendaAprazo, vendaConvenio, vendaCartaoC, totalDiario, totalAcumulado, data_abertura, data_fechamento) VALUES(?,?,?,?,?,?,?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setInt(1, c.getNumCaixa());
            stmt.setFloat(2, c.getVendaAvista());
            stmt.setFloat(3, c.getVendaAprazo());
            stmt.setFloat(4, c.getVendaConvenio());
            stmt.setFloat(5, c.getVendaCartao());
            stmt.setFloat(6, c.getTotalDiario());
            stmt.setFloat(7, c.getTotalAcumulado());
            stmt.setString(8, c.getData_abertura());
            stmt.setString(9, c.getData_fechamento());
            
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "OPERAÇÃO REALIZADA COM SUCESSO!");
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Caixa c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE caixa set  vendaAvista=?, vendaAprazo=?, vendaConvenio=?, vendaCartao=?, totalDiario=?, totalAcumulado=?, data_abertura=?, data_fechamento=? where id_caixa=?";
        PreparedStatement s = conexao.prepareStatement("select * from caixa");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_caixa() == rs.getInt("id_caixa")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setFloat(1, c.getVendaAvista());
            stmt.setFloat(2, c.getVendaAprazo());
            stmt.setFloat(3, c.getVendaConvenio());
            stmt.setFloat(4, c.getVendaCartao());
            stmt.setFloat(5, c.getTotalDiario());
            stmt.setFloat(6, c.getTotalAcumulado());
            stmt.setString(7, c.getData_abertura());
            stmt.setString(8, c.getData_fechamento());
            stmt.setInt(9, c.getId_caixa());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "CAIXA EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "CAIXA NÃO CADASTRADA!");
        }

    }

    public void excluir(Caixa c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM caixa WHERE id_caixa=? ";
        PreparedStatement s = conexao.prepareStatement("select * from caixa");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_caixa() == rs.getInt("id_caixa")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, c.getId_caixa());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "INFORMACÕES DE CAIXA DELETADAS COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADA!");
        }

    }

    public List<Caixa> listar() throws SQLException {
        List<Caixa> caixa = new ArrayList<Caixa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from caixa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Caixa c = new Caixa();
                c.setId_caixa(rs.getInt("id_caixa"));
                c.setNumCaixa(rs.getInt("numCaixa"));
                c.setVendaAvista(rs.getFloat("vendaAvista"));
                c.setVendaAprazo(rs.getFloat("vendaAprazo"));
                c.setVendaConvenio(rs.getFloat("vendaConvenio"));
                c.setVendaCartao(rs.getFloat("vendaCartaoC"));
                c.setTotalDiario(rs.getFloat("totalDiario"));
                c.setTotalAcumulado(rs.getFloat("totalAcumulado"));
                c.setData_abertura(rs.getString("data_abertura"));
                c.setData_fechamento(rs.getString("data_fechamento"));
                caixa.add(c);
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (caixa);
    }  
}
