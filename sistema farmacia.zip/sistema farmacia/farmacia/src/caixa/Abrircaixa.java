package caixa;

public class Abrircaixa {
    private int numCaixa;
    private float valor;
    private String data_abertura;

    public Abrircaixa(int numCaixa, float valor, String data_abertura) {
        this.numCaixa = numCaixa;
        this.valor = valor;
        this.data_abertura = data_abertura;
    }
    public Abrircaixa(){}

    public int getNumCaixa() {
        return numCaixa;
    }

    public void setNumCaixa(int numCaixa) {
        this.numCaixa = numCaixa;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public String getData_abertura() {
        return data_abertura;
    }

    public void setData_abertura(String data_abertura) {
        this.data_abertura = data_abertura;
    }
    
    
}
