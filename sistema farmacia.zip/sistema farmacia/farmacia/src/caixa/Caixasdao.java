package caixa;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Caixasdao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Caixasdao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Caixas c) throws SQLException, UnknownHostException, IOException {
        try {
            String sql = "INSERT INTO caixas(descricao) VALUES(?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getDescricao());

            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "OPERAÇÃO REALIZADA COM SUCESSO!");
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Caixas c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE caixas set  descricao=? where id_caixas=?";
        PreparedStatement s = conexao.prepareStatement("select * from caixas");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_caixas() == rs.getInt("id_caixas")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getDescricao());
            stmt.setInt(2, c.getId_caixas());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "CAIXA EDITADO COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "CAIXA NÃO CADASTRADO!");
        }

    }

    public void excluir(Caixas c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM caixas WHERE id_caixas=? ";
        PreparedStatement s = conexao.prepareStatement("select * from caixas");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_caixas() == rs.getInt("id_caixas")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, c.getId_caixas());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "CAIXA DELETADO COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "CAIXA NÃO CADASTRADO!");
        }

    }

    public List<Caixas> listar() throws SQLException {
        List<Caixas> caixa = new ArrayList<Caixas>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from caixas");

            rs = sql.executeQuery();

            while (rs.next()) {

                Caixas c = new Caixas();
                c.setId_caixas(rs.getInt("id_caixas"));
                c.setDescricao(rs.getString("descricao"));
                caixa.add(c);
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (caixa);
    }

    public Caixas caixas(int numero) throws SQLException {

        Caixas c = new Caixas();
        int verifica = 0;
        PreparedStatement sql = conexao.prepareStatement("select * from caixas");
        ResultSet rs = null;
        rs = sql.executeQuery();

        while (rs.next()) {

            if (rs.getInt("id_caixas") == numero && numero > 0) {
                c.setId_caixas(rs.getInt("id_caixas"));
                c.setDescricao(rs.getString("descricao"));
                verifica = 1;
            } 
        }
         if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CAIXA NÃO CADASTRADO!");
         }
        return c;
    }
    
    public int caixas_busca(int numero) throws SQLException {

        Caixas c = new Caixas();
        int verifica = 0;
        PreparedStatement sql = conexao.prepareStatement("select * from caixas");
        ResultSet rs = null;
        rs = sql.executeQuery();

        while (rs.next()) {

            if (rs.getInt("id_caixas") == numero && numero > 0) {
                c.setId_caixas(rs.getInt("id_caixas"));
                c.setDescricao(rs.getString("descricao"));
                verifica = 1;
            } 
        }
         if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CAIXA NÃO CADASTRADO!");
         }
        return verifica;
    }
}
