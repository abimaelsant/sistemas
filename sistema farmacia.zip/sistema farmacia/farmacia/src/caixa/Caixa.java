package caixa;

public class Caixa {
    private int id_caixa;
    private int numCaixa;
    private float vendaAvista;
    private float vendaAprazo;
    private float vendaConvenio;
    private float vendaCartao;
    private float totalDiario;
    private float totalAcumulado;
    private String data_abertura;
    private String data_fechamento;
    private String flag;
    
    public Caixa(){}

    public Caixa(int id_caixa, int numCaixa, float vendaAvista, float vendaAprazo, float vendaConvenio, float vendaCartao, float totalDiario, float totalAcumulado, String data_abertura, String data_fechamento, String flag) {
        this.id_caixa = id_caixa;
        this.numCaixa = numCaixa;
        this.vendaAvista = vendaAvista;
        this.vendaAprazo = vendaAprazo;
        this.vendaConvenio = vendaConvenio;
        this.vendaCartao = vendaCartao;
        this.totalDiario = totalDiario;
        this.totalAcumulado = totalAcumulado;
        this.data_abertura = data_abertura;
        this.data_fechamento = data_fechamento;
        this.flag = flag;
    }

    public int getId_caixa() {
        return id_caixa;
    }

    public void setId_caixa(int id_caixa) {
        this.id_caixa = id_caixa;
    }

    public int getNumCaixa() {
        return numCaixa;
    }

    public void setNumCaixa(int numCaixa) {
        this.numCaixa = numCaixa;
    }

    public float getVendaAvista() {
        return vendaAvista;
    }

    public void setVendaAvista(float vendaAvista) {
        this.vendaAvista = vendaAvista;
    }

    public float getVendaAprazo() {
        return vendaAprazo;
    }

    public void setVendaAprazo(float vendaAprazo) {
        this.vendaAprazo = vendaAprazo;
    }

    public float getVendaConvenio() {
        return vendaConvenio;
    }

    public void setVendaConvenio(float vendaConvenio) {
        this.vendaConvenio = vendaConvenio;
    }

    public float getVendaCartao() {
        return vendaCartao;
    }

    public void setVendaCartao(float vendaCartao) {
        this.vendaCartao = vendaCartao;
    }

    public float getTotalDiario() {
        return totalDiario;
    }

    public void setTotalDiario(float totalDiario) {
        this.totalDiario = totalDiario;
    }

    public float getTotalAcumulado() {
        return totalAcumulado;
    }

    public void setTotalAcumulado(float totalAcumulado) {
        this.totalAcumulado = totalAcumulado;
    }

    public String getData_abertura() {
        return data_abertura;
    }

    public void setData_abertura(String data_abertura) {
        this.data_abertura = data_abertura;
    }

    public String getData_fechamento() {
        return data_fechamento;
    }

    public void setData_fechamento(String data_fechamento) {
        this.data_fechamento = data_fechamento;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
    
}
