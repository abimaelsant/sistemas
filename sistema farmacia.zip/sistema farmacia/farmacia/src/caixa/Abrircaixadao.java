package caixa;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Abrircaixadao {
       Conexao conexoes = new Conexao();
    Connection conexao;

    public Abrircaixadao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Abrircaixa c) throws SQLException, UnknownHostException, IOException {
        ResultSet rs = null;
      
            
            String s = "DELETE FROM abrir_caixa WHERE numCaixa=? ";
            //PreparedStatement s = conexao.prepareStatement("select * from caixa");
            PreparedStatement st = conexao.prepareStatement(s);

            st.setInt(1, c.getNumCaixa());
            st.execute();
            st.close();
            
            String sql = "INSERT INTO abrir_caixa(numCaixa, valor_abertura, data_abertura) VALUES(?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setInt(1, c.getNumCaixa());
            stmt.setFloat(2, c.getValor());
            stmt.setString(3, c.getData_abertura());
            
            stmt.execute();
            stmt.close();
            //JOptionPane.showMessageDialog(null, "OPERACAO REALIZADA COM SUCESSO!");       
    }

    public List<Abrircaixa> listar() throws SQLException {
        List<Abrircaixa> caixa = new ArrayList<Abrircaixa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from abrir_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Abrircaixa c = new Abrircaixa();
                c.setNumCaixa(rs.getInt("numCaixa"));
                c.setValor(rs.getFloat("valor_abertura"));
                c.setData_abertura(rs.getString("data_abertura"));
                caixa.add(c);
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (caixa);
    }    
    
    public List<Abrircaixa> listar_abrircaixa(int numero_caixa) throws SQLException {
        List<Abrircaixa> caixa = new ArrayList<Abrircaixa>();

        ResultSet rs = null;
        int verifica = 0;
        try {

            PreparedStatement sql = conexao.prepareStatement("select * from abrir_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getInt("numCaixa") == numero_caixa){
                Abrircaixa c = new Abrircaixa();
                c.setNumCaixa(rs.getInt("numCaixa"));
                c.setValor(rs.getFloat("valor_abertura"));
                c.setData_abertura(rs.getString("data_abertura"));
                caixa.add(c);
                verifica = 1;
              }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CAIXA NÃO FOI ABERTO!");
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (caixa);
    }
    public int listar_ver(int numero_caixa) throws SQLException {
        ResultSet rs = null;
        int verifica = 0;
        try {

            PreparedStatement sql = conexao.prepareStatement("select * from abrir_caixa");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getInt("numCaixa") == numero_caixa){
                Abrircaixa c = new Abrircaixa();
                c.setNumCaixa(rs.getInt("numCaixa"));
                c.setValor(rs.getFloat("valor_abertura"));
                c.setData_abertura(rs.getString("data_abertura"));
                verifica = 1;
              }
            }
        
        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (verifica);
    }    
}
