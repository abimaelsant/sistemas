package venda;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Vendadao {
    Conexao conexoes = new Conexao();
    Connection conexao;

    public Vendadao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Venda v) throws SQLException, UnknownHostException, IOException {
        ResultSet rs = null;
        int verifica = 0;
        try {
            String sql = "INSERT INTO venda(tipo_venda, cpf_cliente, id_forma_pagamento, id_produto, nome_prod, quantidade, data_venda, acrescimo, desconto, valor_venda, id_funcionario, numCaixa, numeroEfc, numeroCf) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement s = conexao.prepareStatement("select * from venda");

        rs = s.executeQuery();

        while (rs.next()) {
            if (v.getId_venda() == rs.getInt("id_venda")) {
                verifica = 1;
            }
        }
        if (verifica == 0) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, v.getTipo_venda());
            stmt.setString(2, v.getCpf_cliente());
            stmt.setInt(3, v.getId_forma_pagamento());
            stmt.setString(4, v.getId_produto());
            stmt.setString(5, v.getNome_prod());
            stmt.setInt(6, v.getQuantidade());
            stmt.setString(7, v.getData_venda());
            stmt.setFloat(8, v.getAcrescimo());
            stmt.setFloat(9, v.getDesconto());
            stmt.setFloat(10, v.getValor_venda());
            stmt.setInt(11, v.getId_funcionario());
            stmt.setInt(12, v.getNumCaixa());
            stmt.setInt(13, v.getNumeroEFC());
            stmt.setInt(14, v.getNumeroCF());

            stmt.execute();
            stmt.close();
      }else{
        }
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Venda v) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE venda set tipo_venda=?, cpf_cliente=?, id_forma_pagamento=?, id_produto=?, quantidade=?, data_venda=?, acrescimo=?, desconto=?, valor_venda=?, id_funcionario=?, numCaixa=?, numeroEfc=?, numeroCf=? where id_venda=?";
        PreparedStatement s = conexao.prepareStatement("select * from venda");

        rs = s.executeQuery();

        while (rs.next()) {
            if (v.getId_venda() == rs.getInt("id_venda")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, v.getTipo_venda());
            stmt.setString(2, v.getCpf_cliente());
            stmt.setInt(3, v.getId_forma_pagamento());
            stmt.setString(4, v.getId_produto());
            stmt.setInt(5, v.getQuantidade());
            stmt.setString(6, v.getData_venda());
            stmt.setFloat(7, v.getAcrescimo());
            stmt.setFloat(8, v.getDesconto());
            stmt.setFloat(9, v.getValor_venda());
            stmt.setInt(10, v.getId_funcionario());
            stmt.setInt(11, v.getNumCaixa());
            stmt.setInt(12, v.getNumeroEFC());
            stmt.setInt(13, v.getNumeroCF());
            stmt.setInt(14, v.getId_venda());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "VENDA EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "VENDA NÃO CADASTRADA!");
        }

    }

    public void excluir(Venda v) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM venda WHERE id_venda=? ";
        PreparedStatement s = conexao.prepareStatement("select * from venda");

        rs = s.executeQuery();

        while (rs.next()) {
            if (v.getId_venda() == rs.getInt("id_venda")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, v.getId_venda());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "VENDA DELETADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "VENDA NÃO CADASTRADA!");
        }

    }

    public List<Venda> listar() throws SQLException {
        List<Venda> venda = new ArrayList<Venda>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from venda");

            rs = sql.executeQuery();

            while (rs.next()) {

                Venda v = new Venda();
                v.setId_venda(rs.getInt("id_venda"));
                v.setTipo_venda(rs.getString("tipo_venda"));
                v.setCpf_cliente(rs.getString("cpf_cliente"));
                v.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                v.setId_produto(rs.getString("id_produto"));
                v.setNome_prod(rs.getString("nome_prod"));
                v.setQuantidade(rs.getInt("quantidade"));
                v.setData_venda(rs.getString("data_venda"));
                v.setAcrescimo(rs.getFloat("acrescimo"));
                v.setDesconto(rs.getFloat("desconto"));
                v.setValor_venda(rs.getFloat("valor_venda"));
                v.setId_funcionario(rs.getInt("id_funcionario"));
                v.setNumCaixa(rs.getInt("numCaixa"));
                v.setNumeroEFC(rs.getInt("numeroEfc"));
                v.setNumeroCF(rs.getInt("numeroCf"));
                venda.add(v);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (venda);
    }
}
