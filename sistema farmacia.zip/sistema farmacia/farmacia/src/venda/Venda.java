package venda;

public class Venda {
    private int id_venda;
    private String tipo_venda;
    private String cpf_cliente;
    private int id_forma_pagamento;
    private String codigo_produto;
    private int quantidade;
    private String data_venda;
    private float acrescimo;
    private float desconto;
    private float valor_venda;
    private int id_funcionario;
    private int numCaixa;
    private int numeroEFC;
    private int numeroCF;
    private String nome_prod;
    private float val_parcial;
    private float val_total;
    public Venda(){}

   
    public int getId_venda() {
        return id_venda;
    }

    public void setId_venda(int id_venda) {
        this.id_venda = id_venda;
    }

    public String getTipo_venda() {
        return tipo_venda;
    }

    public void setTipo_venda(String tipo_venda) {
        this.tipo_venda = tipo_venda;
    }

    public String getCpf_cliente() {
        return cpf_cliente;
    }

    public void setCpf_cliente(String cpf_cliente) {
        this.cpf_cliente = cpf_cliente;
    }

    public int getId_forma_pagamento() {
        return id_forma_pagamento;
    }

    public void setId_forma_pagamento(int id_forma_pagamento) {
        this.id_forma_pagamento = id_forma_pagamento;
    }

    public String getId_produto() {
        return codigo_produto;
    }

    public void setId_produto(String id_produto) {
        this.codigo_produto = id_produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getData_venda() {
        return data_venda;
    }

    public void setData_venda(String data_venda) {
        this.data_venda = data_venda;
    }

    public float getAcrescimo() {
        return acrescimo;
    }

    public void setAcrescimo(float acrescimo) {
        this.acrescimo = acrescimo;
    }

    public float getDesconto() {
        return desconto;
    }

    public void setDesconto(float desconto) {
        this.desconto = desconto;
    }

    public float getValor_venda() {
        return valor_venda;
    }

    public void setValor_venda(float valor_venda) {
        this.valor_venda = valor_venda;
    }

    public int getId_funcionario() {
        return id_funcionario;
    }

    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    public int getNumCaixa() {
        return numCaixa;
    }

    public void setNumCaixa(int numCaixa) {
        this.numCaixa = numCaixa;
    }

    public int getNumeroEFC() {
        return numeroEFC;
    }

    public void setNumeroEFC(int numeroEFC) {
        this.numeroEFC = numeroEFC;
    }

    public int getNumeroCF() {
        return numeroCF;
    }

    public void setNumeroCF(int numeroCF) {
        this.numeroCF = numeroCF;
    }

    public String getNome_prod() {
        return nome_prod;
    }

    public void setNome_prod(String nome_prod) {
        this.nome_prod = nome_prod;
    }

    public float getVal_parcial() {
        return val_parcial;
    }

    public void setVal_parcial(float val_parcial) {
        this.val_parcial = val_parcial;
    }

    public float getVal_total() {
        return val_total;
    }

    public void setVal_total(float val_total) {
        this.val_total = val_total;
    }
    
    
    
}
