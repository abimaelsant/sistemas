/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package venda;

import caixa.Caixas;
import caixa.Caixasdao;
import cliente.Cliente;
import cliente.Clientedao;
import cliente.PesquisarCliente;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import contas_pagar.Contas_pagar;
import contas_pagar.Contas_pagardao;
import contas_receber.Contas_receber;
import contas_receber.Contas_receberdao;
import empresa.Empresa;
import empresa.Empresadao;
import farmacia.FarmaciaSI;
import forma_pagamento.Forma_pagamento;
import forma_pagamento.Forma_pagamentodao;
import fornecedor.Fornecedor;
import fornecedor.Fornecedordao;
import funcionario.Funcionario;
import funcionario.Funcionariodao;
import funcionario_comissao.Funcionario_comissao;
import funcionario_comissao.Funcionario_comissaodao;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import static java.lang.System.in;
import static java.lang.System.out;
import static java.lang.Thread.sleep;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.ServiceUI;
import javax.print.SimpleDoc;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import laboratorio.Laboratorio;
import laboratorio.Laboratoriodao;
import produto.PesquisarProduto;
import produto.Produto;
import produto.ProdutoSI;
import produto.Produtodao;
import venda_caixa.Caixa_aberto_fechado;
import venda_caixa.Venda_caixa;
import venda_caixa.Venda_caixadao;

/**
 *
 * @author Abimael
 */
public class VendaSI extends javax.swing.JInternalFrame {

    /**
     * Creates new form VendaSI
     */
    public VendaSI() {
        initComponents();
        //geral.setEnabled(false);
        Color color = new Color(211, 211, 211);
        id_prod.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                // Anuncie aqui! Viu como funciona?  
            }

            public void insertUpdate(DocumentEvent e) {
                if (!id_prod.getText().isEmpty() && id_prod.getText().length() == 13) {
                    buscaProdutoPorCodigo(id_prod.getText());
                    qtde.requestFocus();
                }
            }
            public void removeUpdate(DocumentEvent e) {
                //buscaProdutoPorCodigo(id_prod.getText());
            }

            public void buscaProdutoPorCodigo(String codigoStr) {
                try {
                    try {
                        Caixa_aberto_fechado caf = new Caixa_aberto_fechado();
                        int teste = caf.status();
                        if (teste == 1) {
                            Produtodao daop = new Produtodao();
                            Caixasdao daoc = new Caixasdao();
                            Caixas caixas = new Caixas();
                            Produto produto = new Produto();
                            Venda v = new Venda();

                            int numCaixa = 0, qtde_p = 0;
                            String id_produ = "";
                            numCaixa = 1;
                            if (!id_prod.getText().isEmpty()) {
                                id_produ = id_prod.getText();
                            }
                            if (!qtde.getText().isEmpty()) {
                                qtde_p = Integer.parseInt(qtde.getText());
                            }
                            id_caixa = numCaixa;
                            caixas = daoc.caixas(numCaixa);
                            if (caixas.getId_caixas() == numCaixa) {
                                produto = daop.produto_cod(id_produ);
                                if (produto.getCodigo_produto().equals(id_produ)) {
                                    if (produto.getQuantidade_estoque() >= qtde_p) {
                                        v.setId_produto(id_produ);
                                        v.setNome_prod(produto.getNome());
                                        v.setQuantidade(qtde_p);
                                        v.setVal_parcial((produto.getValor_venda() * (qtde_p)));
                                        
                                        int ver = 0;
                                        for (int i = 0; i < venda.size(); i++) {
                                            if (venda.get(i).getId_produto().equals(id_produ)) {
                                                ver = 1;
                                            }
                                        }
                                        if (ver == 0) {
                                            total = total + v.getVal_parcial();
                                            v.setVal_total(total);
                                            venda.add(v);
                                        } else {
                                            ver = 0;
                                            JOptionPane.showMessageDialog(null, "PRODUTO JÁ INSERIDO!");
                                        }
                                        DefaultTableModel table = new DefaultTableModel();
                                        table = (DefaultTableModel) tabela.getModel();
                                        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
                                        tabela.updateUI();
                                        DecimalFormat df = new DecimalFormat("0.00");
                                        for (int i = 0; i < venda.size(); i++) {
                                            table.addRow(new Object[]{venda.get(i).getNome_prod(), venda.get(i).getQuantidade(), df.format(venda.get(i).getVal_parcial())});
                                            float vt = total;
                                            valt.setText(String.valueOf(df.format(vt)));
                                        }
                                    } else {
                                        JOptionPane.showMessageDialog(null, "QUANTIDADE NÃO EXISTENTE EM ESTOQUE! EXISTE(M) APENAS " + produto.getQuantidade_estoque() + " NO ESTOQUE");

                                    }
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "CAIXA NÃO FOI ABERTO! ABRA O CAIXA PARA REALIZAR VENDAS!");
                        }
             
                    } catch (SQLException ex) {
                        Logger.getLogger(VendaSI.class
                                .getName()).log(Level.SEVERE, null, ex);
                    }
                } catch (NumberFormatException nfex) {
                    // exibe mensagem dizendo que o código é inválido.  
                }
            }
        });
    }
    int test1 = 0;

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        qtde = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        cpf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        desc = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        id_f = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        efc = new javax.swing.JTextField();
        cf = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        v_r = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        vv = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        troco = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        d = new javax.swing.JFormattedTextField();
        jLabel16 = new javax.swing.JLabel();
        id_ret = new javax.swing.JTextField();
        jButton11 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        valt = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton13 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        id_prod = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        entrar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        nprodut = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        vpar = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        b4 = new javax.swing.JButton();

        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/far.jpg"))); // NOI18N
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Código do Produto:   ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Quantidade:  ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        qtde.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                qtdeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                qtdeFocusLost(evt);
            }
        });
        qtde.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                qtdeKeyPressed(evt);
            }
        });
        getContentPane().add(qtde, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 170, 40));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 51, 153));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/Adicionar Valores.png"))); // NOI18N
        jButton1.setText("Adicionar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 140, -1));

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Quantidade", "Val Parcial"
            }
        ));
        jScrollPane1.setViewportView(tabela);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 740, 120));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("CPF do Cliente/CNPJ:   ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, -1));
        getContentPane().add(cpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 310, 140, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Desconto:  ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, -1, -1));
        getContentPane().add(desc, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 140, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Nº do Funcionário: ");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, -1, -1));
        getContentPane().add(id_f, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 400, 140, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Número EFC:  ");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Número CF:  ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 500, -1, -1));
        getContentPane().add(efc, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 450, 140, 30));
        getContentPane().add(cf, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 500, 140, 30));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 51, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/confirma.png"))); // NOI18N
        jButton2.setMnemonic('v');
        jButton2.setText("Venda à Vista");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 550, -1, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 51, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/save 2.png"))); // NOI18N
        jButton3.setMnemonic('p');
        jButton3.setText("Venda  à Prazo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 550, -1, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 51, 153));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 4.png"))); // NOI18N
        jButton4.setMnemonic('c');
        jButton4.setText("Venda por Convênio");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 550, -1, 40));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 610, 30, 10));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 51, 153));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 4.png"))); // NOI18N
        jButton5.setMnemonic('t');
        jButton5.setText("Venda no Cartão");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 550, -1, 40));

        jButton6.setBackground(new java.awt.Color(255, 255, 255));
        jButton6.setForeground(new java.awt.Color(255, 0, 51));
        jButton6.setText("Sair");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 0, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Valor recebido:  ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 40, -1, -1));
        getContentPane().add(v_r, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 30, 110, 30));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Valor da Venda:  ");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 80, -1, -1));
        getContentPane().add(vv, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 70, 110, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Troco:  ");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 150, -1, -1));
        getContentPane().add(troco, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 150, 110, 30));

        jButton8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 51, 153));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/calcu 1.png"))); // NOI18N
        jButton8.setText("Calcular");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 110, 130, 30));

        jButton9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(0, 51, 153));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit_clear.png"))); // NOI18N
        jButton9.setText("Limpar");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 170, -1));

        jButton10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(0, 51, 153));
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit_clear2.png"))); // NOI18N
        jButton10.setText("Limpar tabela");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 160, 40));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("Data Venc Prazo/Convênio:  ");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 510, -1, -1));

        try {
            d.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        getContentPane().add(d, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 500, 80, 30));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("Nome do Prod:  ");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 320, -1, -1));
        getContentPane().add(id_ret, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 310, 120, 30));

        jButton11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton11.setForeground(new java.awt.Color(0, 51, 153));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/delete 1.png"))); // NOI18N
        jButton11.setText("Retirar Produto ");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(511, 350, 220, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable1);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 300, 230, 90));

        valt.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        valt.setForeground(new java.awt.Color(0, 51, 153));
        valt.setCaretColor(new java.awt.Color(0, 51, 204));
        valt.setDisabledTextColor(new java.awt.Color(0, 0, 102));
        valt.setEnabled(false);
        valt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valtActionPerformed(evt);
            }
        });
        getContentPane().add(valt, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 430, 170, 100));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(jTable3);

        getContentPane().add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 20, 230, 160));

        jButton13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton13.setForeground(new java.awt.Color(0, 51, 153));
        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/pesquisa 2.png"))); // NOI18N
        jButton13.setText("Pesquisar Cliente ");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 200, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("TOTAL:  ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 400, -1, -1));

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 51, 153));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 2.png"))); // NOI18N
        jButton7.setText("Pesquisar Prod");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, 170, 40));

        jButton12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(0, 51, 153));
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/calcu 2.png"))); // NOI18N
        jButton12.setText("Dívidas do Cliente");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 310, 200, 30));

        id_prod.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                id_prodFocusGained(evt);
            }
        });
        getContentPane().add(id_prod, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 170, 40));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 0));
        jLabel7.setText("Atalhos:  alt + v => venda à vista;   alt + p => venda à prazo;  alt + c => venda por convênio;  alt + t => venda no cartão. ");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 600, -1, -1));

        entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarActionPerformed(evt);
            }
        });
        getContentPane().add(entrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 30, 10));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Nome do Prod:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, -1, -1));

        nprodut.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nprodutKeyPressed(evt);
            }
        });
        getContentPane().add(nprodut, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 80, 30));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("Valor:  ");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, -1, -1));

        vpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vparActionPerformed(evt);
            }
        });
        getContentPane().add(vpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 80, 30));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 0, 51));
        jLabel18.setText("Para produtos sem código de barras");
        getContentPane().add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, -1, -1));

        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });
        getContentPane().add(b4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    ArrayList<Venda> venda = new ArrayList<>();
    float total = 0;
    int id_caixa = 0;

    public void add(int t) {
        test1 = t;
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int tam = venda.size();
        if (tam > 0) {

            try {
                int id_forma_p = 2, id_fun = 0, efc_v = 0, cf_v = 0, verc = 0, verf = 0, verifica_c = 0, verifica_f = 0, testando1 = 0;
                float des = 0, comissaof = 0;
                Contas_receberdao crdao = new Contas_receberdao();
                Vendadao daov = new Vendadao();
                Venda v = new Venda();
                Venda_caixadao daovc = new Venda_caixadao();
                Venda_caixa vc = new Venda_caixa();
                Clientedao daoc = new Clientedao();
                Cliente cliente = new Cliente();
                Forma_pagamentodao daofp = new Forma_pagamentodao();
                Forma_pagamento fp = new Forma_pagamento();
                Funcionariodao daof = new Funcionariodao();
                Funcionario f = new Funcionario();
                Produtodao daop = new Produtodao();
                Produto prod = new Produto();
                Calendar cal = Calendar.getInstance();
                int dia = cal.get(Calendar.DATE);
                int mes = cal.get(Calendar.MONTH) + 1;
                int ano = cal.get(Calendar.YEAR);
                String zero_d = "", zero_m = "";
                if (dia < 10) {
                    zero_d = "0";
                }
                if (mes < 10) {
                    zero_m = "0";
                }
                String data = String.valueOf(zero_d + dia) + "/" + String.valueOf(zero_m + mes) + "/" + String.valueOf(ano);
                if (!id_f.getText().isEmpty()) {
                    id_fun = Integer.parseInt(id_f.getText());
                }
                if (!desc.getText().isEmpty()) {
                    des = Float.parseFloat(desc.getText());
                }
                if (!efc.getText().isEmpty()) {
                    efc_v = Integer.parseInt(efc.getText());
                }
                if (!cf.getText().isEmpty()) {
                    cf_v = Integer.parseInt(cf.getText());
                }
                v.setCpf_cliente(cpf.getText());
                v.setId_forma_pagamento(id_forma_p);
                v.setId_funcionario(id_fun);
                //v.setAcrescimo(ac);
                v.setDesconto(des);
                v.setNumeroEFC(efc_v);
                v.setNumeroCF(cf_v);
                Cliente c_cli = new Cliente();
                float val_total = 0, valorT = 0, valor_dis = 0;
                if (!cpf.getText().isEmpty()) {
                    valorT = crdao.valor(cpf.getText());
                    c_cli = daoc.pesquisac(cpf.getText());
                    valor_dis = c_cli.getValorMax();
                    val_total = valorT + (total - des);
                }
                if (val_total <= c_cli.getValorMax()) {
                    if (cpf.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "O CPF DO CLIENTE É OBRIGATÓRIO!");
                    }
                    fp = daofp.forma_p(id_forma_p);
                    if (!cpf.getText().isEmpty()) {
                        cliente = daoc.pesquisa(cpf.getText());
                        verc = 2;
                        if (cliente.getCpf().equals(cpf.getText())) {
                            verc = 1;
                        }
                    }
                    if (id_fun > 0) {
                        verf = 2;

                        f = daof.funcionario(id_fun);
                        if (f.getId_funcionario() == id_fun) {
                            verf = 1;
                        }
                    }
                    if (verc == 1 && verf != 2) {
                        if (verf == 1) {
                            verifica_c = 1;
                            verifica_f = 1;
                            for (int i = 0; i < venda.size(); i++) {
                                v.setCpf_cliente(cpf.getText());
                                v.setId_funcionario(id_fun);
                                v.setId_forma_pagamento(id_forma_p);
                                v.setId_produto(venda.get(i).getId_produto());
                                v.setNome_prod(venda.get(i).getNome_prod());
                                v.setQuantidade(venda.get(i).getQuantidade());
                                v.setData_venda(data);
                               if(!venda.get(i).getId_produto().equals("1")){
                                prod = daop.produto_cod(venda.get(i).getId_produto());
                                comissaof = comissaof + prod.getComissao();
                               }
                                v.setValor_venda(venda.get(i).getVal_parcial());
                                v.setId_funcionario(id_fun);
                                v.setNumCaixa(id_caixa);
                                daov.cadastro(v);
                               if(!venda.get(i).getId_produto().equals("1")){
                                int q = prod.getQuantidade_estoque();
                                prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                                daop.altera_cod(prod);
                               }
                            }
                            JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");

                        }
                        if (verf == 0) {
                            for (int i = 0; i < venda.size(); i++) {
                                v.setCpf_cliente(cpf.getText());
                                v.setId_produto(venda.get(i).getId_produto());
                                v.setNome_prod(venda.get(i).getNome_prod());
                                v.setQuantidade(venda.get(i).getQuantidade());
                                v.setId_forma_pagamento(id_forma_p);
                                v.setData_venda(data);
                                 if(!venda.get(i).getId_produto().equals("1")){
                                prod = daop.produto_cod(venda.get(i).getId_produto());
                                //JOptionPane.showMessageDialog(null, venda.get(i).getId_produto() + " ---- "+prod.getCodigo_produto());
                                comissaof = comissaof + prod.getComissao();
                                 }
                                v.setValor_venda(venda.get(i).getVal_parcial());
                                v.setId_funcionario(id_fun);
                                v.setNumCaixa(id_caixa);

                                daov.cadastro(v);
                                 if(!venda.get(i).getId_produto().equals("1")){
                                int q = prod.getQuantidade_estoque();
                                prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                                daop.altera_cod(prod);
                                 }
                            }
                            JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");
                        }

                        Contas_receberdao daocr = new Contas_receberdao();
                        Contas_receber cr = new Contas_receber();
                        cr.setData_venda(data);
                        cr.setCpf_cliente(cpf.getText());
                        String val = JOptionPane.showInputDialog(null, "VALOR RECEBIDO:  ");
                        float valor_r = 0;
                        valor_r = Float.parseFloat(val);
                        cr.setValor_receber((total - (des)) - valor_r);
                        cr.setValor_recebido(valor_r);
                        String d_v = d.getText();
                        cr.setData_vcto(d_v);
                        String n_p = JOptionPane.showInputDialog(null, "NÚMERO DE PRESTAÇÕES:  ");
                        int n_prest = Integer.parseInt(n_p);
                        cr.setNumero_prestacao(n_prest);
                        cr.setId_forma_pagamento(id_forma_p);
                        daocr.cadastro(cr);
                        Venda_caixadao venda_c = new Venda_caixadao();
                        Venda_caixa venda_caixa = new Venda_caixa();
                        venda_caixa.setData_venda(data);
                        venda_caixa.setNumCaixa(id_caixa);
                        if (verc == 1) {
                            venda_caixa.setCpf_cliente(cpf.getText());
                        }
                        venda_caixa.setId_forma_pagamento(id_forma_p);
                        venda_caixa.setValor_venda(total - (des));
                        venda_caixa.setValor_pago(valor_r);
                        venda_c.cadastro(venda_caixa);
                        if (id_fun > 0) {
                            Funcionario_comissaodao daofc = new Funcionario_comissaodao();
                            Funcionario_comissao fc = new Funcionario_comissao();
                            fc.setId_funcionario(id_fun);
                            fc.setValor_comissao(comissaof);
                            fc.setMes(mes);
                            fc.setAno(ano);
                            daofc.cadastro(fc);
                        }
                        //_________________________________________________________________________________

                        PrintService[] printService = PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.AUTOSENSE, null);
                        System.out.println("Quantas Impressoras:  " + printService.length);
                        PrintService impressoraPadrao = PrintServiceLookup.lookupDefaultPrintService();
                        System.out.println("A impressora padrão é:  " + impressoraPadrao.getName());
                        DocFlavor docFlavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
                        HashDocAttributeSet hashDocAttributeSet = new HashDocAttributeSet();
                        Document document = new Document();
                        Date dd = new Date();
                        String t = String.valueOf(dd.getDay() + "" + dd.getMonth() + "" + dd.getYear() + "" + dd.getHours() + "" + "" + dd.getMinutes() + "" + "" + dd.getSeconds());
                        System.out.println("data:  " + dd.getTime());
                        String nome = "C:\\Users\\Abimael\\Documents\\comprovantes vendas/comprovante" + t + ".pdf";
                        DecimalFormat df = new DecimalFormat("0.00");

                        PdfWriter.getInstance(document, new FileOutputStream(nome));
                        document.open();

                        // adicionando um parágrafo no documento
                        document.add(new Paragraph("COMPROVANTE DE VENDA A PRAZO\n" + "--------------------------------------------------------------" + "\n"));
                        document.add(new Paragraph("CPF do Cliente -----  Nome do Cliente :   "));
                        document.add(new Paragraph(cliente.getCpf() + " -----------  " + " " + cliente.getNome() + "\n"));
                        document.add(new Paragraph("Id do Funcionario -----  Nome do Funcionario :   "));
                        document.add(new Paragraph(f.getId_funcionario() + " --------  " + " " + f.getNome() + "\n"));
                        document.add(new Paragraph("Nome (s) do (s) Produtos ------ Preço -----Quantidade  :  "));
                        for (int i = 0; i < venda.size(); i++) {

                            document.add(new Paragraph(venda.get(i).getNome_prod() + "  ------ " + "  " + " " + df.format(venda.get(i).getVal_parcial()) + " " + " ------- " + " " + venda.get(i).getQuantidade()));
                        }
                        document.add(new Paragraph("VALOR TOTAL --------- VALOR RECEBIDO  :    "));
                        document.add(new Paragraph(df.format(total - (des)) + " ---------  " + valor_r));
                        document.add(new Paragraph("NÚMERO DE PRESTAÇÕES  :    "));
                        document.add(new Paragraph("" + n_prest + ""));
                        document.add(new Paragraph("Data de Vencimento:   "));
                        document.add(new Paragraph(d.getText() + "\n"));
                        document.add(new Paragraph("Data da Venda:   "));
                        document.add(new Paragraph(data + "\n"));

                        document.close();
                        FileInputStream fileInputStream = new FileInputStream(nome);
                        Doc doc = new SimpleDoc(fileInputStream, docFlavor, hashDocAttributeSet);
                        PrintRequestAttributeSet printResquestAttributeSet = new HashPrintRequestAttributeSet();
                        PrintService printServico = ServiceUI.printDialog(null, 300, 200, printService, impressoraPadrao, docFlavor, printResquestAttributeSet);
                        if (printServico != null) {
                            DocPrintJob docPrintJob = printServico.createPrintJob();
                            docPrintJob.print(doc, printResquestAttributeSet);
                        }

//_________________________________________________________________________________
                        float vt = 0;
                        vt = total - (des);

                        DecimalFormat dff = new DecimalFormat("0.00");

                        valt.setText(String.valueOf(dff.format(vt)));
                        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
                        tabela.updateUI();
                        venda.clear();
                        total = 0;
                    }
                } else {
                    float vall = valor_dis - valorT;
                    JOptionPane.showMessageDialog(null, "DADOS DO CLIENTE ESTÁ INCORRETO, VERIFIQUE O CPF E SEU VALOR PERMITIDO PARA COMPRA A PRAZO.\n VALOR DE COMPRA A PRAZO PARA ESSE CLIENTE É DE: " + vall);
                }

            } catch (SQLException | IOException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DocumentException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (PrintException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else {
            JOptionPane.showMessageDialog(null, "NENHUM PRODUTO FOI ADICIONADO PARA VENDA!");
        }
    

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int tam = venda.size();
        if (tam > 0) {
            try {
                int id_forma_p = 3, id_fun = 0, efc_v = 0, cf_v = 0, verc = 0, verf = 0, verifica_c = 0, verifica_f = 0;
                float des = 0, comissaof = 0;
                Vendadao daov = new Vendadao();
                Venda v = new Venda();
                Venda_caixadao daovc = new Venda_caixadao();
                Venda_caixa vc = new Venda_caixa();
                Empresadao daoe = new Empresadao();
                Empresa empresa = new Empresa();
                Forma_pagamentodao daofp = new Forma_pagamentodao();
                Forma_pagamento fp = new Forma_pagamento();
                Funcionariodao daof = new Funcionariodao();
                Funcionario f = new Funcionario();
                Produtodao daop = new Produtodao();
                Produto prod = new Produto();
                Calendar cal = Calendar.getInstance();
                int dia = cal.get(Calendar.DATE);
                int mes = cal.get(Calendar.MONTH) + 1;
                int ano = cal.get(Calendar.YEAR);
                String zero_d = "", zero_m = "";
                if (dia < 10) {
                    zero_d = "0";
                }
                if (mes < 10) {
                    zero_m = "0";
                }
                String data = String.valueOf(zero_d + dia) + "/" + String.valueOf(zero_m + mes) + "/" + String.valueOf(ano);
                if (!id_f.getText().isEmpty()) {
                    id_fun = Integer.parseInt(id_f.getText());
                }
                if (!desc.getText().isEmpty()) {
                    des = Float.parseFloat(desc.getText());
                }
                if (!efc.getText().isEmpty()) {
                    efc_v = Integer.parseInt(efc.getText());
                }
                if (!cf.getText().isEmpty()) {
                    cf_v = Integer.parseInt(cf.getText());
                }
                v.setCpf_cliente(cpf.getText());
                v.setId_forma_pagamento(id_forma_p);
                v.setId_funcionario(id_fun);
                //v.setAcrescimo(ac);
                v.setDesconto(des);
                v.setNumeroEFC(efc_v);
                v.setNumeroCF(cf_v);
                if (cpf.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "O CPF/CNPJ DO CLIENTE É OBRIGATÓRIO!");
                }
                fp = daofp.forma_p(id_forma_p);
                if (!cpf.getText().isEmpty()) {
                    empresa = daoe.pesquisacnpj(cpf.getText());
                    verc = 2;
                    if (empresa.getCnpj().equals(cpf.getText())) {
                        verc = 1;
                    }
                }
                if (id_fun > 0) {
                    verf = 2;

                    f = daof.funcionario(id_fun);
                    if (f.getId_funcionario() == id_fun) {
                        verf = 1;
                    }
                }
                if (verc == 1 && verf != 2) {
                    if (verf == 1) {
                        verifica_c = 1;
                        verifica_f = 1;
                        for (int i = 0; i < venda.size(); i++) {
                            v.setCpf_cliente(cpf.getText());
                            v.setId_funcionario(id_fun);
                            v.setId_forma_pagamento(id_forma_p);
                            v.setId_produto(venda.get(i).getId_produto());
                            v.setNome_prod(venda.get(i).getNome_prod());
                            v.setQuantidade(venda.get(i).getQuantidade());
                            v.setData_venda(data);
                             if(!venda.get(i).getId_produto().equals("1")){
                            prod = daop.produto_cod(venda.get(i).getId_produto());
                            comissaof = comissaof + prod.getComissao();
                             }
                            v.setValor_venda(venda.get(i).getVal_parcial());
                            v.setId_funcionario(id_fun);
                            v.setNumCaixa(id_caixa);
                            daov.cadastro(v);
                             if(!venda.get(i).getId_produto().equals("1")){
                            int q = prod.getQuantidade_estoque();
                            prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                            daop.altera_cod(prod);
                             }
                        }
                        JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");

                    }
                    if (verf == 0) {
                        for (int i = 0; i < venda.size(); i++) {
                            v.setCpf_cliente(cpf.getText());
                            v.setId_produto(venda.get(i).getId_produto());
                            v.setNome_prod(venda.get(i).getNome_prod());
                            v.setQuantidade(venda.get(i).getQuantidade());
                            v.setId_forma_pagamento(id_forma_p);
                            v.setData_venda(data);
                            if(!venda.get(i).getId_produto().equals("1")){
                            prod = daop.produto_cod(venda.get(i).getId_produto());
                            comissaof = comissaof + prod.getComissao();
                            }
                            v.setValor_venda(venda.get(i).getVal_parcial());
                            v.setId_funcionario(id_fun);
                            v.setNumCaixa(id_caixa);

                            daov.cadastro(v);
                             if(!venda.get(i).getId_produto().equals("1")){
                            int q = prod.getQuantidade_estoque();
                            prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                            daop.altera_cod(prod);
                             }
                        }
                        JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");
                    }

                    Contas_receberdao daocr = new Contas_receberdao();
                    Contas_receber cr = new Contas_receber();
                    cr.setData_venda(data);
                    cr.setCpf_cliente(cpf.getText());
                    String val = JOptionPane.showInputDialog(null, "VALOR RECEBIDO:  ");

                    float valor_r = 0;
                    if (!val.isEmpty()) {
                        valor_r = Float.parseFloat(val);
                    }
                    cr.setValor_receber((total - (des)) - valor_r);
                    cr.setValor_recebido(valor_r);
                    String d_v = d.getText();
                    cr.setData_vcto(d_v);
                    String n_p = JOptionPane.showInputDialog(null, "NÚMERO DE PRESTAÇÕES:  ");
                    int n_prest = 0;
                    if (!n_p.isEmpty()) {
                        n_prest = Integer.parseInt(n_p);
                    }
                    cr.setNumero_prestacao(n_prest);
                    cr.setId_forma_pagamento(id_forma_p);
                    daocr.cadastro(cr);
                    Venda_caixadao venda_c = new Venda_caixadao();
                    Venda_caixa venda_caixa = new Venda_caixa();
                    venda_caixa.setData_venda(data);
                    venda_caixa.setNumCaixa(id_caixa);
                    venda_caixa.setId_forma_pagamento(id_forma_p);
                    venda_caixa.setValor_venda(total - (des));
                    venda_caixa.setValor_pago(valor_r);
                    venda_c.cadastro(venda_caixa);
                    if (id_fun > 0) {
                        Funcionario_comissaodao daofc = new Funcionario_comissaodao();
                        Funcionario_comissao fc = new Funcionario_comissao();
                        fc.setId_funcionario(id_fun);
                        fc.setValor_comissao(comissaof);
                        fc.setMes(mes);
                        fc.setAno(ano);
                        daofc.cadastro(fc);
                    }

                    //_________________________________________________________________________________
                    PrintService[] printService = PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.AUTOSENSE, null);
                    System.out.println("Quantas Impressoras:  " + printService.length);
                    PrintService impressoraPadrao = PrintServiceLookup.lookupDefaultPrintService();
                    System.out.println("A impressora padrão é:  " + impressoraPadrao.getName());
                    DocFlavor docFlavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
                    HashDocAttributeSet hashDocAttributeSet = new HashDocAttributeSet();
                    Document document = new Document();
                    Date dd = new Date();
                    String t = String.valueOf(dd.getDay() + "" + dd.getMonth() + "" + dd.getYear() + "" + dd.getHours() + "" + "" + dd.getMinutes() + "" + "" + dd.getSeconds());
                    System.out.println("data:  " + dd.getTime());
                    String nome = "C:\\Users\\Abimael\\Documents\\comprovantes vendas/comprovante" + t + ".pdf";
                    DecimalFormat df = new DecimalFormat("0.00");

                    PdfWriter.getInstance(document, new FileOutputStream(nome));
                    document.open();

                    // adicionando um parágrafo no documento
                    document.add(new Paragraph("COMPROVANTE DE VENDA A PRAZO\n" + "--------------------------------------------------------------" + "\n"));
                    document.add(new Paragraph("CNPJ do Cliente -----  Nome do Cliente :   "));
                    document.add(new Paragraph(empresa.getCnpj() + " -----------  " + " " + empresa.getNome() + "\n"));
                    document.add(new Paragraph("Id do Funcionario -----  Nome do Funcionario :   "));
                    document.add(new Paragraph(f.getId_funcionario() + " --------  " + " " + f.getNome() + "\n"));
                    document.add(new Paragraph("Nome (s) do (s) Produtos ------ Preço -----Quantidade  :  "));
                    for (int i = 0; i < venda.size(); i++) {

                        document.add(new Paragraph(venda.get(i).getNome_prod() + "  ------ " + "  " + " " + df.format(venda.get(i).getVal_parcial()) + " " + " ------- " + " " + venda.get(i).getQuantidade()));
                    }
                    document.add(new Paragraph("VALOR TOTAL --------- VALOR RECEBIDO  :    "));
                    document.add(new Paragraph(df.format(total - (des)) + " ---------  " + valor_r));
                    document.add(new Paragraph("NÚMERO DE PRESTAÇÕES  :    "));
                    document.add(new Paragraph("" + n_prest + ""));
                    document.add(new Paragraph("Data de Vencimento:   "));
                    document.add(new Paragraph(d.getText() + "\n"));
                    document.add(new Paragraph("Data da Venda:   "));
                    document.add(new Paragraph(data + "\n"));

                    document.close();
                    FileInputStream fileInputStream = new FileInputStream(nome);
                    Doc doc = new SimpleDoc(fileInputStream, docFlavor, hashDocAttributeSet);
                    PrintRequestAttributeSet printResquestAttributeSet = new HashPrintRequestAttributeSet();
                    PrintService printServico = ServiceUI.printDialog(null, 300, 200, printService, impressoraPadrao, docFlavor, printResquestAttributeSet);
                    if (printServico != null) {
                        DocPrintJob docPrintJob = printServico.createPrintJob();
                        docPrintJob.print(doc, printResquestAttributeSet);
                    }

//_________________________________________________________________________________
                    float vt = 0;
                    vt = total - (des);

                    DecimalFormat dff = new DecimalFormat("0.00");

                    valt.setText(String.valueOf(dff.format(vt)));
                 ((DefaultTableModel) tabela.getModel()).setNumRows(0);
                 tabela.updateUI();
                 venda.clear();
                 total = 0;
                }
            } catch (SQLException | IOException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DocumentException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (PrintException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "NENHUM PRODUTO FOI ADICIONADO PARA VENDA!");
        }
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        venda.clear();
        total = 0;

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        int tam = venda.size();
        if (tam > 0) {
            try {
                int id_forma_p = 0, id_fun = 0, efc_v = 0, cf_v = 0, verc = 0, verf = 0, verifica_c = 0, verifica_f = 0;
                float des = 0, comissaof = 0;
                Vendadao daov = new Vendadao();
                Venda v = new Venda();
                Venda_caixadao daovc = new Venda_caixadao();
                Venda_caixa vc = new Venda_caixa();
                Clientedao daoc = new Clientedao();
                Cliente cliente = new Cliente();
                Forma_pagamentodao daofp = new Forma_pagamentodao();
                Forma_pagamento fp = new Forma_pagamento();
                Funcionariodao daof = new Funcionariodao();
                Funcionario f = new Funcionario();
                Produtodao daop = new Produtodao();
                Produto prod = new Produto();
                Calendar cal = Calendar.getInstance();
                int dia = cal.get(Calendar.DATE);
                int mes = cal.get(Calendar.MONTH) + 1;
                int ano = cal.get(Calendar.YEAR);
                String zero_d = "", zero_m = "";
                if (dia < 10) {
                    zero_d = "0";
                }
                if (mes < 10) {
                    zero_m = "0";
                }
                String data = String.valueOf(zero_d + dia) + "/" + String.valueOf(zero_m + mes) + "/" + String.valueOf(ano);
                if (!id_f.getText().isEmpty()) {
                    id_fun = Integer.parseInt(id_f.getText());
                }
                if (!desc.getText().isEmpty()) {
                    des = Float.parseFloat(desc.getText());
                }
                if (!efc.getText().isEmpty()) {
                    efc_v = Integer.parseInt(efc.getText());
                }
                if (!cf.getText().isEmpty()) {
                    cf_v = Integer.parseInt(cf.getText());
                }
                UIManager.put("OptionPane.cancelButtonText", "Cancelar");
                UIManager.put("OptionPane.noButtonText", "Cartão de Débito");
                UIManager.put("OptionPane.yesButtonText", "Cartão de Crédito");
                int r = JOptionPane.showConfirmDialog(null, "TIPO DE CARTÃO? ", "Cartão", JOptionPane.YES_OPTION);

                if (r == 0) {
                    id_forma_p = 4;
                } else {
                    id_forma_p = 5;
                }

                v.setCpf_cliente(cpf.getText());
                v.setId_forma_pagamento(id_forma_p);
                v.setId_funcionario(id_fun);
                //v.setAcrescimo(ac);
                v.setDesconto(des);
                v.setNumeroEFC(efc_v);
                v.setNumeroCF(cf_v);
                if (cpf.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "O CPF DO CLIENTE É OBRIGATÓRIO!");
                }
                fp = daofp.forma_p(id_forma_p);
                if (!cpf.getText().isEmpty()) {
                    cliente = daoc.pesquisa(cpf.getText());
                    verc = 2;
                    if (cliente.getCpf().equals(cpf.getText())) {
                        verc = 1;
                    }
                }
                if (id_fun > 0) {
                    verf = 2;

                    f = daof.funcionario(id_fun);
                    if (f.getId_funcionario() == id_fun) {
                        verf = 1;
                    }
                }
                if (verc == 1 && verf != 2) {
                    if (verf == 1) {
                        verifica_c = 1;
                        verifica_f = 1;
                        for (int i = 0; i < venda.size(); i++) {
                            v.setCpf_cliente(cpf.getText());
                            v.setId_funcionario(id_fun);
                            v.setId_forma_pagamento(id_forma_p);
                            v.setId_produto(venda.get(i).getId_produto());
                            v.setNome_prod(venda.get(i).getNome_prod());
                            v.setQuantidade(venda.get(i).getQuantidade());
                            v.setData_venda(data);
                             if(!venda.get(i).getId_produto().equals("1")){
                            prod = daop.produto_cod(venda.get(i).getId_produto());
                            comissaof = comissaof + prod.getComissao();
                             }
                            v.setValor_venda(venda.get(i).getVal_parcial());
                            v.setId_funcionario(id_fun);
                            v.setNumCaixa(id_caixa);
                            daov.cadastro(v);
                             if(!venda.get(i).getId_produto().equals("1")){
                            int q = prod.getQuantidade_estoque();
                            prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                            daop.altera_cod(prod);
                             }
                        }
                        JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");

                    }
                    if (verf == 0) {
                        for (int i = 0; i < venda.size(); i++) {
                            v.setCpf_cliente(cpf.getText());
                            v.setId_produto(venda.get(i).getId_produto());
                            v.setNome_prod(venda.get(i).getNome_prod());
                            v.setQuantidade(venda.get(i).getQuantidade());
                            v.setId_forma_pagamento(id_forma_p);
                            v.setData_venda(data);
                             if(!venda.get(i).getId_produto().equals("1")){
                            prod = daop.produto_cod(venda.get(i).getId_produto());
                            comissaof = comissaof + prod.getComissao();
                             }
                            v.setValor_venda(venda.get(i).getVal_parcial());
                            v.setId_funcionario(id_fun);
                            v.setNumCaixa(id_caixa);

                            daov.cadastro(v);
                             if(!venda.get(i).getId_produto().equals("1")){
                            int q = prod.getQuantidade_estoque();
                            prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                            daop.altera_cod(prod);
                             }
                        }
                        JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");
                    }

                    Venda_caixadao venda_c = new Venda_caixadao();
                    Venda_caixa venda_caixa = new Venda_caixa();
                    venda_caixa.setData_venda(data);
                    venda_caixa.setNumCaixa(id_caixa);
                    if (verc == 1) {
                        venda_caixa.setCpf_cliente(cpf.getText());
                    }
                    venda_caixa.setId_forma_pagamento(id_forma_p);
                    venda_caixa.setValor_venda(total - (des));
                    venda_caixa.setValor_pago(total - (des));
                    venda_c.cadastro(venda_caixa);
                    if (id_fun > 0) {
                        Funcionario_comissaodao daofc = new Funcionario_comissaodao();
                        Funcionario_comissao fc = new Funcionario_comissao();
                        fc.setId_funcionario(id_fun);
                        fc.setValor_comissao(comissaof);
                        fc.setMes(mes);
                        fc.setAno(ano);
                        daofc.cadastro(fc);
                    }
                    //_________________________________________________________________________________

                    PrintService[] printService = PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.AUTOSENSE, null);
                    System.out.println("Quantas Impressoras:  " + printService.length);
                    PrintService impressoraPadrao = PrintServiceLookup.lookupDefaultPrintService();
                    System.out.println("A impressora padrão é:  " + impressoraPadrao.getName());
                    DocFlavor docFlavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
                    HashDocAttributeSet hashDocAttributeSet = new HashDocAttributeSet();
                    Document document = new Document();
                    Date dd = new Date();
                    String t = String.valueOf(dd.getDay() + "" + dd.getMonth() + "" + dd.getYear() + "" + dd.getHours() + "" + "" + dd.getMinutes() + "" + "" + dd.getSeconds());
                    System.out.println("data:  " + dd.getTime());
                    String nome = "C:\\Users\\Abimael\\Documents\\comprovantes vendas/comprovante" + t + ".pdf";
                    DecimalFormat df = new DecimalFormat("0.00");

                    PdfWriter.getInstance(document, new FileOutputStream(nome));
                    document.open();

                    // adicionando um parágrafo no documento
                    document.add(new Paragraph("COMPROVANTE DE VENDA A PRAZO\n" + "--------------------------------------------------------------" + "\n"));
                    document.add(new Paragraph("CPF do Cliente -----  Nome do Cliente :   "));
                    document.add(new Paragraph(cliente.getCpf() + " -----------  " + " " + cliente.getNome() + "\n"));
                    document.add(new Paragraph("Id do Funcionario -----  Nome do Funcionario :   "));
                    document.add(new Paragraph(f.getId_funcionario() + " --------  " + " " + f.getNome() + "\n"));
                    document.add(new Paragraph("Nome (s) do (s) Produtos ------ Preço -----Quantidade  :  "));
                    for (int i = 0; i < venda.size(); i++) {

                        document.add(new Paragraph(venda.get(i).getNome_prod() + "  ------ " + "  " + " " + df.format(venda.get(i).getVal_parcial()) + " " + " ------- " + " " + venda.get(i).getQuantidade()));
                    }
                    document.add(new Paragraph("VALOR TOTAL   :    "));
                    document.add(new Paragraph(df.format(total - (des))));
                    document.add(new Paragraph("Data da Venda:   "));
                    document.add(new Paragraph(data + "\n"));

                    document.close();
                    FileInputStream fileInputStream = new FileInputStream(nome);
                    Doc doc = new SimpleDoc(fileInputStream, docFlavor, hashDocAttributeSet);
                    PrintRequestAttributeSet printResquestAttributeSet = new HashPrintRequestAttributeSet();
                    PrintService printServico = ServiceUI.printDialog(null, 300, 200, printService, impressoraPadrao, docFlavor, printResquestAttributeSet);
                    if (printServico != null) {
                        DocPrintJob docPrintJob = printServico.createPrintJob();
                        docPrintJob.print(doc, printResquestAttributeSet);
                    }

//_________________________________________________________________________________
                    float vt = 0;
                    vt = total - (des);
                    DecimalFormat dff = new DecimalFormat("0.00");

                    valt.setText(String.valueOf(dff.format(vt)));
                    ((DefaultTableModel) tabela.getModel()).setNumRows(0);
                    tabela.updateUI();
                    venda.clear();
                    total = 0;
                }
            } catch (SQLException | IOException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DocumentException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (PrintException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "NENHUM PRODUTO FOI ADICIONADO PARA VENDA!");
        }
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        venda.clear();
        total = 0;

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        try {
            Caixa_aberto_fechado caf = new Caixa_aberto_fechado();
            int teste = caf.status();
            if (teste == 1) {
                Produtodao daop = new Produtodao();
                Caixasdao daoc = new Caixasdao();
                Caixas caixas = new Caixas();
                Produto produto = new Produto();
                Venda v = new Venda();

                int numCaixa = 0, qtde_p = 0;
                String id_produ = "";
                numCaixa = 1;
                if (!id_prod.getText().isEmpty()) {
                    id_produ = id_prod.getText();
                }
                if (!qtde.getText().isEmpty()) {
                    qtde_p = Integer.parseInt(qtde.getText());
                }
                id_caixa = numCaixa;
                caixas = daoc.caixas(numCaixa);
                if (caixas.getId_caixas() == numCaixa) {
                    if(!id_prod.getText().isEmpty()){
                    produto = daop.produto_cod(id_produ);
                    if (produto.getCodigo_produto().equals(id_produ)) {
                        if (produto.getQuantidade_estoque() >= qtde_p) {
                            v.setId_produto(id_produ);
                            v.setNome_prod(produto.getNome());
                            v.setQuantidade(qtde_p);
                            v.setVal_parcial((produto.getValor_venda() * (qtde_p)));
                            int ver = 0;
                            for (int i = 0; i < venda.size(); i++) {
                                if (venda.get(i).getId_produto().equals(id_produ)) {
                                    ver = 1;
                                }
                            }
                            if (ver == 0) {
                                total = total + v.getVal_parcial();
                                v.setVal_total(total);
                            
                                venda.add(v);
                            } else {
                                ver = 0;
                                JOptionPane.showMessageDialog(null, "PRODUTO JÁ INSERIDO!");
                            }
                            DefaultTableModel table = new DefaultTableModel();
                            table = (DefaultTableModel) tabela.getModel();
                            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
                            tabela.updateUI();
                            DecimalFormat df = new DecimalFormat("0.00");
                            for (int i = 0; i < venda.size(); i++) {
                                table.addRow(new Object[]{venda.get(i).getNome_prod(), venda.get(i).getQuantidade(), df.format(venda.get(i).getVal_parcial())});
                                float vt = total;
                                valt.setText(String.valueOf(df.format(vt)));
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "QUANTIDADE NÃO EXISTENTE EM ESTOQUE! EXISTE(M) APENAS " + produto.getQuantidade_estoque() + " NO ESTOQUE");

                        }
                    }
                }else{
                        float vparc = 0;
                        if(!vpar.getText().isEmpty()){
                            vparc = Float.parseFloat(vpar.getText());
                        }
                            v.setId_produto("1");
                            v.setNome_prod(nprodut.getText());
                            v.setQuantidade(qtde_p);
                            v.setVal_parcial((vparc * (qtde_p)));
                            int ver = 0;
                            for (int i = 0; i < venda.size(); i++) {
                                if (venda.get(i).getId_produto().equals(id_produ)) {
                                    ver = 1;
                                }
                            }
                            if (ver == 0) {
                               total = total + v.getVal_parcial();
                               v.setVal_total(total);
                            
                                venda.add(v);
                            } else {
                                ver = 0;
                                JOptionPane.showMessageDialog(null, "PRODUTO JÁ INSERIDO!");
                            }
                            DefaultTableModel table = new DefaultTableModel();
                            table = (DefaultTableModel) tabela.getModel();
                            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
                            tabela.updateUI();
                            DecimalFormat df = new DecimalFormat("0.00");
                            for (int i = 0; i < venda.size(); i++) {
                                table.addRow(new Object[]{venda.get(i).getNome_prod(), venda.get(i).getQuantidade(), df.format(venda.get(i).getVal_parcial())});
                                float vt = total;
                                valt.setText(String.valueOf(df.format(vt)));
                            }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "CAIXA NÃO FOI ABERTO! ABRA O CAIXA PARA REALIZAR VENDAS!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaSI.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        float vr = Float.parseFloat(v_r.getText());
        float v_v = Float.parseFloat(vv.getText());
        float t = vr - v_v;
        DecimalFormat df = new DecimalFormat("0.00");

        troco.setText(String.valueOf(df.format(t)));
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int tam = venda.size();
        if (tam > 0) {
            try {
                int id_forma_p = 1, id_fun = 0, efc_v = 0, cf_v = 0, verc = 0, verf = 0, verifica_c = 0, verifica_f = 0;
                float des = 0, comissaof = 0;
                Vendadao daov = new Vendadao();
                Venda v = new Venda();
                Venda_caixadao daovc = new Venda_caixadao();
                Venda_caixa vc = new Venda_caixa();
                Clientedao daoc = new Clientedao();
                Cliente cliente = new Cliente();
                Forma_pagamentodao daofp = new Forma_pagamentodao();
                Forma_pagamento fp = new Forma_pagamento();
                Funcionariodao daof = new Funcionariodao();
                Funcionario f = new Funcionario();
                Produtodao daop = new Produtodao();
                Produto prod = new Produto();
                Calendar cal = Calendar.getInstance();
                int dia = cal.get(Calendar.DATE);
                int mes = cal.get(Calendar.MONTH) + 1;
                int ano = cal.get(Calendar.YEAR);
                String zero_d = "", zero_m = "";
                if (dia < 10) {
                    zero_d = "0";
                }
                if (mes < 10) {
                    zero_m = "0";
                }
                String data = String.valueOf(zero_d + dia) + "/" + String.valueOf(zero_m + mes) + "/" + String.valueOf(ano);
                if (!id_f.getText().isEmpty()) {
                    id_fun = Integer.parseInt(id_f.getText());
                }
                if (!desc.getText().isEmpty()) {
                    des = Float.parseFloat(desc.getText());
                }
                if (!efc.getText().isEmpty()) {
                    efc_v = Integer.parseInt(efc.getText());
                }
                if (!cf.getText().isEmpty()) {
                    cf_v = Integer.parseInt(cf.getText());
                }
                v.setCpf_cliente(cpf.getText());
                v.setId_forma_pagamento(id_forma_p);
                v.setId_funcionario(id_fun);
                //v.setAcrescimo(ac);
                v.setDesconto(des);
                v.setNumeroEFC(efc_v);
                v.setNumeroCF(cf_v);

                fp = daofp.forma_p(id_forma_p);
                if (!cpf.getText().isEmpty()) {
                    cliente = daoc.pesquisa(cpf.getText());
                    verc = 2;
                    if (cliente.getCpf().equals(cpf.getText())) {
                        verc = 1;
                    }
                }
                if (id_fun > 0) {
                    verf = 2;

                    f = daof.funcionario(id_fun);
                    if (f.getId_funcionario() == id_fun) {
                        verf = 1;
                    }
                }
                if (verc != 2 && verf != 2) {
                    if (verc == 1) {
                        if (verf == 1) {
                            verifica_c = 1;
                            verifica_f = 1;
                            for (int i = 0; i < venda.size(); i++) {
                                v.setCpf_cliente(cpf.getText());
                                v.setId_funcionario(id_fun);
                                v.setId_forma_pagamento(id_forma_p);
                                v.setId_produto(venda.get(i).getId_produto());
                                v.setNome_prod(venda.get(i).getNome_prod());
                                v.setQuantidade(venda.get(i).getQuantidade());
                                v.setData_venda(data);
                                if(!venda.get(i).getId_produto().equals("1")){
                                prod = daop.produto_cod(venda.get(i).getId_produto());
                                comissaof = comissaof + prod.getComissao();
                                }
                                v.setValor_venda(venda.get(i).getVal_parcial());
                                v.setId_funcionario(id_fun);
                                v.setNumCaixa(id_caixa);
                                daov.cadastro(v);
                                if(!venda.get(i).getId_produto().equals("1")){
                                int q = prod.getQuantidade_estoque();
                                prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                                prod.setEstoque_minimo(prod.getEstoque_minimo());
                                daop.altera_cod(prod);
                                }
                            }
                            JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");

                        }
                    }
                    if (verc == 0) {
                        if (verf == 0) {
                            for (int i = 0; i < venda.size(); i++) {
                                v.setId_produto(venda.get(i).getId_produto());
                                v.setNome_prod(venda.get(i).getNome_prod());
                                v.setQuantidade(venda.get(i).getQuantidade());
                                v.setId_forma_pagamento(id_forma_p);
                                v.setData_venda(data);
                                if(!venda.get(i).getId_produto().equals("1")){
                                prod = daop.produto_cod(venda.get(i).getId_produto());
                                 comissaof = comissaof + prod.getComissao();
                                }
                                v.setValor_venda(venda.get(i).getVal_parcial());
                                v.setId_funcionario(id_fun);
                                v.setNumCaixa(id_caixa);

                                daov.cadastro(v);
                               if(!venda.get(i).getId_produto().equals("1")){
                                int q = prod.getQuantidade_estoque();
                                prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                                daop.altera_cod(prod);
                               } 
                            }
                            JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");
                        }
                    }
                    if (verc == 1 && verifica_c == 0 || verf == 1 && verifica_f == 0) {

                        for (int i = 0; i < venda.size(); i++) {
                            if (verc == 1) {
                                v.setCpf_cliente(cpf.getText());
                            }
                            if (verf == 1) {
                                v.setId_funcionario(id_fun);
                            }
                            v.setId_forma_pagamento(id_forma_p);
                            v.setId_produto(venda.get(i).getId_produto());
                            v.setNome_prod(venda.get(i).getNome_prod());
                            v.setQuantidade(venda.get(i).getQuantidade());
                            v.setData_venda(data);
                           if(!venda.get(i).getId_produto().equals("1")){
                            prod = daop.produto_cod(venda.get(i).getId_produto());
                            comissaof = comissaof + prod.getComissao();
                           }
                            v.setValor_venda(venda.get(i).getVal_parcial());
                            v.setId_funcionario(id_fun);
                            v.setNumCaixa(id_caixa);
                            daov.cadastro(v);
                           if(!venda.get(i).getId_produto().equals("1")){
                            int q = prod.getQuantidade_estoque();
                            prod.setQuantidade_estoque(q - venda.get(i).getQuantidade());
                            daop.altera_cod(prod);
                        }
                        }
                        JOptionPane.showMessageDialog(null, "VENDA REALIZADA COM SUCESSO!");

                    }
                    Venda_caixadao venda_c = new Venda_caixadao();
                    Venda_caixa venda_caixa = new Venda_caixa();
                    venda_caixa.setData_venda(data);
                    venda_caixa.setNumCaixa(id_caixa);
                    if (verc == 1) {
                        venda_caixa.setCpf_cliente(cpf.getText());
                    }
                    venda_caixa.setId_forma_pagamento(id_forma_p);
                    venda_caixa.setValor_venda(total - (des));
                    venda_caixa.setValor_pago(total - (des));
                    venda_c.cadastro(venda_caixa);
                    if (id_fun > 0) {
                        Funcionario_comissaodao daofc = new Funcionario_comissaodao();
                        Funcionario_comissao fc = new Funcionario_comissao();
                        fc.setId_funcionario(id_fun);
                        fc.setValor_comissao(comissaof);
                        fc.setMes(mes);
                        fc.setAno(ano);
                        daofc.cadastro(fc);
                    }
//_________________________________________________________________

                    PrintService[] printService = PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.AUTOSENSE, null);
                    System.out.println("Quantas Impressoras:  " + printService.length);
                    PrintService impressoraPadrao = PrintServiceLookup.lookupDefaultPrintService();
                    System.out.println("A impressora padrão é:  " + impressoraPadrao.getName());
                    DocFlavor docFlavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
                    HashDocAttributeSet hashDocAttributeSet = new HashDocAttributeSet();
                    Document document = new Document();
                    Date d = new Date();
                    String t = String.valueOf(d.getDay() + "" + d.getMonth() + "" + d.getYear() + "" + d.getHours() + "" + "" + d.getMinutes() + "" + "" + d.getSeconds());
                    System.out.println("data:  " + d.getTime());
                    String nome = "C:\\Users\\Abimael\\Documents\\comprovantes vendas/comprovante" + t + ".pdf";
                    DecimalFormat df = new DecimalFormat("0.00");

                    PdfWriter.getInstance(document, new FileOutputStream(nome));
                    document.open();

                    // adicionando um parágrafo no documento
                    document.add(new Paragraph("COMPROVANTE DE VENDA A VISTA\n" + "--------------------------------------------------------------" + "\n"));
                    document.add(new Paragraph("CPF do Cliente -----  Nome do Cliente :   "));
                    document.add(new Paragraph(cliente.getCpf() + " -----------  " + " " + cliente.getNome() + "\n"));
                    document.add(new Paragraph("Id do Funcionario -----  Nome do Funcionario :   "));
                    document.add(new Paragraph(f.getId_funcionario() + " --------  " + " " + f.getNome() + "\n"));
                    document.add(new Paragraph("Nome (s) do (s) Produtos ------ Preço -----Quantidade  :  "));
                    for (int i = 0; i < venda.size(); i++) {

                        document.add(new Paragraph(venda.get(i).getNome_prod() + "  ------ " + "  " + " " + df.format(venda.get(i).getVal_parcial()) + " " + " ------- " + " " + venda.get(i).getQuantidade()));
                    }
                    document.add(new Paragraph("VALOR TOTAL:   "));
                    document.add(new Paragraph(df.format(total - (des)) + "\n"));
                    document.add(new Paragraph("Data da Venda:   "));
                    document.add(new Paragraph(data + "\n"));

                    document.close();
                    FileInputStream fileInputStream = new FileInputStream(nome);
                    Doc doc = new SimpleDoc(fileInputStream, docFlavor, hashDocAttributeSet);
                    PrintRequestAttributeSet printResquestAttributeSet = new HashPrintRequestAttributeSet();
                    PrintService printServico = ServiceUI.printDialog(null, 300, 200, printService, impressoraPadrao, docFlavor, printResquestAttributeSet);
                    if (printServico != null) {
                        DocPrintJob docPrintJob = printServico.createPrintJob();
                        docPrintJob.print(doc, printResquestAttributeSet);
                    }

//_________________________________________________________________________________
                    float vt = 0;
                    vt = total - (des);

                    DecimalFormat dff = new DecimalFormat("0.00");

                    valt.setText(String.valueOf(dff.format(vt)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DocumentException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (PrintException ex) {
                Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "NENHUM PRODUTO FOI ADICIONADO PARA VENDA!");
        }
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        venda.clear();
        total = 0;

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        //nome_prod.setText("");
        nprodut.setText("");
        vpar.setText("");
        valt.setText("");
        //nc.setText("");
        id_prod.setText("");
        qtde.setText("");
        cpf.setText("");
        id_f.setText("");
        efc.setText("");
        cf.setText("");
        //acresc.setText("");
        desc.setText("");
        v_r.setText("");
        vv.setText("");
        troco.setText("");

    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        venda.clear();
        total = 0;
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        float t = 0;
        for (int i = 0; i < venda.size(); i++) {
            if (venda.get(i).getNome_prod().equals(id_ret.getText())) {
                t = venda.get(i).getVal_parcial();
                venda.remove(i);

            }

        }
        total = total - t;
        float vt = total;
        DefaultTableModel table = new DefaultTableModel();
        table = (DefaultTableModel) tabela.getModel();
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        DecimalFormat df = new DecimalFormat("0.00");
        valt.setText(String.valueOf(df.format(vt)));

        for (int i = 0; i < venda.size(); i++) {
            table.addRow(new Object[]{venda.get(i).getNome_prod(), venda.get(i).getQuantidade(), df.format(venda.get(i).getVal_parcial())});
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void valtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valtActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        PesquisarCliente pcli = new PesquisarCliente();
        pcli.setVisible(true);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        PesquisarProduto p = new PesquisarProduto();
        p.setVisible(true);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        Contas_receberdao crdao;
        try {
            crdao = new Contas_receberdao();
            if (!cpf.getText().isEmpty()) {
                List<Contas_receber> crlist = new ArrayList<>();
                crlist = crdao.listar_cli_venda(cpf.getText());
                if (crlist.size() > 0) {
                    Contas_cliente cclientes = new Contas_cliente(cpf.getText());
                    cclientes.setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(null, "DIGITE O CPF DO CLIENTE QUE DESEJA BUSCAR!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaSI.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton12ActionPerformed

    private void qtdeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_qtdeFocusLost

    }//GEN-LAST:event_qtdeFocusLost

    private void qtdeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_qtdeFocusGained
          getRootPane().setDefaultButton(entrar);
        entrar.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    entrar.doClick();
		}
	      }
        });
    }//GEN-LAST:event_qtdeFocusGained

    private void id_prodFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_id_prodFocusGained
        id_prod.setText("");
    }//GEN-LAST:event_id_prodFocusGained

    private void qtdeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qtdeKeyPressed
       getRootPane().setDefaultButton(entrar);
        entrar.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    entrar.doClick();
		}
	      }
        });

    }//GEN-LAST:event_qtdeKeyPressed

    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entrarActionPerformed
         id_prod.requestFocus();
    }//GEN-LAST:event_entrarActionPerformed

    private void vparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vparActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_vparActionPerformed

    private void nprodutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nprodutKeyPressed
                       getRootPane().setDefaultButton(b4);
        b4.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b4.doClick();
		}
	      }
        });


    }//GEN-LAST:event_nprodutKeyPressed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        vpar.requestFocus();
    }//GEN-LAST:event_b4ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b4;
    private javax.swing.JTextField cf;
    private javax.swing.JTextField cpf;
    private javax.swing.JFormattedTextField d;
    private javax.swing.JTextField desc;
    private javax.swing.JTextField efc;
    private javax.swing.JButton entrar;
    private javax.swing.JTextField id_f;
    private javax.swing.JTextField id_prod;
    private javax.swing.JTextField id_ret;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField nprodut;
    private javax.swing.JTextField qtde;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField troco;
    private javax.swing.JTextField v_r;
    private javax.swing.JTextField valt;
    private javax.swing.JTextField vpar;
    private javax.swing.JTextField vv;
    // End of variables declaration//GEN-END:variables
}
