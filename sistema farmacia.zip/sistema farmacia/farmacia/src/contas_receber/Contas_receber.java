package contas_receber;

public class Contas_receber {
    private int id_contas_receber;
    private String data_venda;
    private String tipo;
    private String cpf_cliente;
    private float valor_receber;
    private float valor_recebido;
    private float desconto;
    private float acrescimo;
    private String data_vcto;
    private float saldo;
    private int id_venda;
    private int id_empresa;
    private int numero_prestacao;
    private int id_forma_pagamento;
    
    public Contas_receber(){}

    public Contas_receber(int id_contas_receber, String data_venda, String tipo, String cpf_cliente, float valor_receber, float valor_recebido, float desconto, float acrescimo, String data_vcto, float saldo, int id_venda, int id_empresa, int numero_prestacao, int id_forma_pagamento) {
        this.id_contas_receber = id_contas_receber;
        this.data_venda = data_venda;
        this.tipo = tipo;
        this.cpf_cliente = cpf_cliente;
        this.valor_receber = valor_receber;
        this.valor_recebido = valor_recebido;
        this.desconto = desconto;
        this.acrescimo = acrescimo;
        this.data_vcto = data_vcto;
        this.saldo = saldo;
        this.id_venda = id_venda;
        this.id_empresa = id_empresa;
        this.numero_prestacao = numero_prestacao;
        this.id_forma_pagamento = id_forma_pagamento;
    }

    public int getId_contas_receber() {
        return id_contas_receber;
    }

    public void setId_contas_receber(int id_contas_receber) {
        this.id_contas_receber = id_contas_receber;
    }

    public String getData_venda() {
        return data_venda;
    }

    public void setData_venda(String data_venda) {
        this.data_venda = data_venda;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCpf_cliente() {
        return cpf_cliente;
    }

    public void setCpf_cliente(String cpf_cliente) {
        this.cpf_cliente = cpf_cliente;
    }

    public float getValor_receber() {
        return valor_receber;
    }

    public void setValor_receber(float valor_receber) {
        this.valor_receber = valor_receber;
    }

    public float getValor_recebido() {
        return valor_recebido;
    }

    public void setValor_recebido(float valor_recebido) {
        this.valor_recebido = valor_recebido;
    }

    public float getDesconto() {
        return desconto;
    }

    public void setDesconto(float desconto) {
        this.desconto = desconto;
    }

    public float getAcrescimo() {
        return acrescimo;
    }

    public void setAcrescimo(float acrescimo) {
        this.acrescimo = acrescimo;
    }

    public String getData_vcto() {
        return data_vcto;
    }

    public void setData_vcto(String data_vcto) {
        this.data_vcto = data_vcto;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public int getId_venda() {
        return id_venda;
    }

    public void setId_venda(int id_venda) {
        this.id_venda = id_venda;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public int getNumero_prestacao() {
        return numero_prestacao;
    }

    public void setNumero_prestacao(int numero_prestacao) {
        this.numero_prestacao = numero_prestacao;
    }

    public int getId_forma_pagamento() {
        return id_forma_pagamento;
    }

    public void setId_forma_pagamento(int id_forma_pagamento) {
        this.id_forma_pagamento = id_forma_pagamento;
    }
    
    
}
