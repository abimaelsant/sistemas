package contas_receber;

import conexao.Conexao;
import contas_pagar.Contas_pagar;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Contas_receberdao {
     Conexao conexoes = new Conexao();
    Connection conexao;

    public Contas_receberdao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Contas_receber c) throws SQLException, UnknownHostException, IOException {
        try {
            String sql = "INSERT INTO contas_receber(data_venda, cpf_cliente, valor_receber, valor_recebido, data_vcto, numero_prestacao, id_forma_pagamento) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getData_venda());
            //stmt.setString(2, c.getTipo());
            stmt.setString(2, c.getCpf_cliente());
            stmt.setFloat(3, c.getValor_receber());
            stmt.setFloat(4, c.getValor_recebido());
            //stmt.setFloat(6, c.getDesconto());
            //stmt.setFloat(7, c.getAcrescimo());
            stmt.setString(5, c.getData_vcto());
            //stmt.setFloat(9, c.getSaldo());
            //stmt.setInt(10, c.getId_venda());
            //stmt.setInt(11, c.getId_empresa());
            stmt.setInt(6, c.getNumero_prestacao());
            stmt.setInt(7, c.getId_forma_pagamento());
            
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "OPERAÇÃO REALIZADA COM SUCESSO!");
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Contas_receber c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE contas_receber set  data_venda=?, tipo=?, cpf_cliente=?, valor_receber=?, valor_recebido=?, desconto=?, acrescimo=?, data_vcto=?, saldo=?, id_venda=?, id_empresa=?, numero_prestacao=?, id_forma_pagamento=? where id_contas_receber=?";
        PreparedStatement s = conexao.prepareStatement("select * from contas_receber");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_receber() == rs.getInt("id_contas_receber")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getData_venda());
            stmt.setString(2, c.getTipo());
            stmt.setString(3, c.getCpf_cliente());
            stmt.setFloat(4, c.getValor_receber());
            stmt.setFloat(5, c.getValor_recebido());
            stmt.setFloat(6, c.getDesconto());
            stmt.setFloat(7, c.getAcrescimo());
            stmt.setString(8, c.getData_vcto());
            stmt.setFloat(9, c.getSaldo());
            stmt.setInt(10, c.getId_venda());
            stmt.setInt(11, c.getId_empresa());
            stmt.setInt(12, c.getNumero_prestacao());
            stmt.setInt(13, c.getId_forma_pagamento());
            stmt.setInt(14, c.getId_contas_receber());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADA!");
        }

    }

    public void alteraconta(Contas_receber c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE contas_receber set   valor_receber=?, valor_recebido=?, numero_prestacao=? where id_conta_receber=?";
        PreparedStatement s = conexao.prepareStatement("select * from contas_receber");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_receber() == rs.getInt("id_conta_receber")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            
            stmt.setFloat(1, c.getValor_receber());
            stmt.setFloat(2, c.getValor_recebido());
            stmt.setInt(3, c.getNumero_prestacao());
            stmt.setInt(4, c.getId_contas_receber());
            stmt.executeUpdate();
            stmt.close();
            //JOptionPane.showMessageDialog(null, "EDITADA COM SUCESSO!");
        } else {
            //JOptionPane.showMessageDialog(null, "NAO CADASTRADA!");
        }
    }
    public void excluir(Contas_receber c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM contas_receber WHERE id_conta_receber=? ";
        PreparedStatement s = conexao.prepareStatement("select * from contas_receber");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_receber() == rs.getInt("id_conta_receber")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, c.getId_contas_receber());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "DELETADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADA!");
        }

    }
public void excluir_c(Contas_receber c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM contas_receber WHERE id_conta_receber=? ";
        PreparedStatement s = conexao.prepareStatement("select * from contas_receber");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_contas_receber() == rs.getInt("id_conta_receber")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, c.getId_contas_receber());
            stmt.execute();
            stmt.close();
       //     JOptionPane.showMessageDialog(null, "DELETADA COM SUCESSO!");
        } else {
     //       JOptionPane.showMessageDialog(null, "NAO CADASTRADA!");
        }

    }
    public List<Contas_receber> listar() throws SQLException {
        List<Contas_receber> contas = new ArrayList<Contas_receber>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from contas_receber");

            rs = sql.executeQuery();

            while (rs.next()) {

                Contas_receber c = new Contas_receber();
                c.setId_contas_receber(rs.getInt("id_conta_receber"));
                c.setData_venda(rs.getString("data_venda"));
                c.setTipo(rs.getString("tipo"));
                c.setCpf_cliente(rs.getString("cpf_cliente"));
                c.setValor_receber(rs.getFloat("valor_receber"));
                c.setValor_recebido(rs.getFloat("valor_recebido"));
                c.setDesconto(rs.getFloat("desconto"));
                c.setAcrescimo(rs.getFloat("acrescimo"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setSaldo(rs.getFloat("saldo"));
                c.setId_venda(rs.getInt("id_venda"));
                c.setId_empresa(rs.getInt("id_empresa"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                contas.add(c);
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (contas);
    }
    
    public List<Contas_receber> listarc(String cpf) throws SQLException {
        List<Contas_receber> contas = new ArrayList<Contas_receber>();
       
        ResultSet rs = null;
        int verifica = 0;        
            PreparedStatement sql = conexao.prepareStatement("select * from contas_receber");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getString("cpf_cliente").equals(cpf)){
                  verifica = 1;
                Contas_receber c = new Contas_receber();
                c.setId_contas_receber(rs.getInt("id_conta_receber"));
                c.setData_venda(rs.getString("data_venda"));
                c.setTipo(rs.getString("tipo"));
                c.setCpf_cliente(rs.getString("cpf_cliente"));
                c.setValor_receber(rs.getFloat("valor_receber"));
                c.setValor_recebido(rs.getFloat("valor_recebido"));
                c.setDesconto(rs.getFloat("desconto"));
                c.setAcrescimo(rs.getFloat("acrescimo"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setSaldo(rs.getFloat("saldo"));
                c.setId_venda(rs.getInt("id_venda"));
                c.setId_empresa(rs.getInt("id_empresa"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                contas.add(c);
            }
          }
           
         
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CONTA NÃO ENCONTRADA!");
            }
        return (contas);
    }
    
    public List<Contas_receber> listarcc(String cpf) throws SQLException {
        List<Contas_receber> contas = new ArrayList<Contas_receber>();
        List<Contas_receber> contass = new ArrayList<Contas_receber>();
       
        int verifica = 0;        
        contass = listar();
        for(int i = 0; i < contass.size(); i++){
           if(contass.get(i).getCpf_cliente().equals(cpf)){
                  verifica = 1;
                Contas_receber c = new Contas_receber();
                c.setId_contas_receber(contass.get(i).getId_contas_receber());
                c.setData_venda(contass.get(i).getData_venda());
                c.setTipo(contass.get(i).getTipo());
                c.setCpf_cliente(contass.get(i).getCpf_cliente());
                c.setValor_receber(contass.get(i).getValor_receber());
                c.setValor_recebido(contass.get(i).getValor_recebido());
                c.setDesconto(contass.get(i).getDesconto());
                c.setAcrescimo(contass.get(i).getAcrescimo());
                c.setData_vcto(contass.get(i).getData_vcto());
                c.setSaldo(contass.get(i).getSaldo());
                c.setId_venda(contass.get(i).getId_venda());
                c.setId_empresa(contass.get(i).getId_empresa());
                c.setNumero_prestacao(contass.get(i).getNumero_prestacao());
                c.setId_forma_pagamento(contass.get(i).getId_forma_pagamento());
                contas.add(c);
            }
          }
           
         
            if(verifica == 0){
//                JOptionPane.showMessageDialog(null, "CONTA NÃO ENCONTRADA!");
            }
        return (contas);
    }
    
    
    
   public int contas(int id_c) throws SQLException {
        ResultSet rs = null;
        int verifica = 0;

       
            PreparedStatement sql = conexao.prepareStatement("select * from contas_receber");

            rs = sql.executeQuery();

            while (rs.next()) {

                Contas_receber c = new Contas_receber();
               if(rs.getInt("id_conta_receber") == id_c){
                  verifica = 1;
               }
           }
            return verifica;
   }
     public Contas_receber contas_r(int id_c) throws SQLException {
        ResultSet rs = null;
        int verifica = 0;
        Contas_receber c = new Contas_receber();
       
            PreparedStatement sql = conexao.prepareStatement("select * from contas_receber");

            rs = sql.executeQuery();

            while (rs.next()) {

               if(rs.getInt("id_conta_receber") == id_c){
                   c.setId_contas_receber(rs.getInt("id_conta_receber"));
                c.setData_venda(rs.getString("data_venda"));
                c.setTipo(rs.getString("tipo"));
                c.setCpf_cliente(rs.getString("cpf_cliente"));
                c.setValor_receber(rs.getFloat("valor_receber"));
                c.setValor_recebido(rs.getFloat("valor_recebido"));
                c.setDesconto(rs.getFloat("desconto"));
                c.setAcrescimo(rs.getFloat("acrescimo"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setSaldo(rs.getFloat("saldo"));
                c.setId_venda(rs.getInt("id_venda"));
                c.setId_empresa(rs.getInt("id_empresa"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                verifica = 1;
               }
           }
            return c;
   }
     
     public Float valor(String cpf) throws SQLException {
        float valorT = 0;
        ResultSet rs = null;
        int verifica = 0;
        try {

            PreparedStatement sql = conexao.prepareStatement("select * from contas_receber");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getString("cpf_cliente").equals(cpf)){
                Contas_receber c = new Contas_receber();
                valorT = valorT + rs.getFloat("valor_receber");
            }
          }
        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (valorT);
    }
     public List<Contas_receber> listar_cli_venda(String cpf) throws SQLException {
        List<Contas_receber> contas = new ArrayList<Contas_receber>();

        ResultSet rs = null;
        int verifica = 0;
        try {

            PreparedStatement sql = conexao.prepareStatement("select * from contas_receber");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getString("cpf_cliente").equals(cpf)){
                Contas_receber c = new Contas_receber();
                c.setId_contas_receber(rs.getInt("id_conta_receber"));
                c.setData_venda(rs.getString("data_venda"));
                c.setTipo(rs.getString("tipo"));
                c.setCpf_cliente(rs.getString("cpf_cliente"));
                c.setValor_receber(rs.getFloat("valor_receber"));
                c.setValor_recebido(rs.getFloat("valor_recebido"));
                c.setDesconto(rs.getFloat("desconto"));
                c.setAcrescimo(rs.getFloat("acrescimo"));
                c.setData_vcto(rs.getString("data_vcto"));
                c.setSaldo(rs.getFloat("saldo"));
                c.setId_venda(rs.getInt("id_venda"));
                c.setId_empresa(rs.getInt("id_empresa"));
                c.setNumero_prestacao(rs.getInt("numero_prestacao"));
                c.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                contas.add(c);
                verifica = 1;
            }
          }
            if(verifica == 1){
                
                //JOptionPane.showMessageDialog(null, "CONTA NÃO ENCONTRADA!");
            }
        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (contas);
    }
}
