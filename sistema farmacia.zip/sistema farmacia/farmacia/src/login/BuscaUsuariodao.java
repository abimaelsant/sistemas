package login;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BuscaUsuariodao {
    Conexao conexoes = new Conexao();
    Connection conexao;

    public BuscaUsuariodao() throws SQLException {
        this.conexao = conexoes.conexao();
    }
    public int verifica(String usu, String senha) throws SQLException {
        //List<CadastroUsuario> cadastro = new ArrayList<>();
        int verifica = 0;
        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from cadastro_usuario");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getString("usuario").equals(usu) && rs.getString("senha").equals(senha)){
                CadastroUsuario c = new CadastroUsuario();
                c.setId_usuario(rs.getInt("id_usuario"));
                c.setUsuario(rs.getString("usuario"));
                c.setSenha(rs.getString("senha"));
                c.setId_cargo(rs.getInt("id_cargo"));
                verifica = c.getId_cargo();
               }

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return verifica;
    }
}
