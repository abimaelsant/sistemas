package farmacia;

import cliente.Cliente;
import com.itextpdf.text.DocumentException;
import java.io.FileNotFoundException;
import javax.print.PrintException;

public class Farmacia {

    // variavel estatica porque será utilizada por inumeras threads
    
    public static void main(String[] args) throws FileNotFoundException, PrintException, DocumentException {
    Cliente cliente = new Cliente();
    String cpf = "25933906385";
    cliente.validaCpf(cpf);
      
}
}
    

