package cliente;

import conexao.Conexao;
import empresa.Empresa;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import produto.Produtodao;

public class Clientedao {
        Conexao conexoes = new Conexao();
        Connection conexao;
        
        public Clientedao() throws SQLException{
            this.conexao = conexoes.conexao();
        }
        
        public void cadastro(Cliente c) throws SQLException, UnknownHostException, IOException{
          int verifica = 0;
          String sql = "INSERT INTO cliente(nome, endereco, bairro, cep, cidade, estado, telefone, grupo, ativo_inativo, cpf, identidade, data_nascimento, valorMax) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";  
          ResultSet rs = null;  
          try {  
            PreparedStatement s = conexao.prepareStatement("select * from cliente");

            rs = s.executeQuery();

            while(rs.next()){
               if(c.getCpf().equals(rs.getString("cpf")) || c.getCpf().equals("") || c.getCpf() == null){
                   verifica = 1;
               }
            }
            if(verifica == 0){
                PreparedStatement stmt = conexao.prepareStatement(sql);  
                
                stmt.setString(1, c.getNome());
                stmt.setString(2, c.getEndereco());
                stmt.setString(3, c.getBairro());
                stmt.setString(4, c.getCep());
                stmt.setString(5, c.getCidade());
                stmt.setString(6, c.getEstado());
                stmt.setString(7, c.getTelefone());
                stmt.setString(8, c.getGrupo());
               // stmt.setInt(9, c.getId_empresa());
                stmt.setBoolean(9, c.getAtivo_inativo());
                stmt.setString(10, c.getCpf());
                stmt.setString(11, c.getIdentidade());
                stmt.setString(12, c.getData_nascimento());
                stmt.setFloat(13, c.getValorMax());
                stmt.execute();  
                stmt.close();
                JOptionPane.showMessageDialog(null, "CLIENTE CADASTRADO COM SUCESSO!");
            }else{
                JOptionPane.showMessageDialog(null, "CLIENTE JÁ CADASTRADO OU CAMPO CPF ESTÁ VAZIO!");
            }
            } catch (SQLException u) {
                System.out.println("erro");
        }
        }
    
    public void altera(Cliente c) throws SQLException, UnknownHostException, IOException{
        int verifica = 0;
        try{
            
            ResultSet rs = null;
            String sql = "UPDATE cliente set nome=?, endereco=?, bairro=?, cep=?, cidade=?, estado=?, telefone=?, grupo=?, identidade=?, data_nascimento=?, valorMax=? where cpf=?";
            PreparedStatement s = conexao.prepareStatement("select * from cliente");

            rs = s.executeQuery();

            while(rs.next()){
               if(c.getCpf().equals(rs.getString("cpf"))){
                   verifica = 1;
               }
            }
        if(verifica == 1){
        
        PreparedStatement stmt = conexao.prepareStatement(sql);  
        
        stmt.setString(1, c.getNome());
        stmt.setString(2, c.getEndereco());
        stmt.setString(3, c.getBairro());
        stmt.setString(4, c.getCep());
        stmt.setString(5, c.getCidade());
        stmt.setString(6, c.getEstado());
        stmt.setString(7, c.getTelefone());
        stmt.setString(8, c.getGrupo());
        //stmt.setInt(9, c.getId_empresa());
        stmt.setString(9, c.getIdentidade());
        stmt.setString(10, c.getData_nascimento());
        stmt.setFloat(11, c.getValorMax());
        stmt.setString(12, c.getCpf());
        stmt.executeUpdate();
        stmt.close();
        JOptionPane.showMessageDialog(null, "CLIENTE EDITADO COM SUCESSO!");
        }else{
            JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
        }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Erro ao editar"+e);
        }
        }
    
    public void excluir(Cliente c) throws SQLException, UnknownHostException, IOException{
       int verifica = 0;
        try {
            String cpf = "";
            ResultSet rs = null;
            String sql ="DELETE FROM cliente WHERE cpf=? ";
            PreparedStatement s = conexao.prepareStatement("select * from cliente");

            rs = s.executeQuery();
 
            while(rs.next()){
               
               if(c.getCpf().equals(c.formatCpf(rs.getString("cpf")))){
                   verifica = 1;
               }
            }
            if(verifica == 1){

            PreparedStatement stmt = conexao.prepareStatement(sql);  
              
            stmt.setString(1, c.formatCpf2(c.getCpf()));
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "CLIENTE DELETADO COM SUCESSO!");
            }else{
                JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Erro ao excluir"+e);
        }
        }
    
 public List<Cliente> listar() throws SQLException{
   List<Cliente> cliente = new ArrayList<Cliente>();

  ResultSet rs = null;

  try {

   PreparedStatement sql = conexao.prepareStatement("select * from cliente");

   rs = sql.executeQuery();

   while(rs.next()){

    Cliente c = new Cliente();
    
    c.setNome(rs.getString("nome"));
    c.setEndereco(rs.getString("endereco"));
    c.setBairro(rs.getString("bairro"));
    c.setCep(rs.getString("cep"));
    c.setCidade(rs.getString("cidade"));
    c.setEstado(rs.getString("estado"));
    c.setTelefone(rs.getString("telefone"));
    c.setGrupo(rs.getString("grupo"));
    //c.setId_empresa(rs.getInt("id_empresa"));
    c.setAtivo_inativo(rs.getBoolean("ativo_inativo"));
    c.setCpf(rs.getString("cpf"));
    c.setIdentidade(rs.getString("identidade"));
    c.setData_nascimento(rs.getString("data_nascimento"));
    c.setValorMax(rs.getFloat("valorMax"));
    cliente.add(c);

   }

  } catch (SQLException e) {

   e.printStackTrace();

  }
  
  return(cliente);
 } 
 
  public Cliente pesquisa(String cpf) throws SQLException {
        Cliente c = new Cliente();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from cliente");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getString("cpf").equals(cpf)){
                c.setNome(rs.getString("nome"));
                c.setEndereco(rs.getString("endereco"));
                c.setBairro(rs.getString("bairro"));
                c.setCep(rs.getString("cep"));
                c.setCidade(rs.getString("cidade"));
                c.setEstado(rs.getString("estado"));
                c.setTelefone(rs.getString("telefone"));
                c.setGrupo(rs.getString("grupo"));
                //c.setId_empresa(rs.getInt("id_empresa"));
                c.setCpf(rs.getString("cpf"));
                c.setIdentidade(rs.getString("identidade"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setValorMax(rs.getFloat("valorMax"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
            }
         return c;
        }
   public Cliente pesquisac(String cpf) throws SQLException {
        Cliente c = new Cliente();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from cliente");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getString("cpf").equals(cpf)){
                c.setNome(rs.getString("nome"));
                c.setEndereco(rs.getString("endereco"));
                c.setBairro(rs.getString("bairro"));
                c.setCep(rs.getString("cep"));
                c.setCidade(rs.getString("cidade"));
                c.setEstado(rs.getString("estado"));
                c.setTelefone(rs.getString("telefone"));
                c.setGrupo(rs.getString("grupo"));
               // c.setId_empresa(rs.getInt("id_empresa"));
                c.setCpf(rs.getString("cpf"));
                c.setIdentidade(rs.getString("identidade"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setValorMax(rs.getFloat("valorMax"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                //JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
            }
         return c;
        }
   
    public List<Cliente> pesquisa_nome_cli(String nome) throws SQLException {
        List<Cliente> cliente = new ArrayList<>();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from cliente");

            rs = sql.executeQuery();

            while (rs.next()) {
                Produtodao daop = new Produtodao();
        
                Cliente c = new Cliente();
       
                if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome))){
                c.setNome(rs.getString("nome"));
                c.setEndereco(rs.getString("endereco"));
                c.setBairro(rs.getString("bairro"));
                c.setCep(rs.getString("cep"));
                c.setCidade(rs.getString("cidade"));
                c.setEstado(rs.getString("estado"));
                c.setTelefone(rs.getString("telefone"));
                c.setGrupo(rs.getString("grupo"));
               // c.setId_empresa(rs.getInt("id_empresa"));
                c.setCpf(rs.getString("cpf"));
                c.setIdentidade(rs.getString("identidade"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setValorMax(rs.getFloat("valorMax"));
                cliente.add(c);
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
            }
         return cliente;
        }
   public List<Cliente> pesquisa_nome_cli2(String nome) throws SQLException {
       
        Produtodao daop = new Produtodao();
        List<Cliente> cliente = new ArrayList<>();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from cliente");

            rs = sql.executeQuery();

            while (rs.next()) {
                Cliente c = new Cliente();
                if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome))){
                c.setNome(rs.getString("nome"));
                c.setEndereco(rs.getString("endereco"));
                c.setBairro(rs.getString("bairro"));
                c.setCep(rs.getString("cep"));
                c.setCidade(rs.getString("cidade"));
                c.setEstado(rs.getString("estado"));
                c.setTelefone(rs.getString("telefone"));
                c.setGrupo(rs.getString("grupo"));
               // c.setId_empresa(rs.getInt("id_empresa"));
                c.setCpf(rs.getString("cpf"));
                c.setIdentidade(rs.getString("identidade"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setValorMax(rs.getFloat("valorMax"));
                cliente.add(c);
                verifica = 1;
               }
            }
            if(verifica == 0){
               // JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
            }
         return cliente;
        }
   
   public List<Cliente> pesquisa_nome_cli_contas_pagar(String nome_cpf) throws SQLException {
       
        Produtodao daop = new Produtodao();
        List<Cliente> cliente = new ArrayList<>();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from cliente");

            rs = sql.executeQuery();

            while (rs.next()) {
                Cliente c = new Cliente();
                if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome_cpf)) || rs.getString("cpf").equals(nome_cpf)){
                c.setNome(rs.getString("nome"));
                c.setEndereco(rs.getString("endereco"));
                c.setBairro(rs.getString("bairro"));
                c.setCep(rs.getString("cep"));
                c.setCidade(rs.getString("cidade"));
                c.setEstado(rs.getString("estado"));
                c.setTelefone(rs.getString("telefone"));
                c.setGrupo(rs.getString("grupo"));
               // c.setId_empresa(rs.getInt("id_empresa"));
                c.setCpf(rs.getString("cpf"));
                c.setIdentidade(rs.getString("identidade"));
                c.setData_nascimento(rs.getString("data_nascimento"));
                c.setValorMax(rs.getFloat("valorMax"));
                cliente.add(c);
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CLIENTE NÃO CADASTRADO!");
            }
         return cliente;
        }
   
   
  public Empresa empresa(int id_p) throws SQLException {
        Empresa e = new Empresa();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(id_p != 0){
               if(rs.getInt("id_empresa") == id_p){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                verifica = 1;
               }
            }
            }
            if(verifica == 0){
            }
         return e;
        }
  
}
