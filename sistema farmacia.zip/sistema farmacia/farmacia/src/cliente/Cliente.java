package cliente;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class Cliente {
    private String nome;
    private String endereco;
    private String bairro;
    private String cep;
    private String cidade;
    private String estado;
    private String telefone;
    private String grupo;
    private int id_empresa;
    private boolean ativo_inativo;
    private String cpf;
    private String identidade;
    private String data_nascimento;
    private float valorMax;
    public Cliente(){}
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public boolean getAtivo_inativo() {
        return ativo_inativo;
    }

    public void setAtivo_inativo(boolean ativo_inativo) {
        this.ativo_inativo = ativo_inativo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getIdentidade() {
        return identidade;
    }

    public void setIdentidade(String identidade) {
        this.identidade = identidade;
    }

    public String getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(String data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public float getValorMax() {
        return valorMax;
    }

    public void setValorMax(float valorMax) {
        this.valorMax = valorMax;
    }
    
    public String formatCpf(String cpf){
        if(cpf.length() == 11){
          String bloco1 = cpf.substring(0, 3);
          String bloco2 = cpf.substring(3, 6);
          String bloco3 = cpf.substring(6, 9);
	  String bloco4 = cpf.substring(9, 11);
	//cpf = bloco1+"."+bloco2+"."+bloco3+"-"+bloco4;
	cpf = String.format("%s.%s.%s-%s", bloco1, bloco2, bloco3, bloco4);
        }else{
            
        }
        return cpf;
    }
       public String formatCpf2(String cpf){
        String cpf1 = "";
        String cpf2 = "";
           if(!cpf.isEmpty()){
          String bloco1 = cpf.substring(0, 3);
          String bloco2 = cpf.substring(3, 6);
          String bloco3 = cpf.substring(6, 9);
	  String bloco4 = cpf.substring(9, 11);
	//cpf = bloco1+"."+bloco2+"."+bloco3+"-"+bloco4;
        cpf1 = cpf.replace(".", "");
        cpf2 = cpf1.replace("-", "");
	//cpf = String.format("%s"+"%s"+"%s"+"%s", bloco1, bloco2, bloco3, bloco4);
        }else{
            
        }
        return cpf2;
    }
    
    public boolean validaCpf(String cpf){
          boolean verifica = false;
          int verificacaso1 = 0, verificacaso2 = 0;
          String letra1 = cpf.substring(0, 1);
          String letra2 = cpf.substring(1, 2);
          String letra3 = cpf.substring(2, 3);
	  String letra4 = cpf.substring(3, 4);
	  String letra5 = cpf.substring(4, 5);
	  String letra6 = cpf.substring(5, 6);
	  String letra7 = cpf.substring(6, 7);
	  String letra8 = cpf.substring(7, 8);
	  String letra9 = cpf.substring(8, 9);
	  String digito1 = cpf.substring(9, 10);
	  String digito2 = cpf.substring(10, 11);
          
          int mult1 = Integer.parseInt(letra1) * 2;
          int mult2 = Integer.parseInt(letra2) * 3;
          int mult3 = Integer.parseInt(letra3) * 4;
          int mult4 = Integer.parseInt(letra4) * 5;
          int mult5 = Integer.parseInt(letra5) * 6;
          int mult6 = Integer.parseInt(letra6) * 7;
          int mult7 = Integer.parseInt(letra7) * 8;
          int mult8 = Integer.parseInt(letra8) * 9;
          int mult9 = Integer.parseInt(letra9) * 10;

          int resultMult = mult1 + mult2 + mult3 + mult4 + mult5 + mult6 + mult7 + mult8 + mult9;
          int resto = (resultMult%11);
          int dv1 = -1;
          if(resto < 2){
              dv1 = 0;
          }else{
              dv1 = 11 - resto;
          }
          
          //System.out.println(dv1);
          int mult19 = dv1 * 2;
          int mult10 = Integer.parseInt(letra1) * 3;
          int mult11 = Integer.parseInt(letra2) * 4;
          int mult12 = Integer.parseInt(letra3) * 5;
          int mult13 = Integer.parseInt(letra4) * 6;
          int mult14 = Integer.parseInt(letra5) * 7;
          int mult15 = Integer.parseInt(letra6) * 8;
          int mult16 = Integer.parseInt(letra7) * 9;
          int mult17 = Integer.parseInt(letra8) * 10;
          int mult18 = Integer.parseInt(letra9) * 11;
          
          int resultMult2 = mult10 + mult11 + mult12 + mult13 + mult14 + mult15 + mult16 + mult17 + mult18 + mult19;
          int resto2 = (resultMult2%11);
          int dv2 = -1;
          if(resto2 < 2){
              dv2 = 0;
          }else{
              dv2 = 11 - resto2;
          }
          //System.out.println(dv2);

          if(String.valueOf(dv1).equals(digito2) && String.valueOf(dv2).equals(digito1)){
              verificacaso1 = 1;
          }
          if(!cpf.equals("00000000000") && !cpf.equals("11111111111") && !cpf.equals("22222222222") && !cpf.equals("33333333333") && !cpf.equals("44444444444") && !cpf.equals("55555555555") && !cpf.equals("66666666666") && !cpf.equals("77777777777") && !cpf.equals("88888888888") && !cpf.equals("99999999999") && cpf.trim().length() == 11){
              verificacaso2 = 1;
          }
          
          if(verificacaso1 == 1 && verificacaso2 == 1){
              verifica = true;
          }
          //System.out.println(digito1+digito2+dv1+dv2);
          //JOptionPane.showMessageDialog(null, "Letra 1: "+letra1+"\n Letra 2: "+letra2+"\nLetra 3: "+letra3+"\nLetra 4: "+letra4+"\nLetra 5: "+letra5+"\nLetra 6: "+letra6+"\nLetra 7: "+letra7+"\nLetra 8: "+letra8+"\nLetra 9: "+letra9);
        return verifica;
    }
}
