package fornecedor;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Fornecedordao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Fornecedordao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Fornecedor f) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        String sql = "INSERT INTO fornecedor(nome, endereco, bairro, cep, cidade, estado, telefone, cnpj, representante, telefone_representante) VALUES(?,?,?,?,?,?,?,?,?,?)";
        ResultSet rs = null;
        try {
            PreparedStatement s = conexao.prepareStatement("select * from fornecedor");

            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_fornecedor() == rs.getInt("id_fornecedor")) {
                    verifica = 1;
                }
            }
            if (verifica == 0) {
                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, f.getNome());
                stmt.setString(2, f.getEndereco());
                stmt.setString(3, f.getBairro());
                stmt.setString(4, f.getCep());
                stmt.setString(5, f.getCidade());
                stmt.setString(6, f.getEstado());
                stmt.setString(7, f.getTelefone());
                stmt.setString(8, f.getCnpj());
                stmt.setString(9, f.getRepresentante());
                stmt.setString(10, f.getTelefone_representante());

                stmt.execute();
                stmt.close();
                JOptionPane.showMessageDialog(null, "FORNECEDOR CADASTRADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "FORNECEDOR JÁ CADASTRADO!");
            }
        } catch (SQLException u) {
            System.out.println("erro");
        }
    }

    public void altera(Fornecedor f) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {

            ResultSet rs = null;
            String sql = "UPDATE fornecedor set nome=?, endereco=?, bairro=?, cep=?, cidade=?, estado=?, telefone=?, cnpj=?, representante=?, telefone_representante=? where id_fornecedor=?";
            PreparedStatement s = conexao.prepareStatement("select * from fornecedor");

            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_fornecedor() == rs.getInt("id_fornecedor")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, f.getNome());
                stmt.setString(2, f.getEndereco());
                stmt.setString(3, f.getBairro());
                stmt.setString(4, f.getCep());
                stmt.setString(5, f.getCidade());
                stmt.setString(6, f.getEstado());
                stmt.setString(7, f.getTelefone());
                stmt.setString(8, f.getCnpj());
                stmt.setString(9, f.getRepresentante());
                stmt.setString(10, f.getTelefone_representante());
                stmt.setInt(11, f.getId_fornecedor());
                stmt.executeUpdate();
                stmt.close();
                JOptionPane.showMessageDialog(null, "FORNECEDOR EDITADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "FORNECEDOR NÃO CADASTRADO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao editar" + e);
        }
    }

    public void excluir(Fornecedor f) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {
            ResultSet rs = null;
            String sql = "DELETE FROM fornecedor WHERE id_fornecedor=? ";
            PreparedStatement s = conexao.prepareStatement("select * from fornecedor");

            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_fornecedor() == rs.getInt("id_fornecedor")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setInt(1, f.getId_fornecedor());
                stmt.execute();
                stmt.close();
                JOptionPane.showMessageDialog(null, "FORNECEDOR DELETADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "FORNECEDOR NÃO CADASTRADO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir" + e);
        }
    }

    public List<Fornecedor> listar() throws SQLException {
        List<Fornecedor> fornecedor = new ArrayList<Fornecedor>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from fornecedor");

            rs = sql.executeQuery();

            while (rs.next()) {

                Fornecedor f = new Fornecedor();

                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setCnpj(rs.getString("cnpj"));
                f.setRepresentante(rs.getString("representante"));
                f.setTelefone_representante(rs.getString("telefone_representante"));
                fornecedor.add(f);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (fornecedor);
    }

    public Fornecedor fornecedor(int id_f) throws SQLException {
        Fornecedor f = new Fornecedor();
        int verifica = 0;
        ResultSet rs = null;

        PreparedStatement sql = conexao.prepareStatement("select * from fornecedor");

        rs = sql.executeQuery();

        while (rs.next()) {

            if (rs.getInt("id_fornecedor") == id_f) {
                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setCnpj(rs.getString("cnpj"));
                f.setRepresentante(rs.getString("representante"));
                f.setTelefone_representante(rs.getString("telefone_representante"));
                verifica = 1;
            }
        }
        if (verifica == 0) {
            JOptionPane.showMessageDialog(null, "FORNECEDOR NÃO CADASTRADO!");
        }
        return f;
    }
    public Fornecedor fornecedor_p(int id_f) throws SQLException {
        Fornecedor f = new Fornecedor();
        int verifica = 0;
        ResultSet rs = null;

        PreparedStatement sql = conexao.prepareStatement("select * from fornecedor");

        rs = sql.executeQuery();

        while (rs.next()) {

            if (rs.getInt("id_fornecedor") == id_f) {
                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setCnpj(rs.getString("cnpj"));
                f.setRepresentante(rs.getString("representante"));
                f.setTelefone_representante(rs.getString("telefone_representante"));
                verifica = 1;
            }
        }
        if (verifica == 0) {
//            JOptionPane.showMessageDialog(null, "FORNECEDOR NÃO CADASTRADO!");
        }
        return f;
    }
        public Fornecedor fornecedor_nome(String id_f) throws SQLException {
        Fornecedor f = new Fornecedor();
        int verifica = 0;
        ResultSet rs = null;

        PreparedStatement sql = conexao.prepareStatement("select * from fornecedor");

        rs = sql.executeQuery();

        while (rs.next()) {

            if (rs.getString("nome").equals(id_f)) {
                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setCnpj(rs.getString("cnpj"));
                f.setRepresentante(rs.getString("representante"));
                f.setTelefone_representante(rs.getString("telefone_representante"));
                verifica = 1;
            }
        }
        if (verifica == 0) {
//            JOptionPane.showMessageDialog(null, "FORNECEDOR NÃO CADASTRADO!");
        }
        return f;
    }
        public int fornecedor_pesq(int id_f) throws SQLException {
        Fornecedor f = new Fornecedor();
        int verifica = 0;
        ResultSet rs = null;

        PreparedStatement sql = conexao.prepareStatement("select * from fornecedor");

        rs = sql.executeQuery();

        while (rs.next()) {

            if (rs.getInt("id_fornecedor") == id_f) {
                f.setId_fornecedor(rs.getInt("id_fornecedor"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setCnpj(rs.getString("cnpj"));
                f.setRepresentante(rs.getString("representante"));
                f.setTelefone_representante(rs.getString("telefone_representante"));
                verifica = 1;
            }
        }
        if (verifica == 0) {
            JOptionPane.showMessageDialog(null, "FORNECEDOR NÃO CADASTRADO!");
        }
        return verifica;
    }
}
