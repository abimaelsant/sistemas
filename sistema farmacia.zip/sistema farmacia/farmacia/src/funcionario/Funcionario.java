package funcionario;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import produto.Produtodao;

public class Funcionario {
    private int id_funcionario;
    private String nome;
    private String endereco;
    private String bairro;
    private String cep;
    private String cidade;
    private String estado;
    private String telefone;
    private String funcao;
    private float salario;
    private float comissao;

    public Funcionario(){}
    
    public int getId_funcionario() {
        return id_funcionario;
    }

    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getComissao() {
        return comissao;
    }

    public void setComissao(float comissao) {
        this.comissao = comissao;
    }
    
    public List<Funcionario> lista(String nome) throws SQLException{
        List<Funcionario> l = new ArrayList<>();
        List<Funcionario> l2 = new ArrayList<>();
        Funcionariodao dao = new Funcionariodao();
        Produtodao daop = new Produtodao();
        
        l = dao.listar();
        
        for(int i = 0; i < l.size(); i++){
           String n = l.get(i).getNome();
           if(n.equals("xela")){
               System.out.println("ddddddddddddddddddd");
           }
            //if(daop.removerAcentos(l.get(i).getNome()).equals(daop.removerAcentos("Abimael santiago"))){
            System.out.println("Nome: "+n);
           //}
        }
        return l2;
    }
}
