package funcionario;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import produto.Produtodao;

public class Funcionariodao {
    
   
    public void cadastro(Funcionario f) throws SQLException, UnknownHostException, IOException {
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        int verifica = 0;
        String sql = "INSERT INTO funcionario(nome, endereco, bairro, cep, cidade, estado, telefone, funcao, salario) VALUES(?,?,?,?,?,?,?,?,?)";
         PreparedStatement s = conexao.prepareStatement("select * from funcionario");
         ResultSet rs = null;
            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_funcionario() == rs.getInt("id_funcionario")) {
                    verifica = 1;
                }
            }
            if (verifica == 0) {

        PreparedStatement stmt = conexao.prepareStatement(sql);

        stmt.setString(1, f.getNome());
        stmt.setString(2, f.getEndereco());
        stmt.setString(3, f.getBairro());
        stmt.setString(4, f.getCep());
        stmt.setString(5, f.getCidade());
        stmt.setString(6, f.getEstado());
        stmt.setString(7, f.getTelefone());
        stmt.setString(8, f.getFuncao());
        stmt.setFloat(9, f.getSalario());
        stmt.execute();
        stmt.close();
        JOptionPane.showMessageDialog(null, "FUNCIONARIO CADASTRADO COM SUCESSO!");
            }else{
               JOptionPane.showMessageDialog(null, "FUNCIONARIO JÁ CADASTRADO!");
                
            }
            }

    public void altera(Funcionario f) throws SQLException, UnknownHostException, IOException {
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        int verifica = 0;
        try {

            ResultSet rs = null;
            String sql = "UPDATE funcionario set nome=?, endereco=?, bairro=?, cep=?, cidade=?, estado=?, telefone=?, funcao=?, salario=? where id_funcionario=?";
            PreparedStatement s = conexao.prepareStatement("select * from funcionario");

            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_funcionario() == rs.getInt("id_funcionario")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, f.getNome());
                stmt.setString(2, f.getEndereco());
                stmt.setString(3, f.getBairro());
                stmt.setString(4, f.getCep());
                stmt.setString(5, f.getCidade());
                stmt.setString(6, f.getEstado());
                stmt.setString(7, f.getTelefone());
                stmt.setString(8, f.getFuncao());
                stmt.setFloat(9, f.getSalario());
                stmt.setInt(10, f.getId_funcionario());
                stmt.executeUpdate();
                stmt.close();
                JOptionPane.showMessageDialog(null, "FUNCIONARIO EDITADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "FUNCIONARIO NÃO CADASTRADO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao editar" + e);
        }
    }

    public void excluir(Funcionario f) throws SQLException, UnknownHostException, IOException {
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        int verifica = 0;
        try {
            ResultSet rs = null;
            String sql = "DELETE FROM funcionario WHERE id_funcionario=? ";
            PreparedStatement s = conexao.prepareStatement("select * from funcionario");

            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_funcionario() == rs.getInt("id_funcionario")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setInt(1, f.getId_funcionario());
                stmt.execute();
                stmt.close();
                JOptionPane.showMessageDialog(null, "FUNCIONARIO DELETADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "FUNCIONARIO NÃO CADASTRADO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir" + e);
        }
    }

    public List<Funcionario> listar() throws SQLException {
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        List<Funcionario> funcionario = new ArrayList<Funcionario>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from funcionario");

            rs = sql.executeQuery();

            while (rs.next()) {

                Funcionario f = new Funcionario();

                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setFuncao(rs.getString("funcao"));
                f.setSalario(rs.getFloat("salario"));
                funcionario.add(f);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (funcionario);
    }
    public Funcionario funcionario(int id_f) throws SQLException{
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        ResultSet rs = null;
        int verifica = 0;
        Funcionario f = new Funcionario();
            PreparedStatement sql = conexao.prepareStatement("select * from funcionario");

            rs = sql.executeQuery();

            while (rs.next()) {

              if(rs.getInt("id_funcionario") == id_f){
                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setFuncao(rs.getString("funcao"));
                f.setSalario(rs.getFloat("salario"));
                verifica = 1;
              }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "FUNCIONÁRIO NÃO CADASTRADO!");
            }
            return f;
    }
    public Funcionario funcionariof(int id_f) throws SQLException{
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        ResultSet rs = null;
        int verifica = 0;
        Funcionario f = new Funcionario();
            PreparedStatement sql = conexao.prepareStatement("select * from funcionario");

            rs = sql.executeQuery();

            while (rs.next()) {

              if(rs.getInt("id_funcionario") == id_f){
                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setFuncao(rs.getString("funcao"));
                f.setSalario(rs.getFloat("salario"));
                verifica = 1;
              }
            }
            if(verifica == 0){
                //JOptionPane.showMessageDialog(null, "FUNCIONÁRIO NÃO CADASTRADO!");
            }
            return f;
    }
    
    public List<Funcionario> listar_nome(String nome) throws SQLException {
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
        Produtodao daop = new Produtodao();

        List<Funcionario> funcionario = new ArrayList<>();
 
        int verifica = 0;
        ResultSet rs = null;

            PreparedStatement sql = conexao.prepareStatement("select * from funcionario");

            rs = sql.executeQuery();

            while (rs.next()) {
                Funcionario f = new Funcionario();
               if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome))){

                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setFuncao(rs.getString("funcao"));
                f.setSalario(rs.getFloat("salario"));
                verifica = 1;
                funcionario.add(f);
        
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "FUNCIONÁRIO NÃO CADASTRADO!");
            }
        return (funcionario);
    }
       public List<Funcionario> listar_nome2(String nome) throws SQLException {
        Conexao conexoes = new Conexao();
    Connection conexao;
    
    
    conexao = conexoes.conexao();
    
           List<Funcionario> funcionario = new ArrayList<Funcionario>();
        int verifica = 0;
        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from funcionario");

            rs = sql.executeQuery();

            while (rs.next()) {

                Funcionario f = new Funcionario();
                Produtodao daop = new Produtodao();
               if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome))){
                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setNome(rs.getString("nome"));
                f.setEndereco(rs.getString("endereco"));
                f.setBairro(rs.getString("bairro"));
                f.setCep(rs.getString("cep"));
                f.setCidade(rs.getString("cidade"));
                f.setEstado(rs.getString("estado"));
                f.setTelefone(rs.getString("telefone"));
                f.setFuncao(rs.getString("funcao"));
                f.setSalario(rs.getFloat("salario"));
                funcionario.add(f);
                verifica = 1;
               }
            }
            if(verifica == 0){
               // JOptionPane.showMessageDialog(null, "FUNCIONÁRIO NÃO CADASTRADO!");
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (funcionario);
    }
}
