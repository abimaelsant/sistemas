package forma_pagamento;

public class Forma_pagamento {
    private int id_forma_pagamento;
    private String nome;
    
    public Forma_pagamento(){}

    public Forma_pagamento(int id_forma_pagamento, String nome) {
        this.id_forma_pagamento = id_forma_pagamento;
        this.nome = nome;
    }

    public int getId_forma_pagamento() {
        return id_forma_pagamento;
    }

    public void setId_forma_pagamento(int id_forma_pagamento) {
        this.id_forma_pagamento = id_forma_pagamento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
