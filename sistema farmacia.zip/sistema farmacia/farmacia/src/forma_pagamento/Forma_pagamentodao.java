package forma_pagamento;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Forma_pagamentodao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Forma_pagamentodao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public List<Forma_pagamento> listar() throws SQLException {
        List<Forma_pagamento> fp = new ArrayList<Forma_pagamento>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from forma_pagamento");

            rs = sql.executeQuery();

            while (rs.next()) {

                Forma_pagamento formap = new Forma_pagamento();

                formap.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                formap.setNome(rs.getString("nome"));
                fp.add(formap);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (fp);
    }
    public Forma_pagamento forma_p(int id_f) throws SQLException{
        ResultSet rs = null;
        int verifica = 0;
        Forma_pagamento formap = new Forma_pagamento();

            PreparedStatement sql = conexao.prepareStatement("select * from forma_pagamento");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getInt("id_forma_pagamento") == id_f){
             
                formap.setId_forma_pagamento(rs.getInt("id_forma_pagamento"));
                formap.setNome(rs.getString("nome"));
                verifica = 1;
              }
            }
            if(verifica == 0){
            }
        return formap;
    }
}
