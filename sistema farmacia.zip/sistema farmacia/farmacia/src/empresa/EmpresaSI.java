package empresa;

import cliente.Cliente;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class EmpresaSI extends javax.swing.JInternalFrame {

    public EmpresaSI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        end = new javax.swing.JTextField();
        cep = new javax.swing.JTextField();
        tel = new javax.swing.JTextField();
        cnpj = new javax.swing.JTextField();
        inscestadual = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        obs = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        salvar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        id_p = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        emp_pesqui = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        msg = new javax.swing.JLabel();
        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        b9 = new javax.swing.JButton();
        bairro = new javax.swing.JTextField();
        cidade = new javax.swing.JTextField();
        estado = new javax.swing.JTextField();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Nome:  ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Endereço:  ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Bairro:  ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Cep:   ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("Cidade:  ");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Estado:  ");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("Telefone:  ");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 20, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("CNPJ:   ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("Inscrição Estad:  ");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 120, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("Email:   ");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Obsevação:   ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, -1, -1));

        nome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                nomeFocusGained(evt);
            }
        });
        nome.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nomeKeyPressed(evt);
            }
        });
        getContentPane().add(nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 180, 30));

        end.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                endFocusGained(evt);
            }
        });
        getContentPane().add(end, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 180, 30));

        cep.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cepFocusGained(evt);
            }
        });
        getContentPane().add(cep, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 180, 30));

        tel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                telFocusGained(evt);
            }
        });
        getContentPane().add(tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, 170, 30));

        cnpj.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cnpjFocusGained(evt);
            }
        });
        cnpj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                cnpjKeyPressed(evt);
            }
        });
        getContentPane().add(cnpj, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 170, 30));

        inscestadual.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                inscestadualFocusGained(evt);
            }
        });
        getContentPane().add(inscestadual, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 110, 170, 30));

        email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                emailFocusLost(evt);
            }
        });
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 150, 170, 30));

        obs.setColumns(20);
        obs.setRows(5);
        jScrollPane1.setViewportView(obs);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 200, 180, 60));

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Telefone", "CNPJ", "Insc. Estadual", "Email"
            }
        ));
        tabela.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabela);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 740, 180));

        salvar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        salvar.setForeground(new java.awt.Color(0, 51, 153));
        salvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/save 1.png"))); // NOI18N
        salvar.setText("Salvar");
        salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarActionPerformed(evt);
            }
        });
        getContentPane().add(salvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, -1, 40));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 51, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 1.png"))); // NOI18N
        jButton2.setText("Editar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, -1, 40));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("CNPJ: ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 50, 50, -1));

        id_p.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_pActionPerformed(evt);
            }
        });
        getContentPane().add(id_p, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 80, 130, 30));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 51, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 2.png"))); // NOI18N
        jButton3.setText("Pesquisar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 120, -1, 40));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(jTable2);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 30, 150, 340));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 51, 153));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/listar 2.png"))); // NOI18N
        jButton4.setText("Listar Empresas");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));

        jButton5.setBackground(new java.awt.Color(255, 255, 255));
        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 0, 51));
        jButton5.setText("Sair");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 0, -1, -1));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 51, 153));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit_clear.png"))); // NOI18N
        jButton6.setText("Limpar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, -1, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("Id: ");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 290, -1, -1));

        id.setEnabled(false);
        getContentPane().add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 290, 90, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Nome da Empresa:   ");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 390, -1, -1));
        getContentPane().add(emp_pesqui, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 380, 210, 30));

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 51, 153));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 2.png"))); // NOI18N
        jButton7.setText("Pesquisar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 380, 150, -1));

        msg.setForeground(new java.awt.Color(255, 0, 0));
        getContentPane().add(msg, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 204, 280, 20));

        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });
        getContentPane().add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 10));

        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });
        getContentPane().add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, -1, 10));

        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });
        getContentPane().add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 0, -1, 10));

        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });
        getContentPane().add(b4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 0, -1, 10));

        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });
        getContentPane().add(b5, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 1, -1, -1));

        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });
        getContentPane().add(b6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, -1, 10));

        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });
        getContentPane().add(b7, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, -1, 10));

        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });
        getContentPane().add(b8, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, -1, 10));

        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });
        getContentPane().add(b9, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, -1, 10));

        bairro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                bairroFocusGained(evt);
            }
        });
        getContentPane().add(bairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 180, 30));

        cidade.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cidadeFocusGained(evt);
            }
        });
        getContentPane().add(cidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, 180, 30));

        estado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                estadoFocusGained(evt);
            }
        });
        getContentPane().add(estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 180, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    String verifica_nome = null;
    private void id_pActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_pActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_pActionPerformed

    private void salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarActionPerformed
        Empresa empresa = new Empresa();
        try {
            Empresadao dao = new Empresadao();
            int id_e = 0;
            if (!id.getText().isEmpty()) {
                id_e = Integer.parseInt(id.getText());
            }
            empresa.setId_empresa(id_e);
            empresa.setNome(nome.getText());
            empresa.setEndereco(end.getText());
            empresa.setBairro(bairro.getText());
            empresa.setCep(cep.getText());
            empresa.setCidade(cidade.getText());
            empresa.setEstado(estado.getText());
            empresa.setTelefone(tel.getText());
            empresa.setCnpj(cnpj.getText());
            empresa.setInscricao_estadual(inscestadual.getText());
            empresa.setEmail(email.getText());
            empresa.setObservacao(obs.getText());
            boolean ver = empresa.validaCNPJ(cnpj.getText());
            if (ver == true) {
                dao.cadastro(empresa);
            } else {
                JOptionPane.showMessageDialog(null, "CNPJ INVÁLIDO!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_salvarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Empresa empresa = new Empresa();
        try {
            Empresadao dao = new Empresadao();
            empresa.setId_empresa(Integer.parseInt(id.getText()));
            empresa.setNome(nome.getText());
            empresa.setEndereco(end.getText());
            empresa.setBairro(bairro.getText());
            empresa.setCep(cep.getText());
            empresa.setCidade(cidade.getText());
            empresa.setEstado(estado.getText());
            empresa.setTelefone(tel.getText());
            empresa.setCnpj(cnpj.getText());
            empresa.setInscricao_estadual(inscestadual.getText());
            empresa.setEmail(email.getText());
            empresa.setObservacao(obs.getText());
            dao.altera(empresa);
            //cnpj.setEnabled(true);
            List<Empresa> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            if (verifica_nome == null) {
                lista = dao.listar();
            } else {
                lista = dao.listar_nome_contas_pagar(verifica_nome);
            }
            Collections.sort(lista, new Comparator<Empresa>() {
                public int compare(Empresa p1, Empresa p2) {
                    return p1.getNome().toUpperCase().compareTo(p2.getNome().toUpperCase());
                }
            });
            for (int i = 0; i < lista.size(); i++) {
                String cnpj_emp = empresa.formatCNPJ(lista.get(i).getCnpj());
                table.addRow(new Object[]{ lista.get(i).getNome(), lista.get(i).getTelefone(), cnpj_emp, lista.get(i).getInscricao_estadual(), lista.get(i).getEmail()});
            }

        } catch (SQLException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        nome.setText("");
        end.setText("");
        bairro.setText("");
        cep.setText("");
        cidade.setText("");
        estado.setText("");
        tel.setText("");
        cnpj.setText("");
        inscestadual.setText("");
        email.setText("");
        obs.setText("");
        id_p.setText("");
        id.setText("");
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        emp_pesqui.setText("");
        cnpj.setEnabled(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            Empresadao dao = new Empresadao();
            Empresa empresa = new Empresa();
            //int e_id = Integer.parseInt(id_p.getText());

            empresa = dao.pesquisacnpj(id_p.getText());
            nome.setText(empresa.getNome());
            end.setText(empresa.getEndereco());
            bairro.setText(empresa.getBairro());
            cep.setText(empresa.getCep());
            cidade.setText(empresa.getCidade());
            estado.setText(empresa.getEstado());
            tel.setText(empresa.getTelefone());
            cnpj.setText(empresa.getCnpj());
            inscestadual.setText(empresa.getInscricao_estadual());
            email.setText(empresa.getEmail());
            obs.setText(empresa.getObservacao());
            id.setText(String.valueOf(empresa.getId_empresa()));
            id_p.setText("");
            cnpj.setEnabled(false);
        } catch (SQLException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Empresa empresa = new Empresa();
        try {
            verifica_nome = null;
            Empresadao dao = new Empresadao();
            List<Empresa> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            lista = dao.listar();
            Collections.sort(lista, new Comparator<Empresa>() {
                public int compare(Empresa p1, Empresa p2) {
                    return p1.getNome().toUpperCase().compareTo(p2.getNome().toUpperCase());
                }
            });
            for (int i = 0; i < lista.size(); i++) {
                String cnpj_emp = empresa.formatCNPJ(lista.get(i).getCnpj());
                table.addRow(new Object[]{lista.get(i).getNome(), lista.get(i).getTelefone(), cnpj_emp, lista.get(i).getInscricao_estadual(), lista.get(i).getEmail()});
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        Empresa empresa = new Empresa();
        try {
            Empresadao dao = new Empresadao();
            List<Empresa> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            if (!emp_pesqui.getText().isEmpty()) {
                int teste = dao.pesquisa_pesq(emp_pesqui.getText());
                if (teste == 1) {
                    lista = dao.listar_nome_contas_pagar(emp_pesqui.getText());
                    Collections.sort(lista, new Comparator<Empresa>() {
                        public int compare(Empresa p1, Empresa p2) {
                            return p1.getNome().toUpperCase().compareTo(p2.getNome().toUpperCase());
                        }
                    });
                    verifica_nome = emp_pesqui.getText();
                    for (int i = 0; i < lista.size(); i++) {
                        String cnpj_emp = empresa.formatCNPJ(lista.get(i).getCnpj());
                        table.addRow(new Object[]{lista.get(i).getNome(), lista.get(i).getTelefone(), cnpj_emp, lista.get(i).getInscricao_estadual(), lista.get(i).getEmail()});
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emailFocusLost
        if ((email.getText().contains("@"))
                && (email.getText().contains("."))
                && (!email.getText().contains(" "))) {

            String usuario = new String(email.getText().substring(0,
                    email.getText().lastIndexOf('@')));

            String dominio = new String(email.getText().substring(email.getText().lastIndexOf('@') + 1, email.getText().length()));

            if ((usuario.length() >= 1) && (!usuario.contains("@"))
                    && (dominio.contains(".")) && (!dominio.contains("@")) && (dominio.indexOf(".")
                    >= 1) && (dominio.lastIndexOf(".") < dominio.length() - 1)) {

                msg.setText("");

            } else {

                msg.setText("E-mail Inválido");

                email.requestFocus();

            }

        } else {

            msg.setText("E-mail Inválido");

            email.requestFocus();

        }

    }//GEN-LAST:event_emailFocusLost

    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void cnpjKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cnpjKeyPressed
         if(!id.getText().isEmpty()){
        getRootPane().setDefaultButton(salvar);
        salvar.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    salvar.doClick();
		}
	      }
        });
       }
    }//GEN-LAST:event_cnpjKeyPressed

    private void tabelaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelaMouseClicked
        if(evt.getClickCount() == 1){  
         Object obj  = (tabela.getValueAt(tabela.getSelectedRow(), 2));
         String Id = obj.toString();
                 try {
            Empresadao dao = new Empresadao();
            Empresa empresa = new Empresa();
            //int e_id = Integer.parseInt(id_p.getText());

            empresa = dao.pesquisacnpj(empresa.formatCNPJ2(Id));
            nome.setText(empresa.getNome());
            end.setText(empresa.getEndereco());
            bairro.setText(empresa.getBairro());
            cep.setText(empresa.getCep());
            cidade.setText(empresa.getCidade());
            estado.setText(empresa.getEstado());
            tel.setText(empresa.getTelefone());
            cnpj.setText(empresa.getCnpj());
            inscestadual.setText(empresa.getInscricao_estadual());
            email.setText(empresa.getEmail());
            obs.setText(empresa.getObservacao());
            id.setText(String.valueOf(empresa.getId_empresa()));
            id_p.setText("");
            cnpj.setEnabled(false);
        } catch (SQLException ex) {
            Logger.getLogger(EmpresaSI.class.getName()).log(Level.SEVERE, null, ex);
        }

        }
    }//GEN-LAST:event_tabelaMouseClicked

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        cidade.requestFocus();
    }//GEN-LAST:event_b4ActionPerformed

    private void nomeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomeKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomeKeyPressed

    private void nomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_nomeFocusGained
               getRootPane().setDefaultButton(b1);
        b1.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b1.doClick();
		}
	      }
        });

    }//GEN-LAST:event_nomeFocusGained

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        end.requestFocus();
    }//GEN-LAST:event_b1ActionPerformed

    private void endFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_endFocusGained
        getRootPane().setDefaultButton(b2);
        b2.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b2.doClick();
		}
	      }
        });

    }//GEN-LAST:event_endFocusGained

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        bairro.requestFocus();
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        cep.requestFocus();
    }//GEN-LAST:event_b3ActionPerformed

    private void cepFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cepFocusGained
               getRootPane().setDefaultButton(b4);
        b4.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b4.doClick();
		}
	      }
        });

    }//GEN-LAST:event_cepFocusGained

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        estado.requestFocus();
    }//GEN-LAST:event_b5ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        tel.requestFocus();

    }//GEN-LAST:event_b6ActionPerformed

    private void telFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_telFocusGained
           getRootPane().setDefaultButton(b7);
        b7.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b7.doClick();
		}
	      }
        });
    }//GEN-LAST:event_telFocusGained

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        cnpj.requestFocus();
    }//GEN-LAST:event_b7ActionPerformed

    private void cnpjFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cnpjFocusGained
        getRootPane().setDefaultButton(b8);
        b8.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b8.doClick();
		}
	      }
        });
    }//GEN-LAST:event_cnpjFocusGained

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
       inscestadual.requestFocus();
    }//GEN-LAST:event_b8ActionPerformed

    private void inscestadualFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_inscestadualFocusGained
        getRootPane().setDefaultButton(b9);
        b9.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b9.doClick();
		}
	      }
        });
    }//GEN-LAST:event_inscestadualFocusGained

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        email.requestFocus();
    }//GEN-LAST:event_b9ActionPerformed

    private void bairroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_bairroFocusGained
                getRootPane().setDefaultButton(b3);
        b3.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    b3.doClick();
                }
            }
        });
    }//GEN-LAST:event_bairroFocusGained

    private void cidadeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cidadeFocusGained
               getRootPane().setDefaultButton(b5);
        b5.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b5.doClick();
		}
	      }
        });

    }//GEN-LAST:event_cidadeFocusGained

    private void estadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_estadoFocusGained
               getRootPane().setDefaultButton(b6);
        b6.addKeyListener(new KeyAdapter() {
              public void keyPressed(KeyEvent e) {
	        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
		    b6.doClick();
		}
	      }
        });

    }//GEN-LAST:event_estadoFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    private javax.swing.JTextField bairro;
    private javax.swing.JTextField cep;
    private javax.swing.JTextField cidade;
    private javax.swing.JTextField cnpj;
    private javax.swing.JTextField email;
    private javax.swing.JTextField emp_pesqui;
    private javax.swing.JTextField end;
    private javax.swing.JTextField estado;
    private javax.swing.JTextField id;
    private javax.swing.JTextField id_p;
    private javax.swing.JTextField inscestadual;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel msg;
    private javax.swing.JTextField nome;
    private javax.swing.JTextArea obs;
    private javax.swing.JButton salvar;
    private javax.swing.JTable tabela;
    private javax.swing.JTextField tel;
    // End of variables declaration//GEN-END:variables
}
