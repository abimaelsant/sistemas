package empresa;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import produto.Produtodao;

public class Empresadao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Empresadao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Empresa e) throws SQLException, UnknownHostException, IOException {
        
            String sql = "INSERT INTO empresa(nome, endereco, bairro, cep, cidade, estado, telefone, cnpj, inscricao_estadual, email, observacao) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement s = conexao.prepareStatement("select * from empresa");
            ResultSet rs = null;
            int verifica = 0;
            rs = s.executeQuery();

           //while (rs.next()) {
             //if (e.getId_empresa() == rs.getInt("id_empresa")) {
               // verifica = 1;
            //}
        //}
         
            while (rs.next()) {
             if (e.getCnpj().equals(rs.getString("cnpj")) || e.getCnpj().equals("") || e.getCnpj() == null) {
                verifica = 1;
            }
                        // JOptionPane.showMessageDialog(null, e.getCnpj() + " ---- "+rs.getString("cnpj"));

            }
        if (verifica == 0) {
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getEndereco());
            stmt.setString(3, e.getBairro());
            stmt.setString(4, e.getCep());
            stmt.setString(5, e.getCidade());
            stmt.setString(6, e.getEstado());
            stmt.setString(7, e.getTelefone());
            stmt.setString(8, e.getCnpj());
            stmt.setString(9, e.getInscricao_estadual());
            stmt.setString(10, e.getEmail());
            stmt.setString(11, e.getObservacao());

            stmt.execute();
            stmt.close();
        
            JOptionPane.showMessageDialog(null, "EMPRESA CADASTRADA COM SUCESSO!");
        }else{
        
            JOptionPane.showMessageDialog(null, "EMPRESA JÁ CADASTRADA  OU CAMPO CNPJ ESTÁ VAZIO!");
        }
    }

    public void altera(Empresa e) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE empresa set nome=?, endereco=?, bairro=?, cep=?, cidade=?, estado=?, telefone=?, inscricao_estadual=?, email=?, observacao=? where cnpj=?";
        PreparedStatement s = conexao.prepareStatement("select * from empresa");

        rs = s.executeQuery();

        while (rs.next()) {
            if (e.getCnpj().equals(rs.getString("cnpj"))){
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, e.getNome());
            stmt.setString(2, e.getEndereco());
            stmt.setString(3, e.getBairro());
            stmt.setString(4, e.getCep());
            stmt.setString(5, e.getCidade());
            stmt.setString(6, e.getEstado());
            stmt.setString(7, e.getTelefone());
            stmt.setString(8, e.getInscricao_estadual());
            stmt.setString(9, e.getEmail());
            stmt.setString(10, e.getObservacao());
            stmt.setString(11, e.getCnpj());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "EMPRESA EDITADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
        }

    }

    public void excluir(Empresa e) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM empresa WHERE cnpj=? ";
        PreparedStatement s = conexao.prepareStatement("select * from empresa");

        rs = s.executeQuery();

        while (rs.next()) {
            if (e.getCnpj().equals(rs.getString("cnpj"))) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, e.getCnpj());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "EMPRESA DELETADA COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
        }

    }

    public List<Empresa> listar() throws SQLException {
        List<Empresa> empresa = new ArrayList<Empresa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Empresa e = new Empresa();
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                empresa.add(e);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (empresa);
    }

    public Empresa pesquisa(int e_id) throws SQLException {
        Empresa e = new Empresa();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getInt("id_empresa") == e_id){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
            }
         return e;
        }
    public Empresa pesquisacnpj(String c) throws SQLException {
        Empresa e = new Empresa();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getString("cnpj").equals(c)){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
            }
         return e;
        }
        public Empresa pesquisac(String c) throws SQLException {
        Empresa e = new Empresa();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(rs.getString("cnpj").equals(c)){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                //JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
            }
         return e;
        }
    public Empresa pesquisanome(String c) throws SQLException {
        Empresa e = new Empresa();
        Produtodao daop = new Produtodao();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(c))){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                //JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
            }
         return e;
        }
        public int pesquisa_pesq(String e_id) throws SQLException {
        Empresa e = new Empresa();
        Produtodao daop = new Produtodao();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(e_id))){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
            }
         return verifica;
        }
        
    public List<Empresa> listar_nome_contas_pagar(String nome_cnpj) throws SQLException {
        List<Empresa> empresa = new ArrayList<Empresa>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {

                Empresa e = new Empresa();
                Produtodao daop = new Produtodao();
                if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome_cnpj)) || rs.getString("cnpj").equals(nome_cnpj)){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                empresa.add(e);

            }
            }
        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (empresa);
    }

    
    public int pesquisanome_ver(String c) throws SQLException {
        Empresa e = new Empresa();
        Produtodao daop = new Produtodao();
        int verifica = 0; 
        ResultSet rs = null;

        
            PreparedStatement sql = conexao.prepareStatement("select * from empresa");

            rs = sql.executeQuery();

            while (rs.next()) {
               if((rs.getString("nome")).equals(c)){
                e.setId_empresa(rs.getInt("id_empresa"));
                e.setNome(rs.getString("nome"));
                e.setEndereco(rs.getString("endereco"));
                e.setBairro(rs.getString("bairro"));
                e.setCep(rs.getString("cep"));
                e.setCidade(rs.getString("cidade"));
                e.setEstado(rs.getString("estado"));
                e.setTelefone(rs.getString("telefone"));
                e.setCnpj(rs.getString("cnpj"));
                e.setInscricao_estadual(rs.getString("inscricao_estadual"));
                e.setEmail(rs.getString("email"));
                e.setObservacao(rs.getString("observacao"));
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "EMPRESA NÃO CADASTRADA!");
            }
         return verifica;
        }
    
    
    }
