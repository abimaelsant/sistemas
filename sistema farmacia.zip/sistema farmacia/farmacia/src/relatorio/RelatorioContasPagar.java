/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package relatorio;

import cliente.Clientedao;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import contas_pagar.Contas_pagar;
import contas_pagar.Contas_pagarSI;
import contas_pagar.Contas_pagardao;
import empresa.Empresa;
import empresa.Empresadao;
import forma_pagamento.Forma_pagamento;
import forma_pagamento.Forma_pagamentodao;
import fornecedor.Fornecedor;
import fornecedor.Fornecedordao;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Abimael
 */
public class RelatorioContasPagar extends javax.swing.JInternalFrame {

    /**
     * Creates new form RelatorioContasPagar
     */
    public RelatorioContasPagar() {
        initComponents();
    }
    List<Contas_pagar> lista = new ArrayList<>();
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Gerar Relatórios de Contas a Pagar");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 51, 153));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/listar 2.png"))); // NOI18N
        jButton1.setText("Preencher Tabela");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 260, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 51, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 3.png"))); // NOI18N
        jButton2.setText("Gerar Relatório");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 270, 40));

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nº", "Data da Compra", "Fornecedor", "Data VCTO", "Val da Dívida", "Nº de Prest.", "Forma de Pag."
            }
        ));
        jScrollPane1.setViewportView(tabela);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 680, 300));

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setForeground(new java.awt.Color(255, 0, 0));
        jButton3.setText("Sair");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 0, -1, -1));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 464, 70, 20));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            try {
            lista.clear();
            Contas_pagardao dao = new Contas_pagardao();
            Contas_pagar contas = new Contas_pagar();
            Fornecedordao daof = new Fornecedordao();
            Fornecedor f = new Fornecedor();
            Forma_pagamentodao daoform = new Forma_pagamentodao();
            Forma_pagamento fp = new Forma_pagamento();
            Empresa e = new Empresa();
            Empresadao edao = new Empresadao();
            
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            lista = dao.listar();
            DecimalFormat df = new DecimalFormat("0.00");
            for (int i = 0; i < lista.size(); i++) {
                e = edao.pesquisanome(lista.get(i).getId_fornecedor());
                fp = daoform.forma_p(lista.get(i).getId_forma_pagamento());
                String fpn = "";
                if(fp.getId_forma_pagamento() == 1){
                    fpn = "Venda \u00e0 Vista!";
                }
                 if(fp.getId_forma_pagamento() == 2){
                    fpn = "Venda \u00e0 Prazo!";
                }
                 if(fp.getId_forma_pagamento() == 3){
                    fpn = "Venda por Conv\u00eanio!";
                }
                 if(fp.getId_forma_pagamento() == 4){
                    fpn = "Venda no Cart\u00e3o de Cr\u00e9dito!";
                }
                 if(fp.getId_forma_pagamento() == 5){
                    fpn = "Venda no Cart\u00e3o de D\u00e9bito!";
                }
                
                table.addRow(new Object[]{lista.get(i).getId_contas_pagar(), lista.get(i).getData_compra(), e.getNome(), lista.get(i).getData_vcto(), df.format(lista.get(i).getValor_divida()), lista.get(i).getNumero_prestacao(), fpn});
            }
        } catch (SQLException ex) {
            Logger.getLogger(Contas_pagarSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Document doc = new Document(PageSize.A4.rotate());
            
        OutputStream os = null;

       
        try {
             Fornecedordao daof = new Fornecedordao();
            Fornecedor f = new Fornecedor();
            Forma_pagamentodao daoform = new Forma_pagamentodao();
            Forma_pagamento fp = new Forma_pagamento();
            DecimalFormat df = new DecimalFormat("0.00");
            Empresa e = new Empresa();
            Empresadao edao = new Empresadao();
            
            Empresa empresa = new Empresa();
            Clientedao dao = new Clientedao();
            Date d = new Date();
            Calendar cal = Calendar.getInstance();
            int dia = cal.get(Calendar.DATE);
            int mes = cal.get(Calendar.MONTH) + 1;
            int ano = cal.get(Calendar.YEAR);
            
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            Date hora = Calendar.getInstance().getTime();
            String dataFormatada = sdf.format(hora);
            String caminho = "C:\\Users\\Abimael\\Documents\\comprovantes vendas/contas_pagar --"+dia+mes+ano+" - "+d.getDay()+d.getMonth()+d.getYear()+d.getHours()+d.getMinutes()+d.getSeconds()+".pdf";
            os = new FileOutputStream(caminho);
            PdfWriter.getInstance(doc, os);

            doc.open();

           
            Paragraph p = new Paragraph("--------------------------------------------------------------------------------------------\n");
            p.setAlignment(Element.ALIGN_CENTER);
            float[] columnWidths = {70, 60, 60, 60, 60, 60, 60};
            Paragraph x = new Paragraph("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"
                    + "\nRELATÓRIO DE CONTAS A PAGAR CADASTRADAS NO SISTEMA --- DATA: "+dia+"/"+mes+"/"+ano+" HORA: "+dataFormatada+"\n\n                                                                                                   ");
            PdfPTable t = new PdfPTable(columnWidths);
           //Font f = new Font(Font.FontFamily.COURIER, 9f, Font.NORMAL);
            t.setWidthPercentage(100);
            t.addCell("ID");
            t.addCell("DATA DA COMPRA");
            t.addCell("FORNECEDOR");
            t.addCell("DATA DE VCTO");
            t.addCell("VALOR DA DÍVIDA");
            t.addCell("Nº DE PRESTAÇÕES");
            t.addCell("FORMA DE PAGAMENTO");
            
            for(int i = 0; i < lista.size(); i++){
                e = edao.pesquisanome(lista.get(i).getId_fornecedor());
                fp = daoform.forma_p(lista.get(i).getId_forma_pagamento());
                String fpn = "";
                if(fp.getId_forma_pagamento() == 1){
                    fpn = "Venda \u00e0 Vista!";
                }
                 if(fp.getId_forma_pagamento() == 2){
                    fpn = "Venda \u00e0 Prazo!";
                }
                 if(fp.getId_forma_pagamento() == 3){
                    fpn = "Venda por Conv\u00eanio!";
                }
                 if(fp.getId_forma_pagamento() == 4){
                    fpn = "Venda no Cart\u00e3o de Cr\u00e9dito!";
                }
                 if(fp.getId_forma_pagamento() == 5){
                    fpn = "Venda no Cart\u00e3o de D\u00e9bito!";
                }
                
                t.addCell(String.valueOf(lista.get(i).getId_contas_pagar()));
                t.addCell(lista.get(i).getData_compra());
                t.addCell(e.getNome());
                t.addCell(lista.get(i).getData_vcto());
                t.addCell(String.valueOf(lista.get(i).getValor_divida()));
                t.addCell(String.valueOf(lista.get(i).getNumero_prestacao()));
                t.addCell(fpn);
            }
            doc.add(x);
            doc.add(t);
            doc.close();
            JOptionPane.showMessageDialog(null, "RELATÓRIO GERADO COM SUCESSO! VERIFIQUE A PASTA DE DESTINO:  "+caminho);

        } catch (FileNotFoundException | DocumentException ex) {
            Logger.getLogger(RelatorioCliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(RelatorioCliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
