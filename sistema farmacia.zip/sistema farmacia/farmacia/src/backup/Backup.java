/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backup;

import conexao.Conexao;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author Abimael
 */
public class Backup extends javax.swing.JInternalFrame {

    Process proc;

    /**
     * Creates new form Backup
     */
    public Backup() {
        initComponents();
        janela.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        janela = new javax.swing.JFileChooser();
        b = new javax.swing.JButton();
        brestaurar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(janela, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 40, 670, 360));

        b.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        b.setForeground(new java.awt.Color(0, 51, 204));
        b.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/backup.png"))); // NOI18N
        b.setText("Realizar Backup");
        b.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActionPerformed(evt);
            }
        });
        getContentPane().add(b, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 240, -1));

        brestaurar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        brestaurar.setForeground(new java.awt.Color(0, 51, 204));
        brestaurar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/left.png"))); // NOI18N
        brestaurar.setText("Restaurar Backup");
        brestaurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brestaurarActionPerformed(evt);
            }
        });
        getContentPane().add(brestaurar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 240, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 300, 220));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("Sair");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActionPerformed

        try {
            String arquivo = null, banco = "farmacia";
            Conexao c = new Conexao();
            c.conexao();

            janela.setVisible(true);

            int result = janela.showSaveDialog(null);

            if (result == JFileChooser.APPROVE_OPTION) {
                arquivo = janela.getSelectedFile().toString().concat(".sql");

                File file = new File(arquivo);

                if (file.exists()) {
                    Object[] options = {"Sim", "Não"};
                    int opcao = JOptionPane.showOptionDialog(null, "Este arquivo já existe. Quer sobreescrever este arquivo?", "Atenção!!!",
                            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                    if (opcao == JOptionPane.YES_OPTION) {
                        FileWriter fw = new FileWriter(file);
                        Runtime bck = Runtime.getRuntime();
                        Process child = bck.exec("C:\\Program Files\\MySQL\\MySQL Server 5.5\\bin/mysqldump --user=root --password=123 --opt " + banco);
                        InputStreamReader irs = new InputStreamReader(child.getInputStream());
                        BufferedReader br = new BufferedReader(irs);

                        String line;
                        while ((line = br.readLine()) != null) {
                            fw.write(line + "\n");
                        }
                        fw.close();
                        irs.close();
                        br.close();
                        JOptionPane.showMessageDialog(null, "Backup realizado com sucesso.", "Tudo OK!", 1);
                    } else {
                        bActionPerformed(evt);
                    }
                } else {
                    FileWriter fw = new FileWriter(file);
                    //Runtime bck = Runtime.getRuntime();   
                    Runtime bck = Runtime.getRuntime();
                    Process child = bck.exec("C:\\Program Files\\MySQL\\MySQL Server 5.5\\bin/mysqldump --user=root --password=123 --opt " + banco);
                    InputStreamReader irs = new InputStreamReader(child.getInputStream());
                    BufferedReader br = new BufferedReader(irs);

                    String line;
                    while ((line = br.readLine()) != null) {
                        fw.write(line + "\n");
                    }
                    fw.close();
                    irs.close();
                    br.close();
                    JOptionPane.showMessageDialog(null, "Backup realizado com sucesso.", "Tudo OK!", 1);
                }

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e, "Erro!", 2);
        }
    }//GEN-LAST:event_bActionPerformed

    private void brestaurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brestaurarActionPerformed
        String dbName = "farmacia", dbUserName = "root", dbPassword = "123", source = null;
        janela.setVisible(true);

        int result = janela.showOpenDialog(null);

        if (result == JFileChooser.OPEN_DIALOG) {

            File bkp;
            bkp = janela.getSelectedFile();
            source = bkp.getPath();

            String[] executeCmd = new String[]{"C:\\Program Files\\MySQL\\MySQL Server 5.5\\bin/mysql", "--user=" + dbUserName, "--password=" + dbPassword, dbName, "-e", " source " + source};
            Process runtimeProcess = null;

            try {
                runtimeProcess = Runtime.getRuntime().exec(executeCmd);
                int processComplete = runtimeProcess.waitFor();
                if (processComplete == 0) {
                    JOptionPane.showMessageDialog(null, "RESTAURAÇÃO REALIZADA COM SUCESSO!");

                } else {
                    JOptionPane.showMessageDialog(null, "RESTAURAÇÃO NÃO REALIZADA! PROBLEMAS NA EXECUÇÃO. CONTATE O SUPORTE!");

                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Backup.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Backup.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }//GEN-LAST:event_brestaurarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b;
    private javax.swing.JButton brestaurar;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JFileChooser janela;
    // End of variables declaration//GEN-END:variables
}
