package laboratorio;

public class Laboratorio {
    private int id_laboratorio;
    private String nome;
    
    public Laboratorio(){}

    public Laboratorio(int id_laboratorio, String nome) {
        this.id_laboratorio = id_laboratorio;
        this.nome = nome;
    }

    public int getId_laboratorio() {
        return id_laboratorio;
    }

    public void setId_laboratorio(int id_laboratorio) {
        this.id_laboratorio = id_laboratorio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
