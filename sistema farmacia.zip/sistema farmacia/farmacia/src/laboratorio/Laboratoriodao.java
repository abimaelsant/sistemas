package laboratorio;

import conexao.Conexao;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import produto.Produtodao;

public class Laboratoriodao {

    Conexao conexoes = new Conexao();
    Connection conexao;

    public Laboratoriodao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Laboratorio l) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        String sql = "INSERT INTO laboratorio(nome) VALUES(?)";
        ResultSet rs = null;
        PreparedStatement s = conexao.prepareStatement("select * from laboratorio");

        rs = s.executeQuery();

        while (rs.next()) {
            if (l.getId_laboratorio() == rs.getInt("id_laboratorio")) {
                verifica = 1;
            }
        }
        if (verifica == 0) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, l.getNome());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "LABORATÓRIO CADASTRADO COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "LABORATÓRIO JÁ CADASTRADO!");

        }
    }

    public void altera(Laboratorio l) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {

            ResultSet rs = null;
            String sql = "UPDATE laboratorio set nome=? where id_laboratorio=?";
            PreparedStatement s = conexao.prepareStatement("select * from laboratorio");

            rs = s.executeQuery();

            while (rs.next()) {
                if (l.getId_laboratorio() == rs.getInt("id_laboratorio")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setString(1, l.getNome());
                stmt.setInt(2, l.getId_laboratorio());
                stmt.executeUpdate();
                stmt.close();
                JOptionPane.showMessageDialog(null, "LABORATÓRIO EDITADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao editar" + e);
        }
    }

    public void excluir(Laboratorio l) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {
            ResultSet rs = null;
            String sql = "DELETE FROM laboratorio WHERE id_laboratorio=? ";
            PreparedStatement s = conexao.prepareStatement("select * from laboratorio");

            rs = s.executeQuery();

            while (rs.next()) {
                if (l.getId_laboratorio() == rs.getInt("id_laboratorio")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setInt(1, l.getId_laboratorio());
                stmt.execute();
                stmt.close();
                JOptionPane.showMessageDialog(null, "LABORATÓRIO DELETADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir" + e);
        }
    }

    public List<Laboratorio> listar() throws SQLException {
        List<Laboratorio> laboratorio = new ArrayList<Laboratorio>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

            rs = sql.executeQuery();

            while (rs.next()) {

                Laboratorio l = new Laboratorio();

                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                laboratorio.add(l);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (laboratorio);
    }
public List<Laboratorio> listar_nome(String nome) throws SQLException {
        List<Laboratorio> laboratorio = new ArrayList<Laboratorio>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

            rs = sql.executeQuery();
            Produtodao daop = new Produtodao();
            while (rs.next()) {

                Laboratorio l = new Laboratorio();
              if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome))){
                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                laboratorio.add(l);

            }
            }
        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (laboratorio);
    }

    public Laboratorio laboratorio(int id_l) throws SQLException {
        ResultSet rs = null;
        Laboratorio l = new Laboratorio();
        int verifica = 0;
        PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

        rs = sql.executeQuery();

        while (rs.next()) {
            if (rs.getInt("id_laboratorio") == id_l) {
                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                verifica = 1;

            }
        }
        if (verifica == 0) {
            JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
        }
        return l;
    }
    public Laboratorio laboratorio_p(String id_l) throws SQLException {
        ResultSet rs = null;
        Laboratorio l = new Laboratorio();
        int verifica = 0;
        PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

        rs = sql.executeQuery();

        while (rs.next()) {
            if (rs.getString("nome").equals(id_l)) {
                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                verifica = 1;

            }
        }
        if (verifica == 0) {
            JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
        }
        return l;
    }
    
     public Laboratorio laboratorio_nome(String id_l) throws SQLException {
        ResultSet rs = null;
        Laboratorio l = new Laboratorio();
        int verifica = 0;
        PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

        rs = sql.executeQuery();

        while (rs.next()) {
            if (rs.getString("nome").equals(id_l)) {
                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                verifica = 1;

            }
        }
        if (verifica == 0) {
            //JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
        }
        return l;
    }
    
     public int laboratorio_pesq(String id_l) throws SQLException {
        ResultSet rs = null;
        Laboratorio l = new Laboratorio();
        int verifica = 0;
        PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

        rs = sql.executeQuery();

        while (rs.next()) {
            if (rs.getString("nome").equals(id_l)) {
                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                verifica = 1;

            }
        }
        if (verifica == 0) {
            JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
        }
        return verifica;
    }
     
     public int listar_nome_ver(String nome) throws SQLException {
       
        ResultSet rs = null;
        int veri = 0;
        try {

            PreparedStatement sql = conexao.prepareStatement("select * from laboratorio");

            rs = sql.executeQuery();
            Produtodao daop = new Produtodao();
            while (rs.next()) {

                Laboratorio l = new Laboratorio();
              if(daop.removerAcentos(rs.getString("nome")).equals(daop.removerAcentos(nome))){
                l.setId_laboratorio(rs.getInt("id_laboratorio"));
                l.setNome(rs.getString("nome"));
                veri = 1;

            }
            }
            if(veri == 0){
                JOptionPane.showMessageDialog(null, "LABORATÓRIO NÃO CADASTRADO!");
            }
        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (veri);
    }

}
