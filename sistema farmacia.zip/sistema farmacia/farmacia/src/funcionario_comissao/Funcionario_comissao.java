package funcionario_comissao;

public class Funcionario_comissao {
    
    private int id_funcionario_comissao;
    private int id_funcionario;
    private float valor_comissao;
    private int mes;
    private int ano;

    public int getId_funcionario_comissao() {
        return id_funcionario_comissao;
    }

    public void setId_funcionario_comissao(int id_funcionario_comissao) {
        this.id_funcionario_comissao = id_funcionario_comissao;
    }

    public int getId_funcionario() {
        return id_funcionario;
    }

    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    public float getValor_comissao() {
        return valor_comissao;
    }

    public void setValor_comissao(float valor_comissao) {
        this.valor_comissao = valor_comissao;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
    
    
    
}
