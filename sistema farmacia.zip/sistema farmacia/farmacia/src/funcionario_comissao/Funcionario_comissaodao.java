package funcionario_comissao;

import conexao.Conexao;
import funcionario.Funcionario;
import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Funcionario_comissaodao {
    
     Conexao conexoes = new Conexao();
    Connection conexao;

    public Funcionario_comissaodao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(Funcionario_comissao f) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        String sql = "INSERT INTO funcionario_comissao(id_funcionario, valor_comissao, mes, ano) VALUES(?,?,?,?)";
         
        PreparedStatement stmt = conexao.prepareStatement(sql);

        stmt.setInt(1, f.getId_funcionario());
        stmt.setFloat(2, f.getValor_comissao());
        stmt.setInt(3, f.getMes());
        stmt.setInt(4, f.getAno());
        stmt.execute();
        stmt.close();
                
    }

    public void excluir(Funcionario_comissao f) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        try {
            ResultSet rs = null;
            String sql = "DELETE FROM funcionario_comissao WHERE id_funcionario_comissao=? ";
            PreparedStatement s = conexao.prepareStatement("select * from funcionario_comissao");

            rs = s.executeQuery();

            while (rs.next()) {
                if (f.getId_funcionario_comissao() == rs.getInt("id_funcionario_comissao")) {
                    verifica = 1;
                }
            }
            if (verifica == 1) {

                PreparedStatement stmt = conexao.prepareStatement(sql);

                stmt.setInt(1, f.getId_funcionario_comissao());
                stmt.execute();
                stmt.close();
                JOptionPane.showMessageDialog(null, "DELETADO COM SUCESSO!");
            } else {
                JOptionPane.showMessageDialog(null, " NÃO CADASTRADO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir" + e);
        }
    }

    public List<Funcionario_comissao> listar() throws SQLException {
        List<Funcionario_comissao> funcionario = new ArrayList<Funcionario_comissao>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from funcionario_comissao");

            rs = sql.executeQuery();

            while (rs.next()) {

                Funcionario_comissao f = new Funcionario_comissao();

                f.setId_funcionario_comissao(rs.getInt("id_funcionario_comissao"));
                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setValor_comissao(rs.getFloat("valor_comissao"));
                f.setMes(rs.getInt("mes"));
                f.setAno(rs.getInt("ano"));
                funcionario.add(f);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (funcionario);
    }
    public List<Funcionario_comissao> listar_f(int id_f, String p) throws SQLException {
        List<Funcionario_comissao> funcionario = new ArrayList<Funcionario_comissao>();
        int verifica = 0;
        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from funcionario_comissao");

            rs = sql.executeQuery();

            while (rs.next()) {

                Funcionario_comissao f = new Funcionario_comissao();
               if(rs.getInt("id_funcionario") == id_f && String.valueOf(rs.getInt("mes")+"/"+rs.getInt("ano")).equals(p)){
                f.setId_funcionario_comissao(rs.getInt("id_funcionario_comissao"));
                f.setId_funcionario(rs.getInt("id_funcionario"));
                f.setValor_comissao(rs.getFloat("valor_comissao"));
                f.setMes(rs.getInt("mes"));
                f.setAno(rs.getInt("ano"));
                funcionario.add(f);
                verifica = 1;
               }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "NENHUM RESULTADO FOI ENCONTRADO!");
            }

        } catch (SQLException e) {

            e.printStackTrace();

        }
        return (funcionario);
    }
    
}
