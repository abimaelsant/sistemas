package cadastrousuario;

import java.io.IOException;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CadastroUsuariodao {
     Conexao conexoes = new Conexao();
    Connection conexao;

    public CadastroUsuariodao() throws SQLException {
        this.conexao = conexoes.conexao();
    }

    public void cadastro(CadastroUsuario c) throws SQLException, UnknownHostException, IOException {
        
            String sql = "INSERT INTO cadastro_usuario(usuario, senha, id_cargo) VALUES(?,?,?)";
            PreparedStatement s = conexao.prepareStatement("select * from cadastro_usuario");
            ResultSet rs = null;
            int verifica = 0;
            rs = s.executeQuery();

           while (rs.next()) {
             if (c.getUsuario().equals(rs.getString("usuario"))) {
                verifica = 1;
            }
            if (c.getSenha().equals(rs.getString("senha"))) {
                verifica = 1;
            }

        }
        if (verifica == 0) {
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getUsuario());
            stmt.setString(2, c.getSenha());
            stmt.setInt(3, c.getId_cargo());
            
            stmt.execute();
            stmt.close();
        
            JOptionPane.showMessageDialog(null, "USUÁRIO CADASTRADO COM SUCESSO!");
        }else{
        
            JOptionPane.showMessageDialog(null, "USUÁRIO JÁ CADASTRADO!");
        }
    }

    public void altera(CadastroUsuario c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;

        ResultSet rs = null;
        String sql = "UPDATE cadastro_usuario set usuario=?, senha=?, id_cargo=? where id_usuario=?";
        PreparedStatement s = conexao.prepareStatement("select * from cadastro_usuario");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_usuario() == rs.getInt("id_usuario")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, c.getUsuario());
            stmt.setString(2, c.getSenha());
            stmt.setInt(3, c.getId_cargo());
            stmt.setInt(4, c.getId_usuario());
            stmt.executeUpdate();
            stmt.close();
            JOptionPane.showMessageDialog(null, "EDITADO COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADO!");
        }

    }

    public void excluir(CadastroUsuario c) throws SQLException, UnknownHostException, IOException {
        int verifica = 0;
        ResultSet rs = null;
        String sql = "DELETE FROM cadastro_usuario WHERE id_usuario=? ";
        PreparedStatement s = conexao.prepareStatement("select * from cadastro_usuario");

        rs = s.executeQuery();

        while (rs.next()) {
            if (c.getId_usuario() == rs.getInt("id_usuario")) {
                verifica = 1;
            }
        }
        if (verifica == 1) {

            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setInt(1, c.getId_usuario());
            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "USUÁRIO DELETADO COM SUCESSO!");
        } else {
            JOptionPane.showMessageDialog(null, "NÃO CADASTRADO!");
        }

    }

    public List<CadastroUsuario> listar() throws SQLException {
        List<CadastroUsuario> cadastro = new ArrayList<>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from cadastro_usuario");

            rs = sql.executeQuery();

            while (rs.next()) {

                CadastroUsuario c = new CadastroUsuario();
                c.setId_usuario(rs.getInt("id_usuario"));
                c.setUsuario(rs.getString("usuario"));
                c.setSenha(rs.getString("senha"));
                c.setId_cargo(rs.getInt("id_cargo"));
                cadastro.add(c);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (cadastro);
    }
    
     public CadastroUsuario pesq(int id) throws SQLException {
        
        CadastroUsuario c = new CadastroUsuario();
        int verifica = 0;
        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from cadastro_usuario");

            rs = sql.executeQuery();

            while (rs.next()) {
                if(rs.getInt("id_usuario") == id){
                c.setId_usuario(rs.getInt("id_usuario"));
                c.setUsuario(rs.getString("usuario"));
                c.setSenha(rs.getString("senha"));
                c.setId_cargo(rs.getInt("id_cargo"));
                verifica = 1;
                }

            }
           if(verifica == 0){
               JOptionPane.showMessageDialog(null, "USUÁRIO NÃO CADASTRADO!");
           }
        } catch (SQLException e) {

            e.printStackTrace();

        }

        return c;
    }
    
    
    
    public List<Cargo> listar_cargo() throws SQLException {
        List<Cargo> cadastro = new ArrayList<>();

        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from cargo");

            rs = sql.executeQuery();

            while (rs.next()) {

                Cargo c = new Cargo();
                c.setId_cargo(rs.getInt("id_cargo"));
                c.setNome(rs.getString("nome"));
                cadastro.add(c);

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return (cadastro);
    }
    
    public Cargo cargo(int id_cargo) throws SQLException {
        //List<Cargo> cadastro = new ArrayList<>();
        
        Cargo c = new Cargo();
        ResultSet rs = null;

        try {

            PreparedStatement sql = conexao.prepareStatement("select * from cargo");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getInt("id_cargo") == id_cargo){
                c.setId_cargo(rs.getInt("id_cargo"));
                c.setNome(rs.getString("nome"));
              }

            }

        } catch (SQLException e) {

            e.printStackTrace();

        }

        return c;
    }
    
    
     public int cargo_pesq(int id_cargo) throws SQLException {
        
        ResultSet rs = null;
        int verifica = 0;
        try {

            PreparedStatement sql = conexao.prepareStatement("select * from cargo");

            rs = sql.executeQuery();

            while (rs.next()) {
              if(rs.getInt("id_cargo") == id_cargo){
                Cargo c = new Cargo();
                c.setId_cargo(rs.getInt("id_cargo"));
                c.setNome(rs.getString("nome"));
                verifica = 1;
              }
            }
            if(verifica == 0){
                JOptionPane.showMessageDialog(null, "CARGO NÃO CADASTRADO!");
            }
        } catch (SQLException e) {

            e.printStackTrace();

        }

        return verifica;
    }

}
