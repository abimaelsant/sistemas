/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cadastrousuario;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Abimael
 */
public class CadastroUsuarioSI extends javax.swing.JFrame {

    /**
     * Creates new form CadastroUsuarioSI
     */
    public CadastroUsuarioSI() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        usuario = new javax.swing.JTextField();
        senha = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabela_cargo = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        id_usu = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        jButton6 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        id_editar = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        id_cargo = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("CADASTRO DE USUÁRIOS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Usuário:    ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Senha:  ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, -1, -1));
        getContentPane().add(usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 240, 30));
        getContentPane().add(senha, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 240, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 51, 153));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/confirma.png"))); // NOI18N
        jButton1.setText("Cadastrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, -1, 50));

        tabela_cargo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id do Cargo", "Nome"
            }
        ));
        jScrollPane2.setViewportView(tabela_cargo);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, 410, 230));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 51, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 1.png"))); // NOI18N
        jButton2.setText("Editar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, -1, 50));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 51, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/listar 2.png"))); // NOI18N
        jButton3.setText("Listar Cargos");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 7, 220, 70));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 51, 153));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/listar 2.png"))); // NOI18N
        jButton4.setText("Listar Usuários ");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Id do Usuário:  ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 350, -1, -1));
        getContentPane().add(id_usu, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 340, 100, 40));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 51, 153));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/delete 1.png"))); // NOI18N
        jButton5.setText("Excluir");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 340, 150, -1));

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id do Usuário", "Usuário", "Senha", "Cargo"
            }
        ));
        jScrollPane3.setViewportView(tabela);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, 850, 290));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 51, 153));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit 2.png"))); // NOI18N
        jButton6.setText("Pesquisar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 341, -1, 40));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Id_cargo:  ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        jLabel6.setText("Id:  ");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, -1, -1));

        id_editar.setEnabled(false);
        getContentPane().add(id_editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, 50, -1));

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 51, 153));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icones 2/edit_clear2.png"))); // NOI18N
        jButton7.setText("Limpar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 11, -1, 60));

        id_cargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "selecione", "GERENTE", "FUNCIONÁRIO-VENDEDOR", " " }));
        id_cargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_cargoActionPerformed(evt);
            }
        });
        getContentPane().add(id_cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 200, 240, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 410, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            CadastroUsuariodao dao = new CadastroUsuariodao();
            CadastroUsuario c = new CadastroUsuario();
            Cargo cargo = new Cargo();
            int id_c = 0;
            if(!id_cargo.getSelectedItem().toString().isEmpty()){
                if(id_cargo.getSelectedItem().toString().equals("GERENTE")){
                    id_c = 1;
                }
                if(id_cargo.getSelectedItem().toString().equals("FUNCIONÁRIO-VENDEDOR")){
                    id_c = 2;
                }
            }
            int verifica = dao.cargo_pesq(id_c);
            if(verifica == 1){
            c.setUsuario(usuario.getText());
            c.setSenha(senha.getText());
            c.setId_cargo(id_c);
            dao.cadastro(c);
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            CadastroUsuariodao dao = new CadastroUsuariodao();
            CadastroUsuario c = new CadastroUsuario();
            Cargo cargo = new Cargo();
            List<Cargo> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela_cargo.getModel();
            ((DefaultTableModel) tabela_cargo.getModel()).setNumRows(0);
            tabela_cargo.updateUI();
            lista = dao.listar_cargo();
            for (int i = 0; i < lista.size(); i++) {
                table.addRow(new Object[]{lista.get(i).getId_cargo(), lista.get(i).getNome()});
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        }
           
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        try {
            CadastroUsuariodao dao = new CadastroUsuariodao();
            CadastroUsuario cadastro = new CadastroUsuario();
            int id_u = 0;
            String cargo = null;
            if(!id_usu.getText().isEmpty()){
                id_u = Integer.parseInt(id_usu.getText());
            }
            cadastro = dao.pesq(id_u);
            usuario.setText(cadastro.getUsuario());
            senha.setText(cadastro.getSenha());
            if(cadastro.getId_cargo() == 1){
                cargo = "GERENTE";
            }
            if(cadastro.getId_cargo() == 2){
                cargo = "FUNCIONÁRIO-VENDEDOR";
            }
            id_cargo.setToolTipText(cargo);
            id_editar.setText(String.valueOf(cadastro.getId_usuario()));
            id_usu.setText("");
        } catch (SQLException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            CadastroUsuariodao dao = new CadastroUsuariodao();
            CadastroUsuario c = new CadastroUsuario();
            Cargo cargo = new Cargo();
            int id_c = 0, id_e = 0;
           if(!id_cargo.getSelectedItem().toString().isEmpty()){
                if(id_cargo.getSelectedItem().toString().equals("GERENTE")){
                    id_c = 1;
                }
                if(id_cargo.getSelectedItem().toString().equals("FUNCIONÁRIO-VENDEDOR")){
                    id_c = 2;
                }
            }
            if(!id_editar.getText().isEmpty()){
                id_e = Integer.parseInt(id_editar.getText());
            }
            int verifica = dao.cargo_pesq(id_c);
            if(verifica == 1 && id_e > 0){
            c.setId_usuario(id_e);
            c.setUsuario(usuario.getText());
            c.setSenha(senha.getText());
            c.setId_cargo(id_c);
            dao.altera(c);
            //Cargo cargo = new Cargo();
            List<CadastroUsuario> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            lista = dao.listar();
            for (int i = 0; i < lista.size(); i++) {
                cargo = dao.cargo(lista.get(i).getId_cargo());
                table.addRow(new Object[]{lista.get(i).getId_usuario(), lista.get(i).getUsuario(), lista.get(i).getSenha(), cargo.getNome()});
            }
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        try {
            CadastroUsuariodao dao = new CadastroUsuariodao();
            CadastroUsuario c = new CadastroUsuario();
            int id_u = 0;
            if(!id_usu.getText().isEmpty()){
                id_u = Integer.parseInt(id_usu.getText());
            }
            c.setId_usuario(id_u);
            dao.excluir(c);
            Cargo cargo = new Cargo();
            List<CadastroUsuario> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            lista = dao.listar();
            for (int i = 0; i < lista.size(); i++) {
                cargo = dao.cargo(lista.get(i).getId_cargo());
                table.addRow(new Object[]{lista.get(i).getId_usuario(), lista.get(i).getUsuario(), lista.get(i).getSenha(), cargo.getNome()});
            }
        } catch (SQLException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
            CadastroUsuariodao dao = new CadastroUsuariodao();
            CadastroUsuario c = new CadastroUsuario();
            Cargo cargo = new Cargo();
            List<CadastroUsuario> lista = new ArrayList<>();
            DefaultTableModel table = new DefaultTableModel();
            table = (DefaultTableModel) tabela.getModel();
            ((DefaultTableModel) tabela.getModel()).setNumRows(0);
            tabela.updateUI();
            lista = dao.listar();
            for (int i = 0; i < lista.size(); i++) {
                cargo = dao.cargo(lista.get(i).getId_cargo());
                table.addRow(new Object[]{lista.get(i).getId_usuario(), lista.get(i).getUsuario(), lista.get(i).getSenha(), cargo.getNome()});
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(CadastroUsuarioSI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        id_editar.setText("");
        usuario.setText("");
        senha.setText("");
        //id_cargo.setText("");
        id_usu.setText("");
        ((DefaultTableModel) tabela.getModel()).setNumRows(0);
        tabela.updateUI();
        ((DefaultTableModel) tabela_cargo.getModel()).setNumRows(0);
         tabela_cargo.updateUI();
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void id_cargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_cargoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_cargoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuarioSI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuarioSI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuarioSI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CadastroUsuarioSI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroUsuarioSI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> id_cargo;
    private javax.swing.JTextField id_editar;
    private javax.swing.JTextField id_usu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField senha;
    private javax.swing.JTable tabela;
    private javax.swing.JTable tabela_cargo;
    private javax.swing.JTextField usuario;
    // End of variables declaration//GEN-END:variables
}
