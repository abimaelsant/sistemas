create database farmacia;
use farmacia;

create table caixas(
   id_caixas int(11),
   descricao varchar(400),
   primary key(id_caixas)
);

create table caixa(
 id_caixa int(11) auto_increment,
 numCaixa int,
 vendaAvista float,
 vendaAprazo float,
 vendaConvenio float,
 vendaCartaoC float,
 vendaCartaoD float,
 totalDiario float,
 totalAcumulado float,
 data_abertura varchar(100),
 data_fechamento varchar(100),
 flag varchar(100),
 primary key(id_caixa)
);
create table abrir_caixa(
  id_abrir_caixa int(20) auto_increment,
  numCaixa int(11),
  valor_abertura float,
  data_abertura varchar(20),
  primary key(id_abrir_caixa)
);

create table empresa(
 id_empresa int(11),
 nome varchar(400),
 endereco varchar(400),
 bairro varchar(400),
 cep varchar(20),
 cidade varchar(400),
 estado varchar(400),
 telefone varchar(20),
 cnpj varchar(50) unique,
 inscricao_estadual varchar(100),
 email varchar(100),
 observacao varchar(300),
 primary key(cnpj)
);

create table cliente(
  nome varchar(400),
  endereco varchar(400),
  bairro varchar(400),
  cep varchar(50),
  cidade varchar(400),
  estado varchar(400),
  telefone varchar(20),
  grupo varchar(400),
  id_empresa int(11),
  ativo_inativo boolean,
  cpf varchar(20) unique,
  identidade varchar(20),
  data_nascimento varchar(20),
  valorMax float,
  primary key(cpf)
);

create table fornecedor(
  id_fornecedor int(11) auto_increment,
  nome varchar(400),
  endereco varchar(400),
  bairro varchar(400),
  cep varchar(20),
  cidade varchar(400),
  estado varchar(400),
  telefone varchar(20),
  cnpj varchar(50),
  representante varchar(400),
  telefone_representante varchar(400),
  primary key(id_fornecedor)
);

create table funcionario(
  id_funcionario int(11) auto_increment,
  nome varchar(400),
  endereco varchar(400),
  bairro varchar(400),
  cep varchar(20),
  cidade varchar(400),
  estado varchar(400),
  telefone varchar(20),
  funcao varchar(400),
  salario float,
  comissão float,
  primary key (id_funcionario)
);

create table laboratorio(
 id_laboratorio int(11) auto_increment,
 nome varchar(400),
 primary key(id_laboratorio)
);

create table forma_pagamento(
 id_forma_pagamento int(11) unique,
 nome varchar(400),
 primary key(id_forma_pagamento)
);

create table produto(
  id_produto int(11) auto_increment,
  codigo_produto varchar(20) unique,
  nome varchar(400),
  numero_lote varchar(400),
  laboratorio varchar(200),
  desconto float,
  permitirdesconto boolean,
  fatorcompra int,
  valor_custo float,
  valor_margem float,
  valor_venda float,
  quantidade_estoque int,
  estoque_minimo int,
  ativo_inativo boolean,
  comissao float,
  aliquota float, 
  pis_cofins float,
  ncm float,
  icms float, 
  fornecedor varchar(300),
  data_vencimento varchar(20),
  primary key (id_produto)
);

create table venda(
 id_venda int(11) auto_increment,
 tipo_venda varchar(400),
 cpf_cliente varchar(400),
 id_forma_pagamento int(11),
 id_produto varchar(50),
 nome_prod varchar(200),
 quantidade int,
 data_venda varchar(20),
 acrescimo float,
 desconto float,
 valor_venda float,
 id_funcionario int(11),
 numCaixa int,
 numeroEfc int,
 numeroCf int,
 primary key (id_venda)
);

create table nota(
 id_nota int(11) auto_increment,
 id_venda int(11),
 id_produto int(11),
 nome_produto varchar(400),
 quantidade int,
 valor_unitario float,
 valor_total float,
 desconto float,
 primary key (id_nota)
);

create table contas_pagar(
   id_contas_pagar int(11) auto_increment,
   data_compra varchar(20),
   id_fornecedor varchar(300),
   data_vcto varchar(20),
   valor_divida float,
   id_nota int(11),
   numero_prestacao int,
   id_forma_pagamento int(11),
   primary key (id_contas_pagar)
);

create table contas_receber(
  id_conta_receber int(11) auto_increment,
  data_venda varchar(20),
  tipo varchar(400),
  cpf_cliente varchar(20),
  valor_receber float,
  valor_recebido float,
  desconto float,
  acrescimo float,
  data_vcto varchar(20),
  saldo float,
  id_venda int(11),
  id_empresa int(11),
  numero_prestacao int,
  id_forma_pagamento int(11),
  primary key (id_conta_receber)
);


create table entrada(
 id_entrada int(11) auto_increment,
 id_notafiscal int(11),
 data_entrada varchar(20),
 id_fornecedor int(11),
 id_produto int(11),
 valor_notafiscal float,
 icms float,
 data_faturamento varchar(20),
 primary key (id_entrada)
);

create table venda_caixa(
   id_venda_caixa int(11) auto_increment,
   data_venda varchar(20), 
   numCaixa int,
   cpf_cliente varchar(50),
   id_forma_pagamento int(11),
   valor_venda float,
   valor_pago float,
   primary key (id_venda_caixa)
);

create table funcionario_comissao(
  id_funcionario_comissao int(11) auto_increment,
  id_funcionario int(11),
  valor_comissao float,
  mes int,
  ano int,
  primary key(id_funcionario_comissao)
);

create table cadastro_usuario(
   id_usuario int(11) auto_increment,
   usuario varchar(10),
   senha varchar(10),
   id_cargo int(11),
   primary key(id_usuario)
);

create table cargo(
   id_cargo int(11),
   nome varchar(50),
   primary key(id_cargo)
);

create table caixa_aberto_fechado(
   id_caixa_aberto_fechado int(11),
   status1 int(10),
   primary key(id_caixa_aberto_fechado)
);

/*
****************************************************************************************************
*/
insert into forma_pagamento(id_forma_pagamento, nome) values ("1", "Venda à Vista!");
insert into forma_pagamento(id_forma_pagamento, nome) values ("2", "Venda à Prazo!");
insert into forma_pagamento(id_forma_pagamento, nome) values ("3", "Venda por Convênio!");
insert into forma_pagamento(id_forma_pagamento, nome) values ("4", "Venda no Cartão de Crédito!");
insert into forma_pagamento(id_forma_pagamento, nome) values ("5", "Venda no Cartão de Débito!");
/*
****************************************************************************************************
*/

/*
****************************************************************************************************
*/

insert into cargo(id_cargo, nome) values ("1", "GERENTE");
insert into cargo(id_cargo, nome) values ("2", "FUNCIONÁRIO-VENDEDOR");


/*
****************************************************************************************************
*/

/*
******************************************************************************************************
*/
insert into caixas(id_caixas, descricao) values ("1", "Caixa 1");
insert caixa_aberto_fechado(id_caixa_aberto_fechado, status1) values ("1", 0);

/*
******************************************************************************************************
*/
