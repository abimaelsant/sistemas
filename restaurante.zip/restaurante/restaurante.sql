create database restaurante;

use restaurante;

create table login (
	id int(11) auto_increment,
    nome varchar(255) not null,
    senha varchar(255) unique not null,
    perfilUsuario varchar(255) not null,
    primary key(id)
);

create table produto (
	id int(11) auto_increment,
    nome varchar(255) not null,
    tipoMarca varchar(255) not null,
    quantidade int not null,
    precoUnitarioVenda float not null,
    precoCusto float not null,
    primary key(id)
);

create table mesa (
	id int(11) auto_increment,
    numero int(11) unique not null,
    descricao varchar(400),
    primary key(id)
);

create table funcionario (
	id int(11) auto_increment,
    nome varchar(255) not null,
    primary key(id)
);

create table pedido (
	id int(11) auto_increment,
    numeroMesa int,
    garcom_id int,
    valorParcial float,
    valorTotal float,
    data_pedido timestamp default current_timestamp(),
    ativo boolean default true,
    primary key(id)
);

create table pedido_produto (
	id int(11) auto_increment,
    pedido_id int,
    produto_id int,
    quantidade int,
    ativo boolean default true,
    primary key(id)
);

select *from pedido;
select *from pedido_produto;
select *from produto;


insert into login(nome, senha, perfilUsuario) values ('Admin', '1000:822464059301646fc5bff27c5a32f270eb25da6dc75c033f:29144ac73e7f4d7d8933f918ab5bda03525284aa07048d4f', 'Admin');
insert into login(nome, senha, perfilUsuario) values ('Venda', '1000:d7462f9d703913f4595aa38f7eeb7e4faa72f7e9f446e63e:7a79282126fb4f361f637edf039de154fd1dbc67091ddf48', 'Venda');