package conexaoDao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexaoBD implements Conexao{
    
    @Override
    public Connection conectaBD(Connection driver){
            Connection conexao = driver;
            return conexao;
    }
    
    @Override
    public void fechaConexaoBD(Connection conexao){
        try {
            conexao.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
