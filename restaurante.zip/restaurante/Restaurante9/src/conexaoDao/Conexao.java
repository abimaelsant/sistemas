package conexaoDao;

import java.sql.Connection;

public interface Conexao {
    Connection conectaBD(Connection driver);
    void fechaConexaoBD(Connection conexao);
}
