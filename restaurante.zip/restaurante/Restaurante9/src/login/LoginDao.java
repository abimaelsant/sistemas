package login;

import conexaoDao.Conexao;
import conexaoDao.ConexaoBD;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class LoginDao {
    Conexao conecta;
    Connection driver, conexao;
    
    public LoginDao() throws SQLException{
        this.conecta = new ConexaoBD();
        driver =  DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurante", "root", "123");
        this.conexao = this.conecta.conectaBD(driver);
    }
    
    public String login(String senha) throws NoSuchAlgorithmException, InvalidKeySpecException{
        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from login");
      
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Login login = new Login();
                if(PasswordHash.validatePassword(senha, rs.getString("senha"))){
                    return (rs.getString("perfilUsuario"));
                }
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return "";
    }
}
