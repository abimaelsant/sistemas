package mesa;

import java.util.Collection;

public interface MesaDaoInterface {
    void cadastrar(Mesa mesa);
    void editar(Mesa mesa);
    void deletar(int id);
    Collection<?> mesas();
    Collection<Mesa> mesaNumero(int num);
}
