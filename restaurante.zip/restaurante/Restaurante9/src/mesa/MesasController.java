package mesa;

import conexaoDao.Conexao;
import conexaoDao.ConexaoBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;

public class MesasController implements MesaDaoInterface{
    MesaDaoInterface mesaDao;
    Conexao conexao;
    Connection driver;
    
    public MesasController() throws SQLException{
        this.conexao = new ConexaoBD();
        driver =  DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurante", "root", "123");
        this.mesaDao = new MesaDao(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void cadastrar(Mesa mesa){
        this.mesaDao.cadastrar(mesa);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void editar(Mesa mesa){
        this.mesaDao.editar(mesa);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void deletar(int id){
        this.mesaDao.deletar(id);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public Collection<Mesa> mesas(){
        return (Collection<Mesa>) this.mesaDao.mesas();
    }
    public Collection<Mesa> mesaNumero(int num){
        return this.mesaDao.mesaNumero(num);
    }
}
