package mesa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.JOptionPane;

public class MesaDao implements MesaDaoInterface{
    private final Connection conexao;
    
    public MesaDao(Connection conexao){
        this.conexao = conexao;
    }
    
    @Override
    public void cadastrar(Mesa mesa) {
        String sql = "INSERT INTO mesa(numero) VALUES(?)";

        try{
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, mesa.getNumero());
                stmt.execute();
                JOptionPane.showMessageDialog(null, "CADASTRO REALIZADO COM SUCESSO");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void editar(Mesa mesa) {
        String sql = "UPDATE mesa set numero=? where id=?";

        try {

            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, mesa.getNumero());
                stmt.setInt(2, mesa.getId());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "EDITADO COM SUCESSO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void deletar(int id) {

        String sql = "DELETE FROM mesa WHERE id=?";

        try {
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, id);
                stmt.execute();
                JOptionPane.showMessageDialog(null, "DELETADO COM SUCESSO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }

    @Override
    public Collection<Mesa> mesas() {

        List<Mesa> mesas = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select * from mesa");
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Mesa mesa = new Mesa();
                mesa.setId(rs.getInt("id"));
                mesa.setNumero(rs.getInt("numero"));
                mesas.add(mesa);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return (mesas);
    }
    
    @Override
    public Collection<Mesa> mesaNumero(int num) {

        List<Mesa> mesas = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select * from mesa where numero=?");
            sql.setInt(1, num);
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Mesa mesa = new Mesa();
                mesa.setId(rs.getInt("id"));
                mesa.setNumero(rs.getInt("numero"));
                mesas.add(mesa);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return (mesas);
    }
}
