package produto;

import conexaoDao.Conexao;
import conexaoDao.ConexaoBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;

public class ProdutosController implements ProdutoDaoInterface{
    ProdutoDaoInterface produtoDao;
    Conexao conexao;
    Connection driver;
    
    public ProdutosController() throws SQLException{
        this.conexao = new ConexaoBD();
        driver =  DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurante", "root", "123");
        this.produtoDao = new ProdutoDao(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void cadastrar(Produto produto){
        this.produtoDao.cadastrar(produto);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void editar(Produto produto){
        this.produtoDao.editar(produto);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void deletar(int id){
        this.produtoDao.deletar(id);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public Collection<Produto> produtos(){
        return (Collection<Produto>) this.produtoDao.produtos();
    }
    
    @Override
    public Collection<Produto> busca(String nome){
        return (Collection<Produto>) this.produtoDao.busca(nome);
    }
    
    @Override
    public Produto produto(int id){
        return this.produtoDao.produto(id);
    }
    
    @Override
    public void editarQuantidade(Produto produto) {
        this.produtoDao.editarQuantidade(produto);
        //this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
}
