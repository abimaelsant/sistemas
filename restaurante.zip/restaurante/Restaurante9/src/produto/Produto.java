package produto;

public class Produto {
    private int id;
    private String nome;
    private String tipoMarca;
    private int quantidade;
    private float precoUnitarioVenda;
    private float precoCusto;
    
    public Produto(){}
    
    public Produto(int id, String nome, String tipoMarca, int quantidade, float precoCusto, float precoUnitarioVenda){
        this.id = id;
        this.nome = nome;
        this.tipoMarca = tipoMarca;
        this.quantidade = quantidade;
        this.precoUnitarioVenda = precoUnitarioVenda;
        this.precoCusto = precoCusto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipoMarca() {
        return tipoMarca;
    }

    public void setTipoMarca(String tipoMarca) {
        this.tipoMarca = tipoMarca;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPrecoUnitarioVenda() {
        return precoUnitarioVenda;
    }

    public void setPrecoUnitarioVenda(float precoUnitarioVenda) {
        this.precoUnitarioVenda = precoUnitarioVenda;
    }

    public float getPrecoCusto() {
        return precoCusto;
    }

    public void setPrecoCusto(float precoCusto) {
        this.precoCusto = precoCusto;
    }
}