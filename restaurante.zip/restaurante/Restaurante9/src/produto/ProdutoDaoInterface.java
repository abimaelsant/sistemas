package produto;

import java.util.Collection;

public interface ProdutoDaoInterface {
    void cadastrar(Produto produto);
    void editar(Produto produto);
    public void editarQuantidade(Produto produto);
    void deletar(int id);
    Collection<?> produtos();
    Collection<?> busca(String nome);
    Produto produto(int id);
}
