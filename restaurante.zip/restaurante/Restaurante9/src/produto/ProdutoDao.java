package produto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.JOptionPane;

public class ProdutoDao implements ProdutoDaoInterface{
    private final Connection conexao;
    
    public ProdutoDao(Connection conexao){
        this.conexao = conexao;
    }
    
    @Override
    public void cadastrar(Produto produto) {
        String sql = "INSERT INTO produto(nome, tipoMarca, quantidade, precoUnitarioVenda, precoCusto) VALUES(?,?,?,?,?)";

        try{
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setString(1, produto.getNome());
                stmt.setString(2, produto.getTipoMarca());
                stmt.setInt(3, produto.getQuantidade());
                stmt.setFloat(4, produto.getPrecoUnitarioVenda());
                stmt.setFloat(5, produto.getPrecoCusto());
                stmt.execute();
                JOptionPane.showMessageDialog(null, "CADASTRO REALIZADO COM SUCESSO");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void editar(Produto produto) {
        String sql = "UPDATE produto set nome=?, tipoMarca=?, quantidade=?, precoUnitarioVenda=?, precoCusto=? where id=?";

        try {

            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setString(1, produto.getNome());
                stmt.setString(2, produto.getTipoMarca());
                stmt.setInt(3, produto.getQuantidade());
                stmt.setFloat(4, produto.getPrecoUnitarioVenda());
                stmt.setFloat(5, produto.getPrecoCusto());
                stmt.setInt(6, produto.getId());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "EDITADO COM SUCESSO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void editarQuantidade(Produto produto) {
        String sql = "UPDATE produto set quantidade=? where id=?";

        try {

            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, produto.getQuantidade());
                stmt.setInt(2, produto.getId());
                stmt.executeUpdate();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void deletar(int id) {

        String sql = "DELETE FROM produto WHERE id=?";

        try {
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, id);
                stmt.execute();
                JOptionPane.showMessageDialog(null, "DELETADO COM SUCESSO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }

    @Override
    public Collection<Produto> produtos() {

        List<Produto> produtos = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select * from produto");
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setTipoMarca(rs.getString("tipoMarca"));
                produto.setQuantidade(rs.getInt("quantidade"));
                produto.setPrecoUnitarioVenda(rs.getFloat("precoUnitarioVenda"));
                produto.setPrecoCusto(rs.getFloat("precoCusto"));
                produtos.add(produto);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return (produtos);
    }
    
    @Override
    public Collection<Produto> busca(String nome){
        List<Produto> produtos = new ArrayList<>();
        try {
            PreparedStatement smt = this.conexao.prepareStatement("SELECT * FROM produto WHERE nome LIKE ?");
            
            smt.setString(1, "%" + nome + "%");
            
            ResultSet rs = smt.executeQuery();

            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setTipoMarca(rs.getString("tipoMarca"));
                produto.setQuantidade(rs.getInt("quantidade"));
                produto.setPrecoUnitarioVenda(rs.getFloat("precoUnitarioVenda"));
                produto.setPrecoCusto(rs.getFloat("precoCusto"));
                produtos.add(produto);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return (produtos);
    }
    
    @Override
    public Produto produto(int id){
        Produto produto = new Produto();
        try {
            PreparedStatement smt = this.conexao.prepareStatement("SELECT * FROM produto WHERE id=?");
            
            smt.setInt(1, id);
            
            ResultSet rs = smt.executeQuery();

            while (rs.next()) {
                
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setTipoMarca(rs.getString("tipoMarca"));
                produto.setQuantidade(rs.getInt("quantidade"));
                produto.setPrecoUnitarioVenda(rs.getFloat("precoUnitarioVenda"));
                produto.setPrecoCusto(rs.getFloat("precoCusto"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return (produto);
    }
}
