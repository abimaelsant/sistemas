package relatorios;

import java.awt.Font;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pedido.Pedido;
import pedido.PedidoDaoInterface;
import pedido.PedidosController;
import produto.Produto;
import produto.ProdutoDaoInterface;
import produto.ProdutosController;

public class Vendas extends javax.swing.JFrame {

    public Vendas() {
        initComponents();
        dados.setRowHeight(30);
        setLocationRelativeTo( null );
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        data.requestFocus();
        dados.setDefaultEditor(Object.class, null); 
        valorTotal.setFont(new Font("Arial", Font.BOLD, 30));
        valorTotal.setEnabled(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        data = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dados = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        valorTotal = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setText("RELATÓRIOS VENDA");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));

        try {
            data.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataActionPerformed(evt);
            }
        });
        getContentPane().add(data, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 170, 40));

        jLabel2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jLabel2.setText("Data:      ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        jButton1.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/business_salesreport_salesreport_negocio_2353.png"))); // NOI18N
        jButton1.setText("BUSCAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, 180, 60));

        dados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Produto", "Marca/Tipo", "Quantidade", "Valor"
            }
        ));
        jScrollPane1.setViewportView(dados);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 800, 300));

        jButton2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton2.setText("CANCELAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, 330, -1));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 530, -1, 20));
        getContentPane().add(valorTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 460, 230, 70));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataActionPerformed
      
    }//GEN-LAST:event_dataActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if(!data.getText().equals("  /  /    ")){
                float valorT = 0, valorProd = 0;
                String nomeProd = "", marca = "";
                int qtdeProd = 0, verifica1 = 0, verifica2 = 0;
                List<Pedido> pedidos = new ArrayList<>();
                List<Pedido> pedidoProduto = new ArrayList<>();
                List<Produto> produtos = new ArrayList<>();
                PedidoDaoInterface dao = new PedidosController();
                ProdutoDaoInterface prodDao = new ProdutosController();
                pedidos = (List<Pedido>) dao.pedidos();
                produtos = (List<Produto>) prodDao.produtos();
                DefaultTableModel table;
                table = (DefaultTableModel) dados.getModel();
                ((DefaultTableModel) dados.getModel()).setNumRows(0);
                dados.updateUI();
                for(int x = 0; x < produtos.size(); x++){
                    for(int i = 0; i < pedidos.size(); i++){
                        verifica1 = 0;
                        String d = new SimpleDateFormat("dd/MM/yyyy").format(pedidos.get(i).getData().getTime());
                        if(d.compareTo(data.getText()) == 0){
                            verifica1 = 1;
                            verifica2 = 1;
                            pedidoProduto = (List<Pedido>) dao.pedidoProdutoRelatorio(pedidos.get(i).getId());
                            for(int j = 0; j < pedidoProduto.size(); j++){
                                if(produtos.get(x).getId() == pedidoProduto.get(j).getProdutoId()){
                                    nomeProd = prodDao.produto(produtos.get(x).getId()).getNome();
                                    marca = prodDao.produto(produtos.get(x).getId()).getTipoMarca();
                                    valorProd += prodDao.produto(pedidoProduto.get(j).getProdutoId()).getPrecoUnitarioVenda() * pedidoProduto.get(j).getQuantidade();
                                    qtdeProd += pedidoProduto.get(j).getQuantidade();
                                }
                            }
                        }
                    }
                    if(verifica1 == 1 && valorProd > 0){
                        Locale ptBr = new Locale("pt", "BR");
                        String valorStr = NumberFormat.getCurrencyInstance(ptBr).format(valorProd);
                        table.addRow(new Object[]{nomeProd, marca, qtdeProd, valorStr});
                        valorT += valorProd; 
                        valorProd = 0;
                        qtdeProd = 0;
                        nomeProd = "";
                    }
                }
                if(verifica2 == 0){
                    JOptionPane.showMessageDialog(null, "NENHUM RELATÓRIO PARA ESSA DATA!");
                }
                Locale ptBr = new Locale("pt", "BR");
                String valorString = NumberFormat.getCurrencyInstance(ptBr).format(valorT);
                valorTotal.setText(valorString);
            }else{
                JOptionPane.showMessageDialog(null, "INSIRA UMA DATA!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Vendas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vendas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable dados;
    private javax.swing.JFormattedTextField data;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField valorTotal;
    // End of variables declaration//GEN-END:variables
}
