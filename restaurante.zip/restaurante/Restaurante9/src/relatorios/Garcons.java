package relatorios;

import constantes.Constantes;
import java.awt.Font;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pedido.Pedido;
import pedido.PedidoDaoInterface;
import pedido.PedidosController;
import produto.Produto;
import produto.ProdutoDaoInterface;
import produto.ProdutosController;

public class Garcons extends javax.swing.JFrame {

    public Garcons() {
        initComponents();
    }
    
    public Garcons(String id) {
        initComponents();
        dados.setRowHeight(30);
       
        setLocationRelativeTo( null );
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        dados.setDefaultEditor(Object.class, null); 
        garcom.setText(id);
        data.requestFocus();
        dados.setDefaultEditor(Object.class, null); 
        valorTotalComissao.setFont(new Font("Arial", Font.BOLD, 30));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        data = new javax.swing.JFormattedTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dados = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        garcom = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        valorTotalComissao = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setText("RELATÓRIO DO GARÇOM");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, -1, -1));

        jLabel2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jLabel2.setText("Data:      ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        try {
            data.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dataActionPerformed(evt);
            }
        });
        getContentPane().add(data, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 80, 170, 40));

        jButton1.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/business_salesreport_salesreport_negocio_2353.png"))); // NOI18N
        jButton1.setText("BUSCAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, 180, 60));

        dados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mesa", "Valor Total Pedido", "Valor Comissão"
            }
        ));
        jScrollPane1.setViewportView(dados);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 690, 310));

        jButton2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton2.setText("CANCELAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 480, 330, -1));

        garcom.setEnabled(false);
        garcom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                garcomActionPerformed(evt);
            }
        });
        getContentPane().add(garcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 17, 140, 40));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 530, -1, -1));
        getContentPane().add(valorTotalComissao, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 450, 270, 70));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 530, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataActionPerformed

    }//GEN-LAST:event_dataActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            java.text.DecimalFormat df = new java.text.DecimalFormat("##0.00");
            if(!data.getText().equals("  /  /    ")){
                float valorT = 0, valorTotal = 0;
                String nomeGarcom = "";
                int qtdeMesas = 0, verifica = 0;
                List<Pedido> pedidos = new ArrayList<>();
                Constantes constantes = new Constantes();
                PedidoDaoInterface dao = new PedidosController();
                ProdutoDaoInterface prodDao = new ProdutosController();
                pedidos = (List<Pedido>) dao.pedidosGarcom(Integer.parseInt(garcom.getText()));

                DefaultTableModel table;
                table = (DefaultTableModel) dados.getModel();
                ((DefaultTableModel) dados.getModel()).setNumRows(0);
                dados.updateUI();

                for(int i = 0; i < pedidos.size(); i++){
                        String d = new SimpleDateFormat("dd/MM/yyyy").format(pedidos.get(i).getData().getTime());
                        if(d.compareTo(data.getText()) == 0){
                            verifica = 1;
                            valorT += ((constantes.getValorComissaoGarcom() * pedidos.get(i).getValorTotal())/100);
                            valorTotal += valorT;
                            table.addRow(new Object[]{pedidos.get(i).getMesa(), pedidos.get(i).getValorTotal(), String.valueOf("R$ "+df.format(valorT))});
                    }
                        valorT = 0;
                }
                
                if(verifica == 0){
                    JOptionPane.showMessageDialog(null, "NENHUM RELATÓRIO PARA ESSA DATA OU GARÇOM!");
                }
                Locale ptBr = new Locale("pt", "BR");
                String valorString = NumberFormat.getCurrencyInstance(ptBr).format(valorTotal);
                valorTotalComissao.setText(valorString);
             }else{
                JOptionPane.showMessageDialog(null, "INSIRA UMA DATA!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Garcons.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            this.dispose();
            GarcomLista garcomLista = new GarcomLista();
            garcomLista.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Garcons.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void garcomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_garcomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_garcomActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Garcons().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable dados;
    private javax.swing.JFormattedTextField data;
    private javax.swing.JTextField garcom;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField valorTotalComissao;
    // End of variables declaration//GEN-END:variables
}
