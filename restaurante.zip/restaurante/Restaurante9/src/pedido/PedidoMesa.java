package pedido;

import funcionario.Funcionario;
import funcionario.FuncionarioDaoInterface;
import funcionario.FuncionariosController;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import produto.Produto;
import produto.ProdutoDaoInterface;
import produto.ProdutosController;

public class PedidoMesa extends javax.swing.JFrame {

    ArrayList<Pedido> lista = new ArrayList<>();
    float valorParcial = 0;
    Pedido pedidoEnviar = new Pedido();
    int pedidoId = 0, qualJanela;
    String garcomNome = "";

    public PedidoMesa() {
        initComponents();
        dados.setRowHeight(30);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        dados.setDefaultEditor(Object.class, null);
        garcom.removeAllItems();
        add.setEnabled(false);

        try {
            ProdutoDaoInterface produtoController = new ProdutosController();

            List<Produto> produtos;

            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();

            produtos = (ArrayList) produtoController.produtos();

            for (int i = 0; i < produtos.size(); i++) {
                table.addRow(new Object[]{produtos.get(i).getId(), produtos.get(i).getNome(), produtos.get(i).getTipoMarca(), produtos.get(i).getQuantidade(), produtos.get(i).getPrecoUnitarioVenda()});
            }

            FuncionarioDaoInterface dao = new FuncionariosController();
            List<Funcionario> funcionarios;
            funcionarios = (ArrayList) dao.funcionarios();
            if (this.garcomNome.equals("")) {
                garcom.addItem("Selecione um Garçom");
            } else {
                garcom.addItem(this.garcomNome);
            }
            for (int i = 0; i < funcionarios.size(); i++) {
                garcom.addItem(funcionarios.get(i).getId() + "- " + funcionarios.get(i).getNome());
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public PedidoMesa(int num, int janela) {
        initComponents();
        dados.setRowHeight(30);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        dados.setDefaultEditor(Object.class, null);
        qualJanela = janela;
        garcom.removeAllItems();
        mesa.setText(String.valueOf(num));
        add.setEnabled(false);
        try {
            ProdutoDaoInterface produtoController = new ProdutosController();

            List<Produto> produtos;

            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();

            produtos = (ArrayList) produtoController.produtos();

            for (int i = 0; i < produtos.size(); i++) {
                table.addRow(new Object[]{produtos.get(i).getId(), produtos.get(i).getNome(), produtos.get(i).getTipoMarca(), produtos.get(i).getQuantidade(), produtos.get(i).getPrecoUnitarioVenda()});
            }

            FuncionarioDaoInterface dao = new FuncionariosController();
            List<Funcionario> funcionarios;
            funcionarios = (ArrayList) dao.funcionarios();
            if (this.garcomNome.equals("")) {
                garcom.addItem("Selecione um Garçom");
            } else {
                garcom.addItem(this.garcomNome);
            }
            for (int i = 0; i < funcionarios.size(); i++) {
                garcom.addItem(funcionarios.get(i).getId() + "- " + funcionarios.get(i).getNome());
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public PedidoMesa(int num, int garcomId, int p, int janela) {
        try {
            initComponents();
            dados.setRowHeight(30);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
            dados.setDefaultEditor(Object.class, null);
            qualJanela = janela;
            garcom.removeAllItems();
            mesa.setText(String.valueOf(num));
            add.setEnabled(false);
            Funcionario funcionario = new Funcionario();
            FuncionarioDaoInterface dao = new FuncionariosController();
            funcionario = dao.funcionario(garcomId);
            pedidoId = p;
            this.garcomNome = funcionario.getId() + "- " + funcionario.getNome();
            List<Funcionario> funcionarios;
            funcionarios = (ArrayList) dao.funcionarios();
            if (this.garcomNome.equals("")) {
                garcom.addItem("Selecione um Garçom");
            } else {
                garcom.setSelectedItem(this.garcomNome);
            }
            for (int i = 0; i < funcionarios.size(); i++) {
                garcom.addItem(funcionarios.get(i).getId() + "- " + funcionarios.get(i).getNome());
            }
            ProdutoDaoInterface produtoController = new ProdutosController();

            List<Produto> produtos;

            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();

            produtos = (ArrayList) produtoController.produtos();

            for (int i = 0; i < produtos.size(); i++) {
                table.addRow(new Object[]{produtos.get(i).getId(), produtos.get(i).getNome(), produtos.get(i).getTipoMarca(), produtos.get(i).getQuantidade(), produtos.get(i).getPrecoUnitarioVenda()});
            }

        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        mesa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nome = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dados = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        garcom = new javax.swing.JComboBox<>();
        add = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setText("INSERIR PEDIDO NA MESA");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, -1, -1));

        mesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesaActionPerformed(evt);
            }
        });
        getContentPane().add(mesa, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, 120, 40));

        jLabel3.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel3.setText("PRODUTOS");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        jLabel4.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jLabel4.setText("Nome:   ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeActionPerformed(evt);
            }
        });
        getContentPane().add(nome, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, 270, 40));

        jButton3.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/pesquisar.png"))); // NOI18N
        jButton3.setText("BUSCAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 204, 160, 50));

        dados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome", "Marca/Tipo", "Quantidade", "Valor Unitário  Venda  R$ "
            }
        ));
        dados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dados);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 830, 290));

        jButton2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton2.setText("CANCELAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 600, 320, 50));

        garcom.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        garcom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                garcomActionPerformed(evt);
            }
        });
        getContentPane().add(garcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 460, 60));

        add.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/confirm.png"))); // NOI18N
        add.setText("CONFIRMAR PEDIDO");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        getContentPane().add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 180, 230, 70));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 670, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mesaActionPerformed

    private void nomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeActionPerformed

    }//GEN-LAST:event_nomeActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            ProdutoDaoInterface produtoController = new ProdutosController();

            List<Produto> produtos;

            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();

            produtos = (ArrayList) produtoController.busca(nome.getText());

            for (int i = 0; i < produtos.size(); i++) {
                table.addRow(new Object[]{produtos.get(i).getId(), produtos.get(i).getNome(), produtos.get(i).getTipoMarca(), produtos.get(i).getQuantidade(), produtos.get(i).getPrecoUnitarioVenda()});
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void dadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dadosMouseClicked
        if (evt.getClickCount() > 1) {
            int op = JOptionPane.showConfirmDialog(null, "\nDETALHES\n\n" + "NOME: " + dados.getValueAt(dados.getSelectedRow(), 1) + "\n\nMARCA/TIPO: " + dados.getValueAt(dados.getSelectedRow(), 2)+"\n\n\nDESEJA ADICIONAR O PRODUTO? \n\n");
            if (op == 0) {
                try {
                    if (garcom.getSelectedItem().toString().equals("Selecione um Garçom")) {
                        JOptionPane.showMessageDialog(null, "Selecione um garçom!");
                    } else {
                        String qtdeCompra = JOptionPane.showInputDialog("Quantidade?");
                        int qtde = Integer.parseInt(qtdeCompra);
                        if (qtde > 0) {
                            Object id = (dados.getValueAt(dados.getSelectedRow(), 0));
                            Object nomeProd = (dados.getValueAt(dados.getSelectedRow(), 1));
                            Object marca = (dados.getValueAt(dados.getSelectedRow(), 2));
                            Object quantidade = (dados.getValueAt(dados.getSelectedRow(), 3));
                            Object valorVenda = (dados.getValueAt(dados.getSelectedRow(), 4));

                            String Id = id.toString();
                            String Nome = nomeProd.toString();
                            String Marca = marca.toString();
                            String qtdeEstoque = quantidade.toString();
                            String valorV = valorVenda.toString();

                            PedidoDaoInterface pedidodao = new PedidosController();
                            ProdutoDaoInterface dao = new ProdutosController();
                            Produto produto = new Produto();
                            produto = dao.produto(Integer.parseInt(Id));
                            Pedido pedido = new Pedido();
                            int qtdeArray = 0;
                            for (int i = 0; i < lista.size(); i++) {
                                if (lista.get(i).getProdutoId() == Integer.parseInt(Id)) {
                                    qtdeArray += lista.get(i).getQuantidade();
                                }
                            }
                            String garcomStr = garcom.getSelectedItem().toString();
                            String[] idGarcom = garcomStr.split("-");
                            int estoque = (produto.getQuantidade() - pedidodao.quantidadeProdutoItemProduto(Integer.parseInt(Id))) - qtdeArray;
                            if (estoque >= qtde) {
                                qtdeArray = 0;
                                //valorParcial += qtde * produto.getPrecoUnitarioVenda();
                                pedido.setProdutoId(Integer.parseInt(Id));
                                pedido.setQuantidade(qtde);
                                pedidoEnviar.setGarcom_id(Integer.parseInt(idGarcom[0]));
                                //pedidoEnviar.setValorParcial(valorParcial);
                                //pedidoEnviar.setValorTotal(valorParcial);
                                pedidoEnviar.setMesa(Integer.parseInt(mesa.getText()));
                                lista.add(pedido);
                                add.setEnabled(true);
                            } else {
                                JOptionPane.showMessageDialog(null, "QUANTIDADE INSUFICIENTE! EXISTEM APENAS " + estoque + " ITEMS DESSE PRODUTO NO ESTOQUE!");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "ADICIONE ALGUM PRODUTO!");
                        }
                    }
                    //ProdutoEditar editar = new ProdutoEditar(Id, Nome, Marca, qtde, valorC, valorV);
                    //editar.setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_dadosMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        PedidosMesa pedidosmesa = new PedidosMesa(mesa.getText(), qualJanela);
        lista.clear();
        pedidosmesa.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void garcomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_garcomActionPerformed

    }//GEN-LAST:event_garcomActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        try {
            PedidoDaoInterface pedido = new PedidosController();
            if (pedidoId > 0) {
                pedidoEnviar.setId(pedidoId);
                pedido.editar(pedidoEnviar, lista);
                valorParcial = 0;
                lista.clear();
                pedidoEnviar = new Pedido();
                this.dispose();
                PedidosMesa pedidosmesa = new PedidosMesa(mesa.getText(), qualJanela);
                pedidosmesa.setVisible(true);
            } else {
                pedido.cadastrar(pedidoEnviar, lista);
                valorParcial = 0;
                pedidoEnviar = new Pedido();
                this.dispose();
                PedidosMesa pedidosmesa = new PedidosMesa(mesa.getText(), qualJanela);
                lista.clear();
                pedidosmesa.setVisible(true);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PedidoMesa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JTable dados;
    private javax.swing.JComboBox<String> garcom;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField mesa;
    private javax.swing.JTextField nome;
    // End of variables declaration//GEN-END:variables
}
