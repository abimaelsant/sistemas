package pedido;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import funcionario.FuncionarioDaoInterface;
import funcionario.FuncionariosController;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.ServiceUI;
import javax.print.SimpleDoc;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import produto.Produto;
import produto.ProdutoDaoInterface;
import produto.ProdutosController;

public class PedidosMesa extends javax.swing.JFrame {

    int garcomId, qualJanela;

    public PedidosMesa() {
        initComponents();
    }

    public PedidosMesa(String m, int janela) {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        qualJanela = janela;
        mesa.setText(m);
        dados.setRowHeight(25);
        itemPedido.setRowHeight(25);
        dados.setDefaultEditor(Object.class, null);
        itemPedido.setDefaultEditor(Object.class, null);
        try {
            PedidoDaoInterface pedidosController = new PedidosController();
            FuncionarioDaoInterface funcionariosController = new FuncionariosController();
            boolean teste = pedidosController.pedidosMesaExiste(Integer.parseInt(mesa.getText()));
            if (teste == true) {
                add.setEnabled(false);
            }
            List<Pedido> pedidos;

            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();

            pedidos = (ArrayList) pedidosController.pedidosMesa(Integer.parseInt(mesa.getText()));

            for (int i = 0; i < pedidos.size(); i++) {
                garcomId = pedidos.get(i).getGarcom_id();
                table.addRow(new Object[]{pedidos.get(i).getId(), pedidos.get(i).getMesa(), funcionariosController.nomeFuncionario(pedidos.get(i).getGarcom_id())});
                valorTotal(pedidos.get(i).getId());
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        mesa = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        dados = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        itemPedido = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        valorTotal = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setText("PEDIDOS DA MESA");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        mesa.setEnabled(false);
        mesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mesaActionPerformed(evt);
            }
        });
        getContentPane().add(mesa, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 120, 40));

        dados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Mesa", "Garçom"
            }
        ));
        dados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dados);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 780, 220));

        itemPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Produto", "Quantidade", "Preço Unitário"
            }
        ));
        itemPedido.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemPedidoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(itemPedido);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 780, 160));

        jLabel2.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel2.setText("Items do pedido");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, -1, -1));

        jLabel3.setFont(new java.awt.Font("Ubuntu", 0, 11)); // NOI18N
        jLabel3.setForeground(java.awt.SystemColor.activeCaption);
        jLabel3.setText("*Para ver os items do pedido, selecione um pedido na tabela acima.");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 390, -1, -1));

        jButton2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton2.setText("CANCELAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 610, 320, 50));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 680, 30, 10));

        add.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/plus (1).png"))); // NOI18N
        add.setText("ADICIONAR PEDIDO À MESA");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        getContentPane().add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 20, 310, 60));

        jButton3.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/atualizar.png"))); // NOI18N
        jButton3.setText("ATUALIZAR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 94, 310, 50));

        valorTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                valorTotalActionPerformed(evt);
            }
        });
        getContentPane().add(valorTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 200, 70));

        jLabel5.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel5.setText("R$");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, -1, -1));

        jButton1.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/icons8-finalizar-pedido-50.png"))); // NOI18N
        jButton1.setText("FINALIZAR PEDIDO");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 610, 340, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mesaActionPerformed

    }//GEN-LAST:event_mesaActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        if(qualJanela == 1){
            try {
                Mesas mesas = new Mesas();
                mesas.setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(qualJanela == 2){
            try {
                Mesas2 mesas = new Mesas2();
                mesas.setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(qualJanela == 3){
            try {
                Mesas3 mesas = new Mesas3();
                mesas.setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            PedidoDaoInterface pedidosController = new PedidosController();
            FuncionarioDaoInterface funcionariosController = new FuncionariosController();
            boolean teste = pedidosController.pedidosMesaExiste(Integer.parseInt(mesa.getText()));
            if (teste == true) {
                add.setEnabled(false);
            }
            List<Pedido> pedidos;

            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();

            pedidos = (ArrayList) pedidosController.pedidosMesa(Integer.parseInt(mesa.getText()));

            for (int i = 0; i < pedidos.size(); i++) {
                garcomId = pedidos.get(i).getGarcom_id();
                table.addRow(new Object[]{pedidos.get(i).getId(), pedidos.get(i).getMesa(), funcionariosController.nomeFuncionario(pedidos.get(i).getGarcom_id())});
                valorTotal(pedidos.get(i).getId());
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void dadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dadosMouseClicked
        if (evt.getClickCount() == 1) {
            try {
                java.text.DecimalFormat df = new java.text.DecimalFormat("##0.00");
                Object pedidoId = (dados.getValueAt(dados.getSelectedRow(), 0));
                String pedidoIdBusca = pedidoId.toString();
                PedidoDaoInterface pedidosController = new PedidosController();
                FuncionarioDaoInterface funcionariosController = new FuncionariosController();
                ProdutoDaoInterface produtoDao = new ProdutosController();

                List<Pedido> pedidos;

                DefaultTableModel table;
                table = (DefaultTableModel) itemPedido.getModel();
                ((DefaultTableModel) itemPedido.getModel()).setNumRows(0);
                itemPedido.updateUI();

                pedidos = (ArrayList) pedidosController.pedidoProduto(Integer.parseInt((pedidoIdBusca)));

                for (int i = 0; i < pedidos.size(); i++) {
                    table.addRow(new Object[]{pedidos.get(i).getId(), produtoDao.produto(pedidos.get(i).getProdutoId()).getNome(), pedidos.get(i).getQuantidade(), String.valueOf(df.format(produtoDao.produto(pedidos.get(i).getProdutoId()).getPrecoUnitarioVenda()))});
                }
                valorTotal(Integer.parseInt((pedidoIdBusca)));
            } catch (SQLException ex) {
                Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (evt.getClickCount() > 1) {
            Object pedidoId = (dados.getValueAt(dados.getSelectedRow(), 0));
            String pedido = pedidoId.toString();
            PedidoMesa pedidomesa = new PedidoMesa(Integer.parseInt(mesa.getText()), garcomId, Integer.parseInt(pedido), qualJanela);
            pedidomesa.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_dadosMouseClicked

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        PedidoMesa pedidomesa = new PedidoMesa(Integer.parseInt(mesa.getText()), qualJanela);
        pedidomesa.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_addActionPerformed

    private void itemPedidoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemPedidoMouseClicked
        if (evt.getClickCount() == 1) {
            try {
                java.text.DecimalFormat df = new java.text.DecimalFormat("##0.00");
                int dialogButton = JOptionPane.YES_NO_OPTION;
                int opcao = JOptionPane.showConfirmDialog(null, "Deseja retirar o item?", "Warning", dialogButton);
                if (opcao == JOptionPane.YES_OPTION) {
                    Object id = (itemPedido.getValueAt(itemPedido.getSelectedRow(), 0));
                    String idItem = id.toString();
                    PedidoDaoInterface dao = new PedidosController();
                    dao.deletarItemPedido(Integer.parseInt(idItem));
                    Object pedidoId = (dados.getValueAt(dados.getSelectedRow(), 0));
                    String pedidoIdBusca = pedidoId.toString();
                    PedidoDaoInterface pedidosController = new PedidosController();
                    FuncionarioDaoInterface funcionariosController = new FuncionariosController();
                    ProdutoDaoInterface produtoDao = new ProdutosController();

                    List<Pedido> pedidos;

                    DefaultTableModel table;
                    table = (DefaultTableModel) itemPedido.getModel();
                    ((DefaultTableModel) itemPedido.getModel()).setNumRows(0);
                    itemPedido.updateUI();

                    pedidos = (ArrayList) pedidosController.pedidoProduto(Integer.parseInt((pedidoIdBusca)));

                    for (int i = 0; i < pedidos.size(); i++) {
                        table.addRow(new Object[]{pedidos.get(i).getId(), produtoDao.produto(pedidos.get(i).getProdutoId()).getNome(), pedidos.get(i).getQuantidade(), String.valueOf(df.format(produtoDao.produto(pedidos.get(i).getProdutoId()).getPrecoUnitarioVenda()))});
                    }
                    valorTotal(Integer.parseInt((pedidoIdBusca)));
                }
            } catch (SQLException ex) {
                Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_itemPedidoMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            dados.addRowSelectionInterval(0, 0);
            List<Pedido> itemsPedido = new ArrayList<>();
            PedidoDaoInterface dao = new PedidosController();
            Object pedidoId = (dados.getValueAt(dados.getSelectedRow(), 0));
            String pedido = pedidoId.toString();
            itemsPedido = (List) dao.pedidoProduto(Integer.parseInt(pedido));
            extrato(Integer.parseInt(pedido));
            dao.desativar(Integer.parseInt(pedido), itemsPedido, Float.parseFloat(valorTotal.getText().replace(',', '.')));
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();
            valorTotal.setText("");
            this.dispose();
            if(qualJanela == 1){
                Mesas mesas = new Mesas();
                mesas.setVisible(true);
            }
            if(qualJanela == 2){
                Mesas2 mesas = new Mesas2();
                mesas.setVisible(true);
            }
            if(qualJanela == 3){
                Mesas3 mesas = new Mesas3();
                mesas.setVisible(true);
            }
        } catch (SQLException | PrintException | FileNotFoundException ex) {
            Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void valorTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_valorTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_valorTotalActionPerformed

    public final void valorTotal(int pedidoId) {
        try {
            java.text.DecimalFormat df = new java.text.DecimalFormat("##0.00");
            float valor = 0;
            PedidoDaoInterface dao = new PedidosController();
            valor = dao.calculaValor(pedidoId);
            valorTotal.setEditable(false);
            valorTotal.setFont(new Font("Arial", Font.BOLD, 30));
            valorTotal.setText(String.valueOf((df.format(BigDecimal.valueOf(valor)))));
        } catch (SQLException ex) {
            Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void extrato(int pedidoId) throws PrintException, FileNotFoundException {
        try {
            java.text.DecimalFormat df = new java.text.DecimalFormat("##0.00");
            dados.addRowSelectionInterval(0, 0);
            Object pedido = (dados.getValueAt(dados.getSelectedRow(), 0));
            pedidoId = Integer.parseInt(pedido.toString());
            PedidoDaoInterface pedidosController = new PedidosController();
            FuncionarioDaoInterface funcionariosController = new FuncionariosController();
            ProdutoDaoInterface produtoDao = new ProdutosController();

            List<Pedido> pedidos;
            List<Pedido> pedidoMesa;

            DefaultTableModel table;
            table = (DefaultTableModel) itemPedido.getModel();
            ((DefaultTableModel) itemPedido.getModel()).setNumRows(0);
            itemPedido.updateUI();

            pedidos = (ArrayList) pedidosController.pedidoProduto((pedidoId));
            pedidoMesa = (ArrayList) pedidosController.pedidosMesa((Integer.parseInt(mesa.getText())));

            int Mesa = 0;
            String data = "", extrato = "", subextrato = "";

            for (int i = 0; i < pedidoMesa.size(); i++) {
                Mesa = pedidoMesa.get(i).getMesa();
                data = new SimpleDateFormat("dd/MM/yyyy").format(pedidoMesa.get(i).getData().getTime());
            }
            extrato = "**EXTRATO DE PEDIDO **\n\nMESA: " + Mesa + " --- Data: " + data + "\n\n" + "Items do pedido: ";
            for (int i = 0; i < pedidos.size(); i++) {
                Produto produto;
                produto = produtoDao.produto(pedidos.get(i).getProdutoId());
                subextrato += "\n\nNome produto: " + produto.getNome() + "\nQuantidade: " + pedidos.get(i).getQuantidade() + "\nValor: " + String.valueOf(df.format((BigDecimal.valueOf(pedidos.get(i).getQuantidade() * produto.getPrecoUnitarioVenda()))));
            }
            extrato += subextrato + "\n\nValor Total: " + (valorTotal.getText());
            JOptionPane.showMessageDialog(null, extrato);
            PrintService[] printService = PrintServiceLookup.lookupPrintServices(DocFlavor.INPUT_STREAM.AUTOSENSE, null);
            System.out.println("Quantas Impressoras:  " + printService.length);
            PrintService impressoraPadrao = PrintServiceLookup.lookupDefaultPrintService();
            System.out.println("A impressora padrão é:  " + impressoraPadrao.getName());
            DocFlavor docFlavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
            HashDocAttributeSet hashDocAttributeSet = new HashDocAttributeSet();
            Document document = new Document();
            String t = "extratopedido";
            String nome = "C:\\Users\\Abimael\\Documents\\" + t + ".pdf";
            //DecimalFormat df = new DecimalFormat("0.00");

            PdfWriter.getInstance(document, new FileOutputStream(nome));
            document.open();

            // adicionando um parágrafo no documento
            document.add(new Paragraph(extrato));

            document.close();
            FileInputStream fileInputStream = new FileInputStream(nome);
            Doc doc = new SimpleDoc(fileInputStream, docFlavor, hashDocAttributeSet);
            PrintRequestAttributeSet printResquestAttributeSet = new HashPrintRequestAttributeSet();
            PrintService printServico = ServiceUI.printDialog(null, 300, 200, printService, impressoraPadrao, docFlavor, printResquestAttributeSet);
            if (printServico != null) {
                DocPrintJob docPrintJob = printServico.createPrintJob();
                docPrintJob.print(doc, printResquestAttributeSet);
            }
            File f = new File(nome);
            if( f.delete() ){

            }
        } catch (SQLException | DocumentException ex) {
            Logger.getLogger(PedidosMesa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PedidosMesa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JTable dados;
    private javax.swing.JTable itemPedido;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField mesa;
    private javax.swing.JTextField valorTotal;
    // End of variables declaration//GEN-END:variables
}
