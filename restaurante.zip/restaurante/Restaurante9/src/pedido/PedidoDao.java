package pedido;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.JOptionPane;
import produto.Produto;
import produto.ProdutoDaoInterface;
import produto.ProdutosController;

public class PedidoDao implements PedidoDaoInterface{
     private final Connection conexao;
    
    public PedidoDao(Connection conexao){
        this.conexao = conexao;
    }
    
    @Override
    public void cadastrar(Pedido pedido, List<Pedido> pedidoProduto) {
        String sql = "INSERT INTO pedido (numeroMesa, garcom_id, valorParcial, valorTotal, ativo) VALUES (?, ?, ?, ?, ?)";
        String sqlItemPedido = "INSERT INTO pedido_produto (pedido_id, produto_id, quantidade) VALUES (?, ?, ?)";
        try{
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, pedido.getMesa());
                stmt.setInt(2, pedido.getGarcom_id());
                stmt.setFloat(3, pedido.getValorParcial());
                stmt.setFloat(4, pedido.getValorTotal());
                stmt.setBoolean(5, true);
                stmt.execute();
               
                PreparedStatement sqlId = this.conexao.prepareStatement("SELECT LAST_INSERT_ID()");
                ResultSet rs = sqlId.executeQuery();
                if (rs.next()) {
                    pedido.setId(rs.getInt("LAST_INSERT_ID()"));                
                }
                //JOptionPane.showMessageDialog(null, "CADASTRO REALIZADO COM SUCESSO");
            }
            for(int i = 0; i < pedidoProduto.size(); i++){
                pedido.setProdutoId(pedidoProduto.get(i).getProdutoId());
                pedido.setQuantidade(pedidoProduto.get(i).getQuantidade());
                try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sqlItemPedido)) {
                    stmt.setInt(1, pedido.getId());
                    stmt.setInt(2, pedido.getProdutoId());
                    stmt.setFloat(3, pedido.getQuantidade());
                    stmt.execute();
                }
            }
            JOptionPane.showMessageDialog(null, "REALIZADO COM SUCESSO!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void editar(Pedido pedido, List<Pedido> pedidoProduto) {
        String sql = "UPDATE pedido set numeroMesa=?, garcom_id=?, valorParcial=?, valorTotal=?, ativo=? where id=?";
        String sqlItemPedido = "INSERT INTO pedido_produto (pedido_id, produto_id, quantidade) VALUES (?, ?, ?)";
        try {
            float valor = 0;
            PreparedStatement sqlBusca = this.conexao.prepareStatement("select *from pedido where id=?");
            sqlBusca.setInt(1, pedido.getId());
            ResultSet rs = sqlBusca.executeQuery();

            while (rs.next()) {
                valor = rs.getFloat("valorTotal");
            }
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, pedido.getMesa());
                stmt.setInt(2, pedido.getGarcom_id());
                stmt.setFloat(3, pedido.getValorParcial());
                stmt.setFloat(4, pedido.getValorTotal() + valor);
                stmt.setBoolean(5, true);
                stmt.setInt(6, pedido.getId());
                stmt.executeUpdate();
               // JOptionPane.showMessageDialog(null, "EDITADO COM SUCESSO!");
            }
            for(int i = 0; i < pedidoProduto.size(); i++){
                pedido.setProdutoId(pedidoProduto.get(i).getProdutoId());
                pedido.setQuantidade(pedidoProduto.get(i).getQuantidade());
                try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sqlItemPedido)) {
                    stmt.setInt(1, pedido.getId());
                    stmt.setInt(2, pedido.getProdutoId());
                    stmt.setFloat(3, pedido.getQuantidade());
                    stmt.executeUpdate();
                }
            }
            JOptionPane.showMessageDialog(null, "REALIZADO COM SUCESSO!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE! "+e);
        }
    }
    
    @Override
    public void deletar(int id) {

        String sql = "DELETE FROM pedido WHERE id=?";
        String sqlItemPedido = "DELETE FROM pedido_produto WHERE pedido_id=?";
        try {
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, id);
                stmt.execute();
            }
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sqlItemPedido)) {
                stmt.setInt(1, id);
                stmt.execute();
            }
            JOptionPane.showMessageDialog(null, "DELETADO COM SUCESSO!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }
    
     @Override
    public void deletarItemPedido(int id) {
        String sqlItemPedido = "DELETE FROM pedido_produto WHERE id=?";
        try {
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sqlItemPedido)) {
                stmt.setInt(1, id);
                stmt.execute();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void desativar(int id, List<Pedido> pedidoProduto, float valorTotal) {

        String sql = "UPDATE pedido set valorTotal=?, ativo=? WHERE id=?";
        String sqlItemPedido = "UPDATE pedido_produto set ativo=? WHERE pedido_id=?";
        
        try {
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setFloat(1, valorTotal);
                stmt.setBoolean(2, false);
                stmt.setInt(3, id);
                stmt.executeUpdate();
            }
            
            retiraProdutos(id);
            
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sqlItemPedido)) {
                stmt.setBoolean(1, false);
                stmt.setInt(2, id);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }

    @Override
    public Collection<Pedido> pedidos() {

        List<Pedido> pedidos = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido where ativo=?");
            sql.setBoolean(1, false);
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setId(rs.getInt("id"));
                pedido.setMesa(rs.getInt("numeroMesa"));
                pedido.setGarcom_id(rs.getInt("garcom_id"));
                pedido.setValorParcial(rs.getFloat("valorParcial"));
                pedido.setValorTotal(rs.getFloat("valorTotal"));
                pedido.setAtivo(rs.getBoolean("ativo"));
                pedido.setData(rs.getTimestamp("data_pedido"));
                pedidos.add(pedido);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return (pedidos);
    }
    
    
    @Override
    public Collection<Pedido> pedidosGarcom(int garcomId) {

        List<Pedido> pedidos = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido where garcom_id=? and ativo=?");
            sql.setInt(1, garcomId);
            sql.setBoolean(2, false);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setId(rs.getInt("id"));
                pedido.setMesa(rs.getInt("numeroMesa"));
                pedido.setGarcom_id(rs.getInt("garcom_id"));
                pedido.setValorParcial(rs.getFloat("valorParcial"));
                pedido.setValorTotal(rs.getFloat("valorTotal"));
                pedido.setAtivo(rs.getBoolean("ativo"));
                pedido.setData(rs.getTimestamp("data_pedido"));
                pedidos.add(pedido);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!"+e);
        }
        return (pedidos);
    }
    
    @Override
    public Collection<Pedido> pedidosMesa(int numeroMesa) {

        List<Pedido> pedidos = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido where numeroMesa=? and ativo=?");
            
            sql.setInt(1, numeroMesa);
            sql.setBoolean(2, true);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setId(rs.getInt("id"));
                pedido.setMesa(rs.getInt("numeroMesa"));
                pedido.setGarcom_id(rs.getInt("garcom_id"));
                pedido.setValorParcial(rs.getFloat("valorParcial"));
                pedido.setValorTotal(rs.getFloat("valorTotal"));
                pedido.setAtivo(rs.getBoolean("ativo"));
                pedido.setData(rs.getTimestamp("data_pedido"));
                pedidos.add(pedido);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return (pedidos);
    }
    
     @Override
    public Boolean pedidosMesaExiste(int numeroMesa) {

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido where numeroMesa=? and ativo=?");
            
            sql.setInt(1, numeroMesa);
            sql.setBoolean(2, true);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                if(rs.getInt("id") > 0){
                    return true;
                }
            }

        } catch (SQLException e) {
      
        }
        return false;
    }
    
    @Override
    public Collection<Pedido> pedidoProduto(int pedidoId) {

        List<Pedido> pedidosProdutos = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido_produto where pedido_id=? and ativo=?");
            
            sql.setInt(1, pedidoId);
            sql.setBoolean(2, true);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setId(rs.getInt("id"));
                pedido.setProdutoId(rs.getInt("produto_id"));
                pedido.setQuantidade(rs.getInt("quantidade"));
                pedido.setAtivo(rs.getBoolean("ativo"));
                pedidosProdutos.add(pedido);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE! "+e);
        }
        return (pedidosProdutos);
    }
    
    @Override
    public Collection<Pedido> pedidoProdutoRelatorio(int pedidoId) {

        List<Pedido> pedidosProdutos = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido_produto where pedido_id=? and ativo=?");
            
            sql.setInt(1, pedidoId);
            sql.setBoolean(2, false);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setId(rs.getInt("id"));
                pedido.setProdutoId(rs.getInt("produto_id"));
                pedido.setQuantidade(rs.getInt("quantidade"));
                pedido.setAtivo(rs.getBoolean("ativo"));
                pedidosProdutos.add(pedido);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE! "+e);
        }
        return (pedidosProdutos);
    }
    
     @Override
    public float calculaValor(int pedidoId) {
        float valor = 0;
        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido_produto where pedido_id=? and ativo=?");
            
            sql.setInt(1, pedidoId);
            sql.setBoolean(2, true);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setId(rs.getInt("id"));
                pedido.setProdutoId(rs.getInt("produto_id"));
                pedido.setQuantidade(rs.getInt("quantidade"));
                pedido.setAtivo(rs.getBoolean("ativo"));
                
                ProdutoDaoInterface dao = new ProdutosController();
                Produto produto = new Produto();
                produto = dao.produto((rs.getInt("produto_id")));
                valor += (rs.getInt("quantidade") * produto.getPrecoUnitarioVenda());
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return valor;
    }
    
    public void retiraProdutos(int pedidoId) throws SQLException{
        ProdutoDaoInterface dao = new ProdutosController();
        PreparedStatement sql = this.conexao.prepareStatement("select *from pedido_produto where pedido_id=? and ativo=?");
        sql.setInt(1, pedidoId);
        sql.setBoolean(2, true);
           
        ResultSet rs = sql.executeQuery();

        while (rs.next()) {
            Produto produto = new Produto();
            Produto produto2 = new Produto();
            produto2 = dao.produto(rs.getInt("produto_id"));
            produto.setId(rs.getInt("produto_id"));
            produto.setQuantidade(produto2.getQuantidade() - rs.getInt("quantidade"));
            dao.editarQuantidade(produto);
        }
    }
    
     @Override
    public int quantidadeProdutoItemProduto(int produtoId){
        int qtde = 0;
   
        try {

            PreparedStatement sql = this.conexao.prepareStatement("select *from pedido_produto where produto_id=? and ativo=?");
            
            sql.setInt(1, produtoId);
            sql.setBoolean(2, true);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                qtde += rs.getInt("quantidade");                
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return qtde;
    }
}
