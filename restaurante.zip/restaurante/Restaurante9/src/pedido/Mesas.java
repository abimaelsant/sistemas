package pedido;

import java.awt.Color;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mesas extends javax.swing.JFrame {

    public Mesas() throws SQLException {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        jLabel1.setFocusable(true);
        JBT1.setBackground(Color.GREEN);
        JBT2.setBackground(Color.GREEN);
        JBT3.setBackground(Color.GREEN);
        JBT4.setBackground(Color.GREEN);
        JBT5.setBackground(Color.GREEN);
        JBT6.setBackground(Color.GREEN);
        JBT7.setBackground(Color.GREEN);
        JBT7.setBackground(Color.GREEN);
        JBT8.setBackground(Color.GREEN);
        JBT9.setBackground(Color.GREEN);
        JBT10.setBackground(Color.GREEN);
        JBT11.setBackground(Color.GREEN);
        JBT12.setBackground(Color.GREEN);
        JBT13.setBackground(Color.GREEN);
        JBT14.setBackground(Color.GREEN);
        JBT15.setBackground(Color.GREEN);
        JBT16.setBackground(Color.GREEN);
        JBT17.setBackground(Color.GREEN);
        JBT18.setBackground(Color.GREEN);
        JBT19.setBackground(Color.GREEN);
        JBT20.setBackground(Color.GREEN);
        JBT21.setBackground(Color.GREEN);
        JBT22.setBackground(Color.GREEN);
        JBT23.setBackground(Color.GREEN);
        JBT24.setBackground(Color.GREEN);
        JBT25.setBackground(Color.GREEN);
        JBT26.setBackground(Color.GREEN);
        JBT27.setBackground(Color.GREEN);
        JBT28.setBackground(Color.GREEN);
        JBT29.setBackground(Color.GREEN);
        JBT30.setBackground(Color.GREEN);
        JBT31.setBackground(Color.GREEN);
        JBT32.setBackground(Color.GREEN);
        JBT33.setBackground(Color.GREEN);
        JBT34.setBackground(Color.GREEN);
        JBT35.setBackground(Color.GREEN);
        JBT36.setBackground(Color.GREEN);
        JBT37.setBackground(Color.GREEN);
        JBT38.setBackground(Color.GREEN);
        JBT39.setBackground(Color.GREEN);
        JBT40.setBackground(Color.GREEN);
        JBT41.setBackground(Color.GREEN);
        JBT42.setBackground(Color.GREEN);
        JBT43.setBackground(Color.GREEN);
        JBT44.setBackground(Color.GREEN);
        JBT45.setBackground(Color.GREEN);
        alteraCor();
    }
    public final void alteraCor() throws SQLException{
        PedidoDaoInterface pedidosController = new PedidosController();
        if (pedidosController.pedidosMesaExiste(1) == true) {
            JBT1.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(2) == true) {
            JBT2.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(3) == true) {
            JBT3.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(4) == true) {
            JBT4.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(5) == true) {
            JBT45.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(6) == true) {
            JBT5.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(7) == true) {
            JBT6.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(8) == true) {
            JBT7.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(9) == true) {
            JBT8.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(10) == true) {
            JBT44.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(11) == true) {
            JBT9.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(12) == true) {
            JBT10.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(13) == true) {
            JBT11.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(14) == true) {
            JBT12.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(15) == true) {
            JBT43.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(16) == true) {
            JBT13.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(17) == true) {
            JBT14.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(18) == true) {
            JBT15.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(19) == true) {
            JBT16.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(20) == true) {
            JBT42.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(21) == true) {
            JBT17.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(22) == true) {
            JBT18.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(13) == true) {
            JBT19.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(24) == true) {
            JBT20.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(25) == true) {
            JBT41.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(26) == true) {
            JBT21.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(27) == true) {
            JBT22.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(28) == true) {
            JBT23.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(29) == true) {
            JBT24.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(30) == true) {
            JBT40.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(31) == true) {
            JBT25.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(32) == true) {
            JBT26.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(33) == true) {
            JBT27.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(34) == true) {
            JBT28.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(35) == true) {
            JBT39.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(36) == true) {
            JBT29.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(37) == true) {
            JBT30.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(38) == true) {
            JBT31.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(39) == true) {
            JBT32.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(40) == true) {
            JBT38.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(41) == true) {
            JBT33.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(42) == true) {
            JBT34.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(43) == true) {
            JBT35.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(44) == true) {
            JBT36.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(45) == true) {
            JBT37.setBackground(Color.red);
        }
    }
    public void abreMesa(int num){
        PedidosMesa pmesa = new PedidosMesa(String.valueOf(num), 1);
        pmesa.setVisible(true);
        this.dispose();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        JBT1 = new javax.swing.JButton();
        JBT2 = new javax.swing.JButton();
        JBT3 = new javax.swing.JButton();
        JBT4 = new javax.swing.JButton();
        JBT45 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        JBT5 = new javax.swing.JButton();
        JBT6 = new javax.swing.JButton();
        JBT7 = new javax.swing.JButton();
        JBT8 = new javax.swing.JButton();
        JBT44 = new javax.swing.JButton();
        JBT9 = new javax.swing.JButton();
        JBT10 = new javax.swing.JButton();
        JBT11 = new javax.swing.JButton();
        JBT12 = new javax.swing.JButton();
        JBT43 = new javax.swing.JButton();
        JBT13 = new javax.swing.JButton();
        JBT14 = new javax.swing.JButton();
        JBT15 = new javax.swing.JButton();
        JBT16 = new javax.swing.JButton();
        JBT42 = new javax.swing.JButton();
        JBT17 = new javax.swing.JButton();
        JBT18 = new javax.swing.JButton();
        JBT19 = new javax.swing.JButton();
        JBT20 = new javax.swing.JButton();
        JBT41 = new javax.swing.JButton();
        JBT21 = new javax.swing.JButton();
        JBT22 = new javax.swing.JButton();
        JBT23 = new javax.swing.JButton();
        JBT24 = new javax.swing.JButton();
        JBT40 = new javax.swing.JButton();
        JBT25 = new javax.swing.JButton();
        JBT26 = new javax.swing.JButton();
        JBT27 = new javax.swing.JButton();
        JBT28 = new javax.swing.JButton();
        JBT39 = new javax.swing.JButton();
        JBT29 = new javax.swing.JButton();
        JBT30 = new javax.swing.JButton();
        JBT31 = new javax.swing.JButton();
        JBT32 = new javax.swing.JButton();
        JBT38 = new javax.swing.JButton();
        JBT33 = new javax.swing.JButton();
        JBT34 = new javax.swing.JButton();
        JBT35 = new javax.swing.JButton();
        JBT36 = new javax.swing.JButton();
        JBT37 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/mesa.png"))); // NOI18N
        jLabel1.setText("MESAS   01 - 45");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 10, -1, 20));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 250, 50, 10));
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 520, -1, -1));

        JBT1.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT1.setText("MESA 01");
        JBT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT1ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 190, 60));

        JBT2.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT2.setText("MESA 02");
        JBT2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT2ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 220, 60));

        JBT3.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT3.setText("MESA 03");
        JBT3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT3ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 50, 220, 60));

        JBT4.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT4.setText("MESA 04");
        JBT4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT4ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 50, 210, 60));

        JBT45.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT45.setText("MESA 05");
        JBT45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT45ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT45, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 50, 190, 60));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 90, 20, 10));

        JBT5.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT5.setText("MESA 06");
        JBT5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT5ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 190, 60));

        JBT6.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT6.setText("MESA 07");
        JBT6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT6ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 220, 60));

        JBT7.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT7.setText("MESA 08");
        JBT7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT7ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT7, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 120, 220, 60));

        JBT8.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT8.setText("MESA 09");
        JBT8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT8ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT8, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 120, 210, 60));

        JBT44.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT44.setText("MESA 10");
        JBT44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT44ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT44, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 120, 190, 60));

        JBT9.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT9.setText("MESA 11");
        JBT9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT9ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 190, 60));

        JBT10.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT10.setText("MESA 12");
        JBT10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT10ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT10, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 220, 60));

        JBT11.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT11.setText("MESA 13");
        JBT11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT11ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT11, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 190, 220, 60));

        JBT12.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT12.setText("MESA 14");
        JBT12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT12ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT12, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 190, 210, 60));

        JBT43.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT43.setText("MESA 15");
        JBT43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT43ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT43, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 190, 190, 60));

        JBT13.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT13.setText("MESA 16");
        JBT13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT13ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 190, 60));

        JBT14.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT14.setText("MESA 17");
        JBT14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT14ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT14, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, 220, 60));

        JBT15.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT15.setText("MESA 18");
        JBT15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT15ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT15, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 260, 220, 60));

        JBT16.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT16.setText("MESA 19");
        JBT16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT16ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT16, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 260, 210, 60));

        JBT42.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT42.setText("MESA 20");
        JBT42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT42ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT42, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 260, 190, 60));

        JBT17.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT17.setText("MESA 21");
        JBT17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT17ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 190, 60));

        JBT18.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT18.setText("MESA 22");
        JBT18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT18ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT18, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 330, 220, 60));

        JBT19.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT19.setText("MESA 23");
        JBT19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT19ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT19, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 330, 220, 60));

        JBT20.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT20.setText("MESA 24");
        JBT20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT20ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT20, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 330, 210, 60));

        JBT41.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT41.setText("MESA 25");
        JBT41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT41ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT41, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 330, 190, 60));

        JBT21.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT21.setText("MESA 26");
        JBT21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT21ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 190, 60));

        JBT22.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT22.setText("MESA 27");
        JBT22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT22ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT22, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 400, 220, 60));

        JBT23.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT23.setText("MESA 28");
        JBT23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT23ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT23, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 400, 220, 60));

        JBT24.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT24.setText("MESA 29");
        JBT24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT24ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT24, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 400, 210, 60));

        JBT40.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT40.setText("MESA 30");
        JBT40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT40ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT40, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 400, 190, 60));

        JBT25.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT25.setText("MESA 31");
        JBT25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT25ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, 190, 60));

        JBT26.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT26.setText("MESA 32");
        JBT26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT26ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT26, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 470, 220, 60));

        JBT27.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT27.setText("MESA 33");
        JBT27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT27ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT27, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 470, 220, 60));

        JBT28.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT28.setText("MESA 34");
        JBT28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT28ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT28, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 470, 210, 60));

        JBT39.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT39.setText("MESA 35");
        JBT39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT39ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT39, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 470, 190, 60));

        JBT29.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT29.setText("MESA 36");
        JBT29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT29ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 540, 190, 60));

        JBT30.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT30.setText("MESA 37");
        JBT30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT30ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT30, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 540, 220, 60));

        JBT31.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT31.setText("MESA 38");
        JBT31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT31ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT31, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 540, 220, 60));

        JBT32.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT32.setText("MESA 39");
        JBT32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT32ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT32, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 540, 210, 60));

        JBT38.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT38.setText("MESA 40");
        JBT38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT38ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT38, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 540, 190, 60));

        JBT33.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT33.setText("MESA 41");
        JBT33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT33ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, 190, 60));

        JBT34.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT34.setText("MESA 42");
        JBT34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT34ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT34, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 610, 220, 60));

        JBT35.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT35.setText("MESA 43");
        JBT35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT35ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT35, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 610, 220, 60));

        JBT36.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT36.setText("MESA 44");
        JBT36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT36ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT36, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 610, 210, 60));

        JBT37.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT37.setText("MESA 45");
        JBT37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT37ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT37, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 610, 190, 60));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 690, -1, -1));
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 690, 80, 40));

        jButton3.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton3.setText("Sair");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 0, 150, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void JBT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT1ActionPerformed
        abreMesa(1);
    }//GEN-LAST:event_JBT1ActionPerformed

    private void JBT2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT2ActionPerformed
        abreMesa(2);
    }//GEN-LAST:event_JBT2ActionPerformed

    private void JBT3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT3ActionPerformed
        abreMesa(3);
    }//GEN-LAST:event_JBT3ActionPerformed

    private void JBT4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT4ActionPerformed
        abreMesa(4);
    }//GEN-LAST:event_JBT4ActionPerformed

    private void JBT45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT45ActionPerformed
        abreMesa(5);
    }//GEN-LAST:event_JBT45ActionPerformed

    private void JBT5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT5ActionPerformed
        abreMesa(6);
    }//GEN-LAST:event_JBT5ActionPerformed

    private void JBT6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT6ActionPerformed
        abreMesa(7);
    }//GEN-LAST:event_JBT6ActionPerformed

    private void JBT7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT7ActionPerformed
        abreMesa(8);
    }//GEN-LAST:event_JBT7ActionPerformed

    private void JBT8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT8ActionPerformed
       abreMesa(9);
    }//GEN-LAST:event_JBT8ActionPerformed

    private void JBT44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT44ActionPerformed
        abreMesa(10);
    }//GEN-LAST:event_JBT44ActionPerformed

    private void JBT9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT9ActionPerformed
        abreMesa(11);
    }//GEN-LAST:event_JBT9ActionPerformed

    private void JBT10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT10ActionPerformed
        abreMesa(12);
    }//GEN-LAST:event_JBT10ActionPerformed

    private void JBT11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT11ActionPerformed
        abreMesa(13);
    }//GEN-LAST:event_JBT11ActionPerformed

    private void JBT12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT12ActionPerformed
        abreMesa(14);
    }//GEN-LAST:event_JBT12ActionPerformed

    private void JBT43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT43ActionPerformed
        abreMesa(15);
    }//GEN-LAST:event_JBT43ActionPerformed

    private void JBT13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT13ActionPerformed
        abreMesa(16);
    }//GEN-LAST:event_JBT13ActionPerformed

    private void JBT14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT14ActionPerformed
        abreMesa(17);
    }//GEN-LAST:event_JBT14ActionPerformed

    private void JBT15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT15ActionPerformed
        abreMesa(18);
    }//GEN-LAST:event_JBT15ActionPerformed

    private void JBT16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT16ActionPerformed
        abreMesa(19);
    }//GEN-LAST:event_JBT16ActionPerformed

    private void JBT42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT42ActionPerformed
        abreMesa(20);
    }//GEN-LAST:event_JBT42ActionPerformed

    private void JBT17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT17ActionPerformed
        abreMesa(21);
    }//GEN-LAST:event_JBT17ActionPerformed

    private void JBT18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT18ActionPerformed
        abreMesa(22);
    }//GEN-LAST:event_JBT18ActionPerformed

    private void JBT19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT19ActionPerformed
        abreMesa(23);
    }//GEN-LAST:event_JBT19ActionPerformed

    private void JBT20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT20ActionPerformed
        abreMesa(24);
    }//GEN-LAST:event_JBT20ActionPerformed

    private void JBT41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT41ActionPerformed
        abreMesa(25);
    }//GEN-LAST:event_JBT41ActionPerformed

    private void JBT21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT21ActionPerformed
        abreMesa(26);
    }//GEN-LAST:event_JBT21ActionPerformed

    private void JBT22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT22ActionPerformed
        abreMesa(27);
    }//GEN-LAST:event_JBT22ActionPerformed

    private void JBT23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT23ActionPerformed
        abreMesa(28);
    }//GEN-LAST:event_JBT23ActionPerformed

    private void JBT24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT24ActionPerformed
        abreMesa(29);
    }//GEN-LAST:event_JBT24ActionPerformed

    private void JBT40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT40ActionPerformed
        abreMesa(30);
    }//GEN-LAST:event_JBT40ActionPerformed

    private void JBT25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT25ActionPerformed
       abreMesa(31);
    }//GEN-LAST:event_JBT25ActionPerformed

    private void JBT26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT26ActionPerformed
        abreMesa(32);
    }//GEN-LAST:event_JBT26ActionPerformed

    private void JBT27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT27ActionPerformed
        abreMesa(33);
    }//GEN-LAST:event_JBT27ActionPerformed

    private void JBT28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT28ActionPerformed
        abreMesa(34);
    }//GEN-LAST:event_JBT28ActionPerformed

    private void JBT39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT39ActionPerformed
        abreMesa(35);
    }//GEN-LAST:event_JBT39ActionPerformed

    private void JBT29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT29ActionPerformed
       abreMesa(36);
    }//GEN-LAST:event_JBT29ActionPerformed

    private void JBT30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT30ActionPerformed
        abreMesa(37);
    }//GEN-LAST:event_JBT30ActionPerformed

    private void JBT31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT31ActionPerformed
        abreMesa(38);
    }//GEN-LAST:event_JBT31ActionPerformed

    private void JBT32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT32ActionPerformed
        abreMesa(39);
    }//GEN-LAST:event_JBT32ActionPerformed

    private void JBT38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT38ActionPerformed
        abreMesa(40);
    }//GEN-LAST:event_JBT38ActionPerformed

    private void JBT33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT33ActionPerformed
        abreMesa(41);
    }//GEN-LAST:event_JBT33ActionPerformed

    private void JBT34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT34ActionPerformed
        abreMesa(42);
    }//GEN-LAST:event_JBT34ActionPerformed

    private void JBT35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT35ActionPerformed
        abreMesa(43);
    }//GEN-LAST:event_JBT35ActionPerformed

    private void JBT36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT36ActionPerformed
        abreMesa(44);
    }//GEN-LAST:event_JBT36ActionPerformed

    private void JBT37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT37ActionPerformed
        abreMesa(45);
    }//GEN-LAST:event_JBT37ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Mesas().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Mesas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBT1;
    private javax.swing.JButton JBT10;
    private javax.swing.JButton JBT11;
    private javax.swing.JButton JBT12;
    private javax.swing.JButton JBT13;
    private javax.swing.JButton JBT14;
    private javax.swing.JButton JBT15;
    private javax.swing.JButton JBT16;
    private javax.swing.JButton JBT17;
    private javax.swing.JButton JBT18;
    private javax.swing.JButton JBT19;
    private javax.swing.JButton JBT2;
    private javax.swing.JButton JBT20;
    private javax.swing.JButton JBT21;
    private javax.swing.JButton JBT22;
    private javax.swing.JButton JBT23;
    private javax.swing.JButton JBT24;
    private javax.swing.JButton JBT25;
    private javax.swing.JButton JBT26;
    private javax.swing.JButton JBT27;
    private javax.swing.JButton JBT28;
    private javax.swing.JButton JBT29;
    private javax.swing.JButton JBT3;
    private javax.swing.JButton JBT30;
    private javax.swing.JButton JBT31;
    private javax.swing.JButton JBT32;
    private javax.swing.JButton JBT33;
    private javax.swing.JButton JBT34;
    private javax.swing.JButton JBT35;
    private javax.swing.JButton JBT36;
    private javax.swing.JButton JBT37;
    private javax.swing.JButton JBT38;
    private javax.swing.JButton JBT39;
    private javax.swing.JButton JBT4;
    private javax.swing.JButton JBT40;
    private javax.swing.JButton JBT41;
    private javax.swing.JButton JBT42;
    private javax.swing.JButton JBT43;
    private javax.swing.JButton JBT44;
    private javax.swing.JButton JBT45;
    private javax.swing.JButton JBT5;
    private javax.swing.JButton JBT6;
    private javax.swing.JButton JBT7;
    private javax.swing.JButton JBT8;
    private javax.swing.JButton JBT9;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
