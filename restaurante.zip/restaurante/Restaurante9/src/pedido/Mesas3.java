package pedido;

import java.awt.Color;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mesas3 extends javax.swing.JFrame {

    public Mesas3() throws SQLException {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        JBT1.setBackground(Color.GREEN);
        JBT2.setBackground(Color.GREEN);
        JBT3.setBackground(Color.GREEN);
        JBT4.setBackground(Color.GREEN);
        JBT5.setBackground(Color.GREEN);
        JBT6.setBackground(Color.GREEN);
        JBT7.setBackground(Color.GREEN);
        JBT8.setBackground(Color.GREEN);
        JBT9.setBackground(Color.GREEN);
        JBT10.setBackground(Color.GREEN);
        alteraCor();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        JBT1 = new javax.swing.JButton();
        JBT2 = new javax.swing.JButton();
        JBT3 = new javax.swing.JButton();
        JBT5 = new javax.swing.JButton();
        JBT6 = new javax.swing.JButton();
        JBT7 = new javax.swing.JButton();
        JBT4 = new javax.swing.JButton();
        JBT8 = new javax.swing.JButton();
        JBT9 = new javax.swing.JButton();
        JBT10 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/mesa.png"))); // NOI18N
        jLabel1.setText("MESAS  91 - 100");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, -1, 20));

        JBT1.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT1.setText("MESA 91");
        JBT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT1ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 190, 60));

        JBT2.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT2.setText("MESA 92");
        JBT2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT2ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 60, 220, 60));

        JBT3.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT3.setText("MESA 93");
        JBT3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT3ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 60, 220, 60));

        JBT5.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT5.setText("MESA 96");
        JBT5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT5ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 190, 60));

        JBT6.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT6.setText("MESA 97");
        JBT6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT6ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 220, 60));

        JBT7.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT7.setText("MESA 98");
        JBT7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT7ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT7, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 130, 220, 60));

        JBT4.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT4.setText("MESA 94");
        JBT4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT4ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT4, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 60, 210, 60));

        JBT8.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT8.setText("MESA 99");
        JBT8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT8ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT8, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 130, 210, 60));

        JBT9.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT9.setText("MESA 95");
        JBT9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT9ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT9, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 60, 190, 60));

        JBT10.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT10.setText("MESA 100");
        JBT10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT10ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT10, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 130, 190, 60));

        jButton3.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton3.setText("Sair");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 10, 140, 40));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 90, 10, 10));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, 100, 40));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1129, 80, 50, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void alteraCor() throws SQLException{
        PedidoDaoInterface pedidosController = new PedidosController();
        if (pedidosController.pedidosMesaExiste(91) == true) {
            JBT1.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(92) == true) {
            JBT2.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(93) == true) {
            JBT3.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(94) == true) {
            JBT4.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(95) == true) {
            JBT9.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(96) == true) {
            JBT5.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(97) == true) {
            JBT6.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(98) == true) {
            JBT7.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(99) == true) {
            JBT8.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(100) == true) {
            JBT10.setBackground(Color.red);
        }
    }
    public void abreMesa(int num){
        PedidosMesa pmesa = new PedidosMesa(String.valueOf(num), 3);
        pmesa.setVisible(true);
        this.dispose();
    }
    private void JBT3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT3ActionPerformed
        abreMesa(93);
    }//GEN-LAST:event_JBT3ActionPerformed

    private void JBT6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT6ActionPerformed
        abreMesa(97);
    }//GEN-LAST:event_JBT6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void JBT4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT4ActionPerformed
        abreMesa(94);
    }//GEN-LAST:event_JBT4ActionPerformed

    private void JBT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT1ActionPerformed
        abreMesa(91);
    }//GEN-LAST:event_JBT1ActionPerformed

    private void JBT2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT2ActionPerformed
        abreMesa(92);
    }//GEN-LAST:event_JBT2ActionPerformed

    private void JBT9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT9ActionPerformed
        abreMesa(95);
    }//GEN-LAST:event_JBT9ActionPerformed

    private void JBT5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT5ActionPerformed
        abreMesa(96);
    }//GEN-LAST:event_JBT5ActionPerformed

    private void JBT7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT7ActionPerformed
        abreMesa(98);
    }//GEN-LAST:event_JBT7ActionPerformed

    private void JBT8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT8ActionPerformed
        abreMesa(99);
    }//GEN-LAST:event_JBT8ActionPerformed

    private void JBT10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT10ActionPerformed
        abreMesa(100);
    }//GEN-LAST:event_JBT10ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mesas3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mesas3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mesas3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mesas3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Mesas3().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Mesas3.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBT1;
    private javax.swing.JButton JBT10;
    private javax.swing.JButton JBT2;
    private javax.swing.JButton JBT3;
    private javax.swing.JButton JBT4;
    private javax.swing.JButton JBT5;
    private javax.swing.JButton JBT6;
    private javax.swing.JButton JBT7;
    private javax.swing.JButton JBT8;
    private javax.swing.JButton JBT9;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
