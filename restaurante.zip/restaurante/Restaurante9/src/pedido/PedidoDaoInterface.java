package pedido;

import java.util.Collection;
import java.util.List;

public interface PedidoDaoInterface {
    void cadastrar(Pedido pedido, List<Pedido> pedidoProduto);
    void editar(Pedido pedido, List<Pedido> pedidoProduto);
    void deletar(int id);
    void deletarItemPedido(int id);
    void desativar(int id, List<Pedido> pedidoProduto, float valorTotal);
    Collection<?> pedidos();
    Collection<?> pedidosGarcom(int garcomId);
    Collection<?> pedidosMesa(int numeroMesa);
    Boolean pedidosMesaExiste(int numeroMesa);
    Collection<?> pedidoProduto(int pedidoId);
    Collection<Pedido> pedidoProdutoRelatorio(int pedidoId);
    float calculaValor(int pedidoId);
    int quantidadeProdutoItemProduto(int produtoId);
    
}
