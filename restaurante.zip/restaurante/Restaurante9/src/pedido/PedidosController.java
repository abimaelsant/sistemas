package pedido;

import conexaoDao.Conexao;
import conexaoDao.ConexaoBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

public class PedidosController implements PedidoDaoInterface{
    PedidoDaoInterface pedidoDao;
    Conexao conexao;
    Connection driver;
    
    public PedidosController() throws SQLException{
        this.conexao = new ConexaoBD();
        driver =  DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurante", "root", "123");
        this.pedidoDao = new PedidoDao(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void cadastrar(Pedido pedido, List<Pedido> pedidoProduto){
        this.pedidoDao.cadastrar(pedido, pedidoProduto);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public void editar(Pedido pedido, List<Pedido> pedidoProduto){
        this.pedidoDao.editar(pedido, pedidoProduto);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public void deletar(int id){
        this.pedidoDao.deletar(id);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public void deletarItemPedido(int id) {
        this.pedidoDao.deletarItemPedido(id);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public void desativar(int id, List<Pedido> pedidoProduto, float valorTotal){
        this.pedidoDao.desativar(id, pedidoProduto, valorTotal);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public Collection<Pedido> pedidos(){
        return (Collection<Pedido>) this.pedidoDao.pedidos();
    }
    @Override
    public Collection<Pedido> pedidosGarcom(int garcomId){
        return (Collection<Pedido>) this.pedidoDao.pedidosGarcom(garcomId);
    }
    @Override
    public Collection<Pedido> pedidoProduto(int pedido_id){
        return (Collection<Pedido>) this.pedidoDao.pedidoProduto(pedido_id);
    }
    @Override
    public Collection<Pedido> pedidoProdutoRelatorio(int pedidoId){
        return this.pedidoDao.pedidoProdutoRelatorio(pedidoId);
    }
    @Override
    public Collection<Pedido> pedidosMesa(int numeroMesa){
        return (Collection<Pedido>) this.pedidoDao.pedidosMesa(numeroMesa);
    }
    
    @Override
    public Boolean pedidosMesaExiste(int numeroMesa){
        return this.pedidoDao.pedidosMesaExiste(numeroMesa);
    }
    
    @Override
    public float calculaValor(int pedidoId){
        return this.pedidoDao.calculaValor(pedidoId);
    }
    
    @Override
     public int quantidadeProdutoItemProduto(int produtoId){
         return this.pedidoDao.quantidadeProdutoItemProduto(produtoId);
     }
}
