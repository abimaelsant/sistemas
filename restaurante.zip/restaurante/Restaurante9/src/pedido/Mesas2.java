package pedido;

import java.awt.Color;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mesas2 extends javax.swing.JFrame {

    public Mesas2() throws SQLException {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        jLabel1.setFocusable(true);
        JBT1.setBackground(Color.GREEN);
        JBT2.setBackground(Color.GREEN);
        JBT3.setBackground(Color.GREEN);
        JBT4.setBackground(Color.GREEN);
        JBT5.setBackground(Color.GREEN);
        JBT6.setBackground(Color.GREEN);
        JBT7.setBackground(Color.GREEN);
        JBT7.setBackground(Color.GREEN);
        JBT8.setBackground(Color.GREEN);
        JBT9.setBackground(Color.GREEN);
        JBT10.setBackground(Color.GREEN);
        JBT11.setBackground(Color.GREEN);
        JBT12.setBackground(Color.GREEN);
        JBT13.setBackground(Color.GREEN);
        JBT14.setBackground(Color.GREEN);
        JBT15.setBackground(Color.GREEN);
        JBT16.setBackground(Color.GREEN);
        JBT17.setBackground(Color.GREEN);
        JBT18.setBackground(Color.GREEN);
        JBT19.setBackground(Color.GREEN);
        JBT20.setBackground(Color.GREEN);
        JBT21.setBackground(Color.GREEN);
        JBT22.setBackground(Color.GREEN);
        JBT23.setBackground(Color.GREEN);
        JBT24.setBackground(Color.GREEN);
        JBT25.setBackground(Color.GREEN);
        JBT26.setBackground(Color.GREEN);
        JBT27.setBackground(Color.GREEN);
        JBT28.setBackground(Color.GREEN);
        JBT29.setBackground(Color.GREEN);
        JBT30.setBackground(Color.GREEN);
        JBT31.setBackground(Color.GREEN);
        JBT32.setBackground(Color.GREEN);
        JBT33.setBackground(Color.GREEN);
        JBT34.setBackground(Color.GREEN);
        JBT35.setBackground(Color.GREEN);
        JBT36.setBackground(Color.GREEN);
        JBT37.setBackground(Color.GREEN);
        JBT38.setBackground(Color.GREEN);
        JBT39.setBackground(Color.GREEN);
        JBT40.setBackground(Color.GREEN);
        JBT41.setBackground(Color.GREEN);
        JBT42.setBackground(Color.GREEN);
        JBT43.setBackground(Color.GREEN);
        JBT44.setBackground(Color.GREEN);
        JBT45.setBackground(Color.GREEN);
        alteraCor();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        JBT1 = new javax.swing.JButton();
        JBT5 = new javax.swing.JButton();
        JBT9 = new javax.swing.JButton();
        JBT13 = new javax.swing.JButton();
        JBT2 = new javax.swing.JButton();
        JBT3 = new javax.swing.JButton();
        JBT6 = new javax.swing.JButton();
        JBT10 = new javax.swing.JButton();
        JBT14 = new javax.swing.JButton();
        JBT15 = new javax.swing.JButton();
        JBT11 = new javax.swing.JButton();
        JBT7 = new javax.swing.JButton();
        JBT4 = new javax.swing.JButton();
        JBT8 = new javax.swing.JButton();
        JBT12 = new javax.swing.JButton();
        JBT16 = new javax.swing.JButton();
        JBT42 = new javax.swing.JButton();
        JBT43 = new javax.swing.JButton();
        JBT44 = new javax.swing.JButton();
        JBT45 = new javax.swing.JButton();
        JBT41 = new javax.swing.JButton();
        JBT40 = new javax.swing.JButton();
        JBT39 = new javax.swing.JButton();
        JBT38 = new javax.swing.JButton();
        JBT37 = new javax.swing.JButton();
        JBT36 = new javax.swing.JButton();
        JBT32 = new javax.swing.JButton();
        JBT28 = new javax.swing.JButton();
        JBT24 = new javax.swing.JButton();
        JBT20 = new javax.swing.JButton();
        JBT19 = new javax.swing.JButton();
        JBT23 = new javax.swing.JButton();
        JBT27 = new javax.swing.JButton();
        JBT31 = new javax.swing.JButton();
        JBT35 = new javax.swing.JButton();
        JBT34 = new javax.swing.JButton();
        JBT33 = new javax.swing.JButton();
        JBT30 = new javax.swing.JButton();
        JBT29 = new javax.swing.JButton();
        JBT26 = new javax.swing.JButton();
        JBT25 = new javax.swing.JButton();
        JBT22 = new javax.swing.JButton();
        JBT21 = new javax.swing.JButton();
        JBT17 = new javax.swing.JButton();
        JBT18 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/mesa.png"))); // NOI18N
        jLabel1.setText("MESAS   46 - 90");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, -1, 20));

        JBT1.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT1.setText("MESA 46");
        JBT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT1ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 190, 60));

        JBT5.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT5.setText("MESA 51");
        JBT5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT5ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 190, 60));

        JBT9.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT9.setText("MESA 56");
        JBT9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT9ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 190, 60));

        JBT13.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT13.setText("MESA 61");
        JBT13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT13ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 190, 60));

        JBT2.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT2.setText("MESA 47");
        JBT2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT2ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 60, 220, 60));

        JBT3.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT3.setText("MESA 48");
        JBT3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT3ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT3, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 60, 220, 60));

        JBT6.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT6.setText("MESA 52");
        JBT6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT6ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 220, 60));

        JBT10.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT10.setText("MESA 57");
        JBT10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT10ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT10, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 200, 220, 60));

        JBT14.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT14.setText("MESA 62");
        JBT14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT14ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT14, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 220, 60));

        JBT15.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT15.setText("MESA 63");
        JBT15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT15ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT15, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 270, 220, 60));

        JBT11.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT11.setText("MESA 58");
        JBT11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT11ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT11, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 200, 220, 60));

        JBT7.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT7.setText("MESA 53");
        JBT7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT7ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT7, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 130, 220, 60));

        JBT4.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT4.setText("MESA 49");
        JBT4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT4ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT4, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 60, 210, 60));

        JBT8.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT8.setText("MESA 54");
        JBT8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT8ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT8, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 130, 210, 60));

        JBT12.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT12.setText("MESA 59");
        JBT12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT12ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT12, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 200, 210, 60));

        JBT16.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT16.setText("MESA 64");
        JBT16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT16ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT16, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 270, 210, 60));

        JBT42.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT42.setText("MESA 65");
        JBT42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT42ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT42, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 270, 190, 60));

        JBT43.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT43.setText("MESA 60");
        JBT43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT43ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT43, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 200, 190, 60));

        JBT44.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT44.setText("MESA 55");
        JBT44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT44ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT44, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 130, 190, 60));

        JBT45.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT45.setText("MESA 50");
        JBT45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT45ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT45, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 60, 190, 60));

        JBT41.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT41.setText("MESA 70");
        JBT41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT41ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT41, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 340, 190, 60));

        JBT40.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT40.setText("MESA 75");
        JBT40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT40ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT40, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 410, 190, 60));

        JBT39.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT39.setText("MESA 80");
        JBT39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT39ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT39, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 480, 190, 60));

        JBT38.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT38.setText("MESA 85");
        JBT38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT38ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT38, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 550, 190, 60));

        JBT37.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT37.setText("MESA 90");
        JBT37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT37ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT37, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 620, 190, 60));

        JBT36.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT36.setText("MESA 89");
        JBT36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT36ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT36, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 620, 210, 60));

        JBT32.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT32.setText("MESA 84");
        JBT32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT32ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT32, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 550, 210, 60));

        JBT28.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT28.setText("MESA 79");
        JBT28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT28ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT28, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 480, 210, 60));

        JBT24.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT24.setText("MESA 74");
        JBT24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT24ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT24, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 410, 210, 60));

        JBT20.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT20.setText("MESA 69");
        JBT20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT20ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT20, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 340, 210, 60));

        JBT19.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT19.setText("MESA 68");
        JBT19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT19ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT19, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 340, 220, 60));

        JBT23.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT23.setText("MESA 73");
        JBT23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT23ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT23, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 410, 220, 60));

        JBT27.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT27.setText("MESA 78");
        JBT27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT27ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT27, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 480, 220, 60));

        JBT31.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT31.setText("MESA 83");
        JBT31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT31ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT31, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 550, 220, 60));

        JBT35.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT35.setText("MESA 88");
        JBT35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT35ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT35, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 620, 220, 60));

        JBT34.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT34.setText("MESA 87");
        JBT34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT34ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT34, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 620, 220, 60));

        JBT33.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT33.setText("MESA 86");
        JBT33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT33ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 620, 190, 60));

        JBT30.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT30.setText("MESA 82");
        JBT30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT30ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT30, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 550, 220, 60));

        JBT29.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT29.setText("MESA 81");
        JBT29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT29ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, 190, 60));

        JBT26.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT26.setText("MESA 77");
        JBT26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT26ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT26, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 480, 220, 60));

        JBT25.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT25.setText("MESA 76");
        JBT25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT25ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, 190, 60));

        JBT22.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT22.setText("MESA 72");
        JBT22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT22ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT22, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 410, 220, 60));

        JBT21.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT21.setText("MESA 71");
        JBT21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT21ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 190, 60));

        JBT17.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT17.setText("MESA 66");
        JBT17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT17ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 190, 60));

        JBT18.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        JBT18.setText("MESA 67");
        JBT18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBT18ActionPerformed(evt);
            }
        });
        getContentPane().add(JBT18, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 340, 220, 60));

        jButton3.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton3.setText("Sair");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 10, 140, 40));
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 690, 90, 40));
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 100, 40, 10));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JBT3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT3ActionPerformed
        abreMesa(48);
    }//GEN-LAST:event_JBT3ActionPerformed

    private void JBT6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT6ActionPerformed
        abreMesa(52);
    }//GEN-LAST:event_JBT6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void JBT41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT41ActionPerformed
        abreMesa(70);
    }//GEN-LAST:event_JBT41ActionPerformed

    private void JBT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT1ActionPerformed
        abreMesa(46);
    }//GEN-LAST:event_JBT1ActionPerformed

    private void JBT2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT2ActionPerformed
        abreMesa(47);
    }//GEN-LAST:event_JBT2ActionPerformed

    private void JBT4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT4ActionPerformed
        abreMesa(49);
    }//GEN-LAST:event_JBT4ActionPerformed

    private void JBT45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT45ActionPerformed
        abreMesa(50);
    }//GEN-LAST:event_JBT45ActionPerformed

    private void JBT5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT5ActionPerformed
        abreMesa(51);
    }//GEN-LAST:event_JBT5ActionPerformed

    private void JBT7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT7ActionPerformed
        abreMesa(53);
    }//GEN-LAST:event_JBT7ActionPerformed

    private void JBT8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT8ActionPerformed
        abreMesa(54);
    }//GEN-LAST:event_JBT8ActionPerformed

    private void JBT44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT44ActionPerformed
        abreMesa(55);
    }//GEN-LAST:event_JBT44ActionPerformed

    private void JBT9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT9ActionPerformed
        abreMesa(56);
    }//GEN-LAST:event_JBT9ActionPerformed

    private void JBT10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT10ActionPerformed
        abreMesa(57);
    }//GEN-LAST:event_JBT10ActionPerformed

    private void JBT11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT11ActionPerformed
        abreMesa(58);
    }//GEN-LAST:event_JBT11ActionPerformed

    private void JBT12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT12ActionPerformed
        abreMesa(59);
    }//GEN-LAST:event_JBT12ActionPerformed

    private void JBT43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT43ActionPerformed
        abreMesa(60);
    }//GEN-LAST:event_JBT43ActionPerformed

    private void JBT13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT13ActionPerformed
        abreMesa(61);
    }//GEN-LAST:event_JBT13ActionPerformed

    private void JBT14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT14ActionPerformed
        abreMesa(62);
    }//GEN-LAST:event_JBT14ActionPerformed

    private void JBT15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT15ActionPerformed
        abreMesa(63);
    }//GEN-LAST:event_JBT15ActionPerformed

    private void JBT16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT16ActionPerformed
        abreMesa(64);
    }//GEN-LAST:event_JBT16ActionPerformed

    private void JBT42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT42ActionPerformed
        abreMesa(65);
    }//GEN-LAST:event_JBT42ActionPerformed

    private void JBT17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT17ActionPerformed
        abreMesa(66);
    }//GEN-LAST:event_JBT17ActionPerformed

    private void JBT18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT18ActionPerformed
        abreMesa(67);
    }//GEN-LAST:event_JBT18ActionPerformed

    private void JBT19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT19ActionPerformed
        abreMesa(68);
    }//GEN-LAST:event_JBT19ActionPerformed

    private void JBT20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT20ActionPerformed
        abreMesa(69);
    }//GEN-LAST:event_JBT20ActionPerformed

    private void JBT21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT21ActionPerformed
        abreMesa(71);
    }//GEN-LAST:event_JBT21ActionPerformed

    private void JBT22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT22ActionPerformed
        abreMesa(72);
    }//GEN-LAST:event_JBT22ActionPerformed

    private void JBT23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT23ActionPerformed
        abreMesa(73);
    }//GEN-LAST:event_JBT23ActionPerformed

    private void JBT24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT24ActionPerformed
        abreMesa(74);
    }//GEN-LAST:event_JBT24ActionPerformed

    private void JBT40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT40ActionPerformed
        abreMesa(75);
    }//GEN-LAST:event_JBT40ActionPerformed

    private void JBT25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT25ActionPerformed
        abreMesa(76);
    }//GEN-LAST:event_JBT25ActionPerformed

    private void JBT26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT26ActionPerformed
        abreMesa(77);
    }//GEN-LAST:event_JBT26ActionPerformed

    private void JBT27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT27ActionPerformed
        abreMesa(78);
    }//GEN-LAST:event_JBT27ActionPerformed

    private void JBT28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT28ActionPerformed
        abreMesa(79);
    }//GEN-LAST:event_JBT28ActionPerformed

    private void JBT39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT39ActionPerformed
        abreMesa(80);
    }//GEN-LAST:event_JBT39ActionPerformed

    private void JBT29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT29ActionPerformed
        abreMesa(81);
    }//GEN-LAST:event_JBT29ActionPerformed

    private void JBT30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT30ActionPerformed
        abreMesa(82);
    }//GEN-LAST:event_JBT30ActionPerformed

    private void JBT31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT31ActionPerformed
        abreMesa(83);
    }//GEN-LAST:event_JBT31ActionPerformed

    private void JBT32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT32ActionPerformed
        abreMesa(84);
    }//GEN-LAST:event_JBT32ActionPerformed

    private void JBT38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT38ActionPerformed
        abreMesa(85);
    }//GEN-LAST:event_JBT38ActionPerformed

    private void JBT33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT33ActionPerformed
        abreMesa(86);
    }//GEN-LAST:event_JBT33ActionPerformed

    private void JBT34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT34ActionPerformed
        abreMesa(87);
    }//GEN-LAST:event_JBT34ActionPerformed

    private void JBT35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT35ActionPerformed
        abreMesa(88);
    }//GEN-LAST:event_JBT35ActionPerformed

    private void JBT36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT36ActionPerformed
        abreMesa(89);
    }//GEN-LAST:event_JBT36ActionPerformed

    private void JBT37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBT37ActionPerformed
        abreMesa(90);
    }//GEN-LAST:event_JBT37ActionPerformed
    public void abreMesa(int num){
        PedidosMesa pmesa = new PedidosMesa(String.valueOf(num), 2);
        pmesa.setVisible(true);
        this.dispose();
    }
    public final void alteraCor() throws SQLException{
        PedidoDaoInterface pedidosController = new PedidosController();
        if (pedidosController.pedidosMesaExiste(46) == true) {
            JBT1.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(47) == true) {
            JBT2.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(48) == true) {
            JBT3.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(49) == true) {
            JBT4.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(50) == true) {
            JBT45.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(51) == true) {
            JBT5.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(52) == true) {
            JBT6.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(53) == true) {
            JBT7.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(54) == true) {
            JBT8.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(55) == true) {
            JBT44.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(56) == true) {
            JBT9.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(57) == true) {
            JBT10.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(58) == true) {
            JBT11.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(59) == true) {
            JBT12.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(60) == true) {
            JBT43.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(61) == true) {
            JBT13.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(62) == true) {
            JBT14.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(63) == true) {
            JBT15.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(64) == true) {
            JBT16.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(65) == true) {
            JBT42.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(66) == true) {
            JBT17.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(67) == true) {
            JBT18.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(68) == true) {
            JBT19.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(69) == true) {
            JBT20.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(70) == true) {
            JBT41.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(71) == true) {
            JBT21.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(72) == true) {
            JBT22.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(73) == true) {
            JBT23.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(74) == true) {
            JBT24.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(75) == true) {
            JBT40.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(76) == true) {
            JBT25.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(77) == true) {
            JBT26.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(78) == true) {
            JBT27.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(79) == true) {
            JBT28.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(80) == true) {
            JBT39.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(81) == true) {
            JBT29.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(82) == true) {
            JBT30.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(83) == true) {
            JBT31.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(84) == true) {
            JBT32.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(85) == true) {
            JBT38.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(86) == true) {
            JBT33.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(87) == true) {
            JBT34.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(88) == true) {
            JBT35.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(89) == true) {
            JBT36.setBackground(Color.red);
        }
        if (pedidosController.pedidosMesaExiste(90) == true) {
            JBT37.setBackground(Color.red);
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mesas2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mesas2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mesas2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mesas2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Mesas2().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Mesas2.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBT1;
    private javax.swing.JButton JBT10;
    private javax.swing.JButton JBT11;
    private javax.swing.JButton JBT12;
    private javax.swing.JButton JBT13;
    private javax.swing.JButton JBT14;
    private javax.swing.JButton JBT15;
    private javax.swing.JButton JBT16;
    private javax.swing.JButton JBT17;
    private javax.swing.JButton JBT18;
    private javax.swing.JButton JBT19;
    private javax.swing.JButton JBT2;
    private javax.swing.JButton JBT20;
    private javax.swing.JButton JBT21;
    private javax.swing.JButton JBT22;
    private javax.swing.JButton JBT23;
    private javax.swing.JButton JBT24;
    private javax.swing.JButton JBT25;
    private javax.swing.JButton JBT26;
    private javax.swing.JButton JBT27;
    private javax.swing.JButton JBT28;
    private javax.swing.JButton JBT29;
    private javax.swing.JButton JBT3;
    private javax.swing.JButton JBT30;
    private javax.swing.JButton JBT31;
    private javax.swing.JButton JBT32;
    private javax.swing.JButton JBT33;
    private javax.swing.JButton JBT34;
    private javax.swing.JButton JBT35;
    private javax.swing.JButton JBT36;
    private javax.swing.JButton JBT37;
    private javax.swing.JButton JBT38;
    private javax.swing.JButton JBT39;
    private javax.swing.JButton JBT4;
    private javax.swing.JButton JBT40;
    private javax.swing.JButton JBT41;
    private javax.swing.JButton JBT42;
    private javax.swing.JButton JBT43;
    private javax.swing.JButton JBT44;
    private javax.swing.JButton JBT45;
    private javax.swing.JButton JBT5;
    private javax.swing.JButton JBT6;
    private javax.swing.JButton JBT7;
    private javax.swing.JButton JBT8;
    private javax.swing.JButton JBT9;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
