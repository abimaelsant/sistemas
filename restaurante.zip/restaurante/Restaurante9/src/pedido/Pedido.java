package pedido;

import java.sql.Timestamp;

public class Pedido {
    private int id;
    private int mesa;
    private int garcom_id;
    private float valorParcial;
    private float valorTotal;
    private int produtoId;
    private int quantidade;
    private boolean ativo;
    private  Timestamp data;
    
    public Pedido(){}
    
    public Pedido(int mesa, float valorParcial, float valorTotal, int produtoId, int quantidade){
        this.mesa = mesa;
        this.valorParcial = valorParcial;
        this.valorTotal = valorTotal;
        this.produtoId = produtoId;
        this.quantidade = quantidade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public int getGarcom_id() {
        return garcom_id;
    }

    public void setGarcom_id(int garcom_id) {
        this.garcom_id = garcom_id;
    }
    
    public float getValorParcial() {
        return valorParcial;
    }

    public void setValorParcial(float valorParcial) {
        this.valorParcial = valorParcial;
    }

    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public int getProdutoId() {
        return produtoId;
    }

    public void setProdutoId(int produtoId) {
        this.produtoId = produtoId;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public  Timestamp getData() {
        return data;
    }

    public void setData( Timestamp data) {
        this.data = data;
    }
}
