package funcionario;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class FuncionarioLista extends javax.swing.JFrame {

    public FuncionarioLista() throws SQLException {
        initComponents();
        dados.setRowHeight(20);
        setLocationRelativeTo( null );
        setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        
        FuncionarioDaoInterface funcionarioController = new FuncionariosController();
        
        List<Funcionario> funcionarios;

        DefaultTableModel table;
        table = (DefaultTableModel) dados.getModel();
        ((DefaultTableModel) dados.getModel()).setNumRows(0);
        dados.updateUI();

        funcionarios = (ArrayList<Funcionario>) funcionarioController.funcionarios();

        for (int i = 0; i < funcionarios.size(); i++) {
            table.addRow(new Object[]{funcionarios.get(i).getId(), funcionarios.get(i).getNome()});
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dados = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        jLabel1.setText("FUNCIONÁRIOS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, -1, -1));

        dados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código", "Nome"
            }
        ));
        dados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dados);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 700, 250));

        jButton1.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/cancelar.png"))); // NOI18N
        jButton1.setText("CANCELAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 334, 320, 60));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 407, 70, 20));

        jButton2.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ícon/atualizar.png"))); // NOI18N
        jButton2.setText("ATUALIZAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 30, 180, 50));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dadosMouseClicked
        if (evt.getClickCount() == 1) {
            Object id = (dados.getValueAt(dados.getSelectedRow(), 0));
            Object nome = (dados.getValueAt(dados.getSelectedRow(), 1));

            String Id = id.toString();
            String Nome = nome.toString();
            
            int codigo = Integer.parseInt(Id);

            FuncionarioEditar editar = new FuncionarioEditar(codigo, Nome);
            editar.setVisible(true);
        }
    }//GEN-LAST:event_dadosMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            FuncionarioDaoInterface funcionarioController = new FuncionariosController();
            
            List<Funcionario> funcionarios;
            
            DefaultTableModel table;
            table = (DefaultTableModel) dados.getModel();
            ((DefaultTableModel) dados.getModel()).setNumRows(0);
            dados.updateUI();
            
            funcionarios = (ArrayList<Funcionario>) funcionarioController.funcionarios();
            
            for (int i = 0; i < funcionarios.size(); i++) {
                table.addRow(new Object[]{funcionarios.get(i).getId(), funcionarios.get(i).getNome()});
            }
        } catch (SQLException ex) {
            Logger.getLogger(FuncionarioLista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new FuncionarioLista().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(FuncionarioLista.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable dados;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
