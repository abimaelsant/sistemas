package funcionario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.swing.JOptionPane;

public class FuncionarioDao implements FuncionarioDaoInterface{
    private final Connection conexao;
    
    public FuncionarioDao(Connection conexao){
        this.conexao = conexao;
    }
    
    @Override
    public void cadastrar(Funcionario funcionario) {
        String sql = "INSERT INTO funcionario(nome) VALUES(?)";

        try{
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setString(1, funcionario.getNome());
                stmt.execute();
                JOptionPane.showMessageDialog(null, "CADASTRO REALIZADO COM SUCESSO");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void editar(Funcionario funcionario) {
        String sql = "UPDATE funcionario set nome=? where id=?";
        
        try {

            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setString(1, funcionario.getNome());
                stmt.setInt(2, funcionario.getId());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "EDITADO COM SUCESSO!");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }
    
    @Override
    public void deletar(int id) {

        String sql = "DELETE FROM funcionario WHERE id=?";

        try {
            try (PreparedStatement stmt = (PreparedStatement) this.conexao.prepareStatement(sql)) {
                stmt.setInt(1, id);
                stmt.execute();
                JOptionPane.showMessageDialog(null, "DELETADO COM SUCESSO!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
    }

    @Override
    public Collection<Funcionario> funcionarios() {

        List<Funcionario> funcionarios = new ArrayList<>();

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select * from funcionario");
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                Funcionario funcionario = new Funcionario();
                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
                funcionarios.add(funcionario);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return (funcionarios);
    }
    
    public Funcionario funcionario(int id) {
        Funcionario funcionario = new Funcionario();
        try {

            PreparedStatement sql = this.conexao.prepareStatement("select * from funcionario where id=?");
            
            sql.setInt(1, id);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                funcionario.setId(rs.getInt("id"));
                funcionario.setNome(rs.getString("nome"));
            }

        } catch (SQLException e) {
            
        }
        return (funcionario);
    }
    
    
    @Override
    public String nomeFuncionario(int id) {

       String nome = "";

        try {

            PreparedStatement sql = this.conexao.prepareStatement("select * from funcionario where id=?");
            
            sql.setInt(1, id);
            
            ResultSet rs = sql.executeQuery();

            while (rs.next()) {
                nome = rs.getString("nome");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA! TENTE NOVAMENTE!");
        }
        return nome;
    }
}
