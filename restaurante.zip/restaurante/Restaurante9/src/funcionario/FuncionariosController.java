package funcionario;

import conexaoDao.Conexao;
import conexaoDao.ConexaoBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collection;

public class FuncionariosController implements FuncionarioDaoInterface{
    FuncionarioDaoInterface funcionarioDao;
    Conexao conexao;
    Connection driver;
    
    public FuncionariosController() throws SQLException{
        this.conexao = new ConexaoBD();
        driver =  DriverManager.getConnection("jdbc:mysql://localhost:3306/restaurante", "root", "123");
        this.funcionarioDao = new FuncionarioDao(this.conexao.conectaBD(driver));
    }
    
    @Override
    public void cadastrar(Funcionario funcionario){
        this.funcionarioDao.cadastrar(funcionario);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public void editar(Funcionario funcionario){
        this.funcionarioDao.editar(funcionario);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public void deletar(int id){
        this.funcionarioDao.deletar(id);
        this.conexao.fechaConexaoBD(this.conexao.conectaBD(driver));
    }
    @Override
    public Collection<Funcionario> funcionarios(){
        return (Collection<Funcionario>) this.funcionarioDao.funcionarios();
    }
    
    @Override
    public String nomeFuncionario(int id){
        return this.funcionarioDao.nomeFuncionario(id);
    }
    
    @Override
    public Funcionario funcionario(int id){
        return this.funcionarioDao.funcionario(id);
    }
}
