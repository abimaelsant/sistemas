package funcionario;

import java.util.Collection;

public interface FuncionarioDaoInterface {
    void cadastrar(Funcionario funcionario);
    void editar(Funcionario funcionario);
    void deletar(int id);
    Collection<?> funcionarios();
    Funcionario funcionario(int id);
    String nomeFuncionario(int id);
}
