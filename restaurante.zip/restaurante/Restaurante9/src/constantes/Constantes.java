package constantes;

public class Constantes {
    private float valorComissaoGarcom;

    public Constantes(){
        this.valorComissaoGarcom = 9;
    }
    public float getValorComissaoGarcom() {
        return valorComissaoGarcom;
    }
}
