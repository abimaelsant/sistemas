package restaurante;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import login.PasswordHash;
public class Restaurante {

    @SuppressWarnings("empty-statement")
    public static void main(String[] args) throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeySpecException {
      
        String senha = "senha12";
        PasswordHash crypt = new PasswordHash();
        String hash = PasswordHash.createHash("vendaqwe123");
        if(PasswordHash.validatePassword(senha, "1000:03e6830ca99bc46c3823bebfc02d3402e559b14db02d6770:c38e90928454c7d31679d427dab7aab753a77bfd860699c2")){
            System.out.println("Certo");
        }else{
            System.out.println("errado");
        }
          System.out.println(hash);       
    }
    
}